package com.cands.ecureader.data

data class BikeModel(
    val id: String,
    val name: String,
    val category: String,
    val engineCc: Int,
    val ecuType: String,
    val rpmDivider: Float = 4.0f
)

object HondaBikeProfiles {
    val list = listOf(
        BikeModel("auto", "Auto Detect (Otomatis)", "System", 0, "Keihin KWP2000", 4.0f),
        BikeModel("beat_fi_old", "Honda BeAT FI (2012-2014)", "Matic", 110, "Keihin 8-bit", 4.0f),
        BikeModel("beat_fi_esp", "Honda BeAT eSP / Street (2016-2019)", "Matic", 110, "Keihin 16-bit eSP", 4.0f),
        BikeModel("beat_deluxe", "Honda BeAT Deluxe / Genio / Scoopy (2020-2026)", "Matic", 110, "Keihin K0J PGM-FI", 4.0f),
        BikeModel("scoopy_esp", "Honda Scoopy eSP Donat / Stylish (2017-2020)", "Matic", 110, "Keihin K93 PGM-FI", 4.0f),
        BikeModel("spacy_fi", "Honda Spacy 110 PGM-FI", "Matic", 110, "Keihin KZL", 4.0f),
        BikeModel("vario_110", "Honda Vario 110 Fi LED", "Matic", 110, "Keihin PGM-FI", 4.0f),
        BikeModel("vario_125_old", "Honda Vario 125 Old (Bohlam / CBS ISS)", "Matic", 125, "Keihin KZR PGM-FI", 4.0f),
        BikeModel("vario_125_esp", "Honda Vario 125 eSP / LED (2015-2026)", "Matic", 125, "Keihin K35 / K60", 4.0f),
        BikeModel("vario_150", "Honda Vario 150 eSP (LED / Keyless)", "Matic", 150, "Keihin K59 / K59J", 4.0f),
        BikeModel("vario_160", "Honda Vario 160 4V eSP+", "Matic", 160, "Keihin K2S PGM-FI", 4.0f),
        BikeModel("pcx_150", "Honda PCX 150 Lokal / CBU", "Matic", 150, "Keihin K97 PGM-FI", 4.0f),
        BikeModel("pcx_160", "Honda PCX 160", "Matic", 160, "Keihin K1Z PGM-FI", 4.0f),
        BikeModel("adv_150_160", "Honda ADV 150 / ADV 160", "Matic", 160, "Keihin PGM-FI", 4.0f),
        BikeModel("forza_250", "Honda Forza 250 / 300", "Matic", 250, "Keihin Forza PGM-FI", 4.0f),
        BikeModel("revo_fi", "Honda Revo 110 FI / Fit", "Underbone", 110, "Keihin K03 PGM-FI", 4.0f),
        BikeModel("supra_x_125", "Honda Supra X 125 FI / Helm-In", "Underbone", 125, "Keihin KYZ PGM-FI", 4.0f),
        BikeModel("supra_gtr_sonic", "Honda Supra GTR 150 / Sonic 150R", "Underbone", 150, "Keihin K56 PGM-FI", 4.0f),
        BikeModel("crf_150l", "Honda CRF 150L", "Sport", 150, "Keihin K84 PGM-FI", 4.0f),
        BikeModel("verza_150", "Honda Verza 150 / CB150 Verza", "Sport", 150, "Keihin K18 PGM-FI", 4.0f),
        BikeModel("cb150r", "Honda CB150R Streetfire (Old & New)", "Sport", 150, "Keihin K15 / K56", 4.0f),
        BikeModel("cbr_150r", "Honda CBR 150R / CB150R", "Sport", 150, "Keihin K75G / K45", 4.0f),
        BikeModel("cbr_250rr", "Honda CBR 250RR / CRF 250L", "Sport", 250, "Keihin K64 High-End", 4.0f)
    )
}
