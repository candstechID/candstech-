package com.cands.ecureader.data

data class BikeModel(val id: String, val name: String, val category: String, val engineCc: Int, val ecuType: String, val rpmDivider: Float = 4.0f)

object HondaBikeProfiles {
    val list = listOf(
        BikeModel("auto", "Auto Detect (Otomatis)", "System", 0, "Keihin KWP2000", 4.0f),
        BikeModel("vario_150", "Honda Vario 150 eSP (LED / Keyless)", "Matic", 150, "Keihin K59 / K59J", 4.0f),
        BikeModel("beat_deluxe", "Honda BeAT Deluxe / Genio (2020+)", "Matic", 110, "Keihin K0J PGM-FI", 4.0f),
        BikeModel("vario_125_esp", "Honda Vario 125 eSP (2015+)", "Matic", 125, "Keihin K35 / K60", 4.0f),
        BikeModel("pcx_160", "Honda PCX 160", "Matic", 160, "Keihin K1Z PGM-FI", 4.0f),
        BikeModel("adv_160", "Honda ADV 160", "Matic", 160, "Keihin PGM-FI", 4.0f),
        BikeModel("cb150r", "Honda CB150R Streetfire", "Sport", 150, "Keihin K15 / K56", 4.0f),
        BikeModel("cbr_150r", "Honda CBR 150R", "Sport", 150, "Keihin K75G / K45", 4.0f)
    )
}
