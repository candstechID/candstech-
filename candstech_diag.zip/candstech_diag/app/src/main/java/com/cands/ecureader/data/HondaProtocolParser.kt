package com.cands.ecureader.data

/**
 * Parser tunggal Honda Keihin K-Line.
 * Indeks data D9 dimulai dari frame[4]. Byte checksum adalah byte terakhir.
 */
data class HondaParsedData(
    val rpm: Int? = null,
    val tpsDeg: Float? = null,
    val tpsVolt: Float? = null,
    val ect: Int? = null,
    val ectVolt: Float? = null,
    val iat: Int? = null,
    val iatVolt: Float? = null,
    val mapKpa: Int? = null,
    val mapVolt: Float? = null,
    val battery: Float? = null,
    val injectorMs: Float? = null,
    val ignitionDeg: Float? = null,
    val speedKmh: Int? = null,
    val o2Volt: Float? = null,
    val stft: Float? = null,
    val o2HeaterVolt: Float? = null,
    val fastIdle: Boolean? = null,
    val statusText: String? = null,
    val fuelPumpOn: Boolean? = null,
    val coolingFanOn: Boolean? = null
)

data class HondaDtc(
    val code: String,
    val description: String
)

object HondaProtocolParser {
    private val dtcDescriptions = mapOf(
        "001-1" to "Rangkaian sensor MAP tegangan rendah",
        "001-2" to "Rangkaian sensor MAP tegangan tinggi",
        "002-1" to "Masalah kinerja sensor MAP",
        "006-1" to "Rangkaian sensor barometrik tegangan rendah",
        "006-2" to "Rangkaian sensor barometrik tegangan tinggi",
        "007-1" to "Rangkaian sensor ECT tegangan rendah",
        "007-2" to "Rangkaian sensor ECT tegangan tinggi",
        "008-1" to "Rangkaian sensor TP tegangan rendah",
        "008-2" to "Sirkuit sensor TP tegangan tinggi",
        "009-1" to "Rangkaian sensor IAT tegangan rendah",
        "009-2" to "Rangkaian sensor IAT tegangan tinggi",
        "011-1" to "Sensor VS tidak ada sinyal",
        "012-1" to "Kerusakan sirkuit injektor utama No.1",
        "013-1" to "Kerusakan sirkuit injektor utama No.2",
        "014-1" to "Kerusakan sirkuit injektor utama No.3",
        "015-1" to "No. 4 kerusakan sirkuit injektor primer",
        "016-1" to "Kerusakan sirkuit injektor sekunder No.1",
        "017-1" to "Kerusakan sirkuit injektor sekunder No.2",
        "018-1" to "Sensor CMP tidak ada sinyal",
        "019-1" to "Sensor CKP tidak ada sinyal",
        "021-1" to "O2 bank sensor 1 tegangan rendah",
        "021-2" to "O2 bank sensor 1 tegangan tinggi",
        "022-1" to "O2 bank sensor 2 tegangan rendah",
        "022-2" to "O2 bank sensor 2 tegangan tinggi"
    )

    fun checksum(bytes: ByteArray, count: Int = bytes.size): Int {
        var sum = 0
        for (i in 0 until count.coerceAtMost(bytes.size)) sum += bytes[i].toInt() and 0xFF
        return (0x100 - (sum and 0xFF)) and 0xFF
    }

    fun isChecksumValid(frame: ByteArray): Boolean =
        frame.size >= 4 && checksum(frame, frame.size - 1) == u(frame, frame.size - 1)

    fun buildQuery(query: Int, table: Int): ByteArray {
        val frame = byteArrayOf(0x72, 0x05, query.toByte(), table.toByte(), 0)
        frame[4] = checksum(frame, 4).toByte()
        return frame
    }

    fun parseLive(frame: ByteArray): HondaParsedData? {
        if (!isValidFrame(frame) || u(frame, 2) != 0x71) return null
        val table = u(frame, 3)
        // Reject short/unsupported table acknowledgements instead of returning
        // an apparently valid object filled entirely with null values.
        val minimumFrameSize = when (table) {
            0x10, 0x11, 0x13 -> 23 // through D26 (vehicle speed)
            0x17 -> 21             // through D24 (vehicle speed)
            0x20, 0x21 -> 8        // through D11 (O2 heater)
            0xD1 -> 11             // through D14 (fan status)
            else -> return null
        }
        if (frame.size < minimumFrameSize) return null
        val d = frame.copyOfRange(4, frame.size - 1)
        fun v(n: Int) = d.getOrNull(n - 9)?.toInt()?.and(0xFF)
        fun pair(n: Int): Int? {
            val hi = v(n) ?: return null
            val lo = v(n + 1) ?: return null
            return (hi shl 8) or lo
        }
        fun volt(n: Int, divisor: Float = 256f) = v(n)?.let { it * (5f / divisor) }
        return when (table) {
            0x10, 0x11, 0x13 -> {
                val rpm = pair(9)
                val injDiv = when (table) { 0x10 -> 10f; 0x11 -> 100f; else -> 200f }
                HondaParsedData(
                    rpm = rpm,
                    tpsVolt = volt(11),
                    tpsDeg = v(12)?.times(0.5f),
                    ectVolt = volt(13),
                    ect = v(14)?.minus(40),
                    iatVolt = volt(15),
                    iat = v(16)?.minus(40),
                    mapVolt = volt(17, if (table == 0x13) 255f else 256f),
                    mapKpa = v(18),
                    battery = v(if (table == 0x13) 20 else 21)?.times(0.1f),
                    injectorMs = pair(if (table == 0x13) 23 else 23)?.div(injDiv),
                    ignitionDeg = v(25)?.let { -64f + it * 0.5f },
                    speedKmh = v(26)
                )
            }
            0x17 -> HondaParsedData(
                rpm = pair(9),
                tpsVolt = volt(11),
                tpsDeg = v(12)?.times(0.5f),
                ectVolt = volt(13),
                ect = v(14)?.minus(40),
                iatVolt = volt(17),
                iat = v(18)?.minus(40),
                battery = v(19)?.times(0.1f),
                injectorMs = pair(20)?.div(200f),
                ignitionDeg = v(22)?.let { -64f + it * 0.5f },
                fastIdle = v(23)?.let { it < 128 },
                speedKmh = v(24)
            )
            0x20, 0x21 -> HondaParsedData(
                o2Volt = volt(9),
                stft = v(10)?.div(128f),
                o2HeaterVolt = volt(11)
            )
            0xD1 -> HondaParsedData(
                statusText = when (v(9)) {
                    0 -> "On Gear"
                    1 -> "Neutral"
                    2 -> "SSS ON"
                    3 -> "SSW ON"
                    else -> "Status ${v(9)}"
                },
                fuelPumpOn = v(13)?.let { it == 1 || it == 5 },
                coolingFanOn = v(14)?.let { it == 1 }
            )
            else -> null
        }
    }

    /**
     * Setiap respons DTC: 02 0C query table D9 D10 D11 D12 D13 D14 CS.
     * Pasangan byte: subkode lebih dulu, nomor DTC sesudahnya.
     */
    fun parseDtc(frame: ByteArray): List<HondaDtc> {
        if (!isValidFrame(frame) || frame.size != 12) return emptyList()
        val query = u(frame, 2)
        if (query != 0x73 && query != 0x74) return emptyList()
        val result = mutableListOf<HondaDtc>()
        var i = 4
        while (i <= 8) {
            val sub = u(frame, i)
            val number = u(frame, i + 1)
            if (sub != 0 || number != 0) {
                val code = "%03d-%d".format(number, when (sub) {
                    1 -> 2
                    2 -> 1
                    else -> sub
                })
                result += HondaDtc(code, dtcDescriptions[code] ?: "Deskripsi belum tersedia")
            }
            i += 2
        }
        return result
    }

    fun isValidFrame(frame: ByteArray): Boolean =
        frame.size >= 4 &&
            u(frame, 0) == 0x02 &&
            u(frame, 1) == frame.size &&
            isChecksumValid(frame)

    private fun u(bytes: ByteArray, index: Int): Int =
        bytes[index].toInt() and 0xFF
}
