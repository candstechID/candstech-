package com.cands.ecureader.viewmodel

import android.app.Application
import android.os.Environment
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null

    var isConnected by mutableStateOf(false)
    var isKontakOn by mutableStateOf(false)

    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)

    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var afr by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    
    var batteryVolt by mutableFloatStateOf(0.0f)
    var engineLoad by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var iat by mutableIntStateOf(0)
    var iacv by mutableIntStateOf(0)
    var injectorMs by mutableFloatStateOf(0.0f)

    private var lastDataTimestamp = System.currentTimeMillis()

    fun selectBike(bike: BikeModel) {
        selectedBike = bike
        Toast.makeText(getApplication(), "Motor dipilih: ${bike.name}", Toast.LENGTH_SHORT).show()
    }

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        isConnected = true
        isKontakOn = true
        lastDataTimestamp = System.currentTimeMillis()

        manager.onDataReceived = { newRpm, newTpsDeg, newTpsVolt, newAfr, newEct, newBatt, newLoad, newMap, newIat, newIacv, newInj ->
            isKontakOn = true
            lastDataTimestamp = System.currentTimeMillis()
            rpm = newRpm
            tpsDegrees = newTpsDeg
            tpsVolt = newTpsVolt
            afr = newAfr
            ect = newEct
            batteryVolt = newBatt
            engineLoad = newLoad
            mapKpa = newMap
            iat = newIat
            iacv = newIacv
            injectorMs = newInj
        }
    }

    fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                if (isConnected && System.currentTimeMillis() - lastDataTimestamp > 2000) {
                    isKontakOn = false
                }

                kLineManager?.sendCommand(kLineManager?.CMD_LIVE_DATA ?: break)
                kLineManager?.pollEngineData()
                delay(100)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        isConnected = false
        isKontakOn = false
    }

    fun triggerDiagMode() {
        Toast.makeText(getApplication(), "Mode DIAG Sensor [${selectedBike.name}] Aktif", Toast.LENGTH_SHORT).show()
    }

    fun resetTopEcu() { topSpeedEcu = 0 }
    fun resetTopGps() { topSpeedGps = 0 }
    
    fun scanDtc() {
        kLineManager?.sendCommand(kLineManager?.CMD_READ_DTC ?: return)
        Toast.makeText(getApplication(), "Scanning DTC (${selectedBike.name})...", Toast.LENGTH_SHORT).show()
    }
    
    fun clearDtc() {
        kLineManager?.sendCommand(kLineManager?.CMD_CLEAR_DTC ?: return)
        Toast.makeText(getApplication(), "Menghapus DTC...", Toast.LENGTH_SHORT).show()
    }
    
    fun resetTp() {
        kLineManager?.sendCommand(kLineManager?.CMD_RESET_TP ?: return)
        Toast.makeText(getApplication(), "Reset TP Terkirim", Toast.LENGTH_SHORT).show()
    }
    
    fun exportCsvLogger() {
        viewModelScope.launch {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "ECU_Log_${selectedBike.id}_$timestamp.csv"
                val path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(path, fileName)
                val writer = FileWriter(file)
                writer.append("Motor,Timestamp,RPM,SpeedECU,SpeedGPS,TPS_Deg,TPS_V,AFR,ECT,BATT,LOAD,MAP,IAT,IACV,INJ_ms\n")
                val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
                writer.append("${selectedBike.name},$time,$rpm,$speedEcu,$speedGps,$tpsDegrees,$tpsVolt,$afr,$ect,$batteryVolt,$engineLoad,$mapKpa,$iat,$iacv,$injectorMs\n")
                writer.flush()
                writer.close()
                Toast.makeText(getApplication(), "Tersimpan: $fileName di Downloads", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(getApplication(), "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
    }
}
