package com.cands.ecureader.viewmodel

import android.app.Application
import android.location.Location
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    private var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null
    private var operationJob: Job? = null
    private var pollCounter = 0

    val isConnected = mutableStateOf(false)
    val isKontakOn = mutableStateOf(false)
    val speedEcu = mutableStateOf(0f)
    val topSpeedEcu = mutableStateOf(0f)
    val speedGps = mutableStateOf(0f)
    val topSpeedGps = mutableStateOf(0f)
    val rpm = mutableStateOf(0)
    val tpsDegrees = mutableStateOf(0f)
    val tpsVolt = mutableStateOf(0f)
    val ect = mutableStateOf(0)
    val afr = mutableStateOf(0f)
    val batteryVolt = mutableStateOf(0f)
    val engineLoad = mutableStateOf(0f)
    val mapKpa = mutableStateOf(0)
    val iat = mutableStateOf(0)
    val iacv = mutableStateOf(0)
    val injectorMs = mutableStateOf(0f)
    val dtcMessage = mutableStateOf("Belum ada pemeriksaan DTC")
    val dtcList = mutableStateListOf<String>()
    val isScanningDtc = mutableStateOf(false)
    val isScanningSensor = mutableStateOf(false)
    val sensorDetailList = mutableStateListOf<SensorItem>()
    val showSensorDialog = mutableStateOf(false)
    val uiLogs = mutableStateListOf<String>()
    val selectedBike = mutableStateOf(HondaBikeProfiles.list.first())

    fun addLog(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        uiLogs.add(0, "[$stamp] $message")
        while (uiLogs.size > 250) uiLogs.removeAt(uiLogs.lastIndex)
    }

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        manager.onLog = { message -> addLog(message) }
        manager.onDataReceived = { data ->
            if (data.rpm >= 0) rpm.value = data.rpm
            if (data.tpsDeg.isFinite()) tpsDegrees.value = data.tpsDeg
            if (data.tpsVolt.isFinite()) tpsVolt.value = data.tpsVolt
            if (data.ect >= -40) ect.value = data.ect
            if (data.battery.isFinite()) batteryVolt.value = data.battery
            if (data.mapKpa >= 0) mapKpa.value = data.mapKpa
            if (data.iat >= -40) iat.value = data.iat
            if (data.injectorMs.isFinite()) injectorMs.value = data.injectorMs
            if (data.speedKmh >= 0) {
                speedEcu.value = data.speedKmh.toFloat()
                if (speedEcu.value > topSpeedEcu.value) topSpeedEcu.value = speedEcu.value
            }
        }
        manager.onSensorDetailReceived = { items ->
            sensorDetailList.clear()
            sensorDetailList.addAll(items)
        }
        manager.onDtcReceived = { codes ->
            dtcList.clear()
            dtcList.addAll(codes)
            dtcMessage.value = if (codes.isEmpty()) "Tidak ada DTC pada tabel yang terbaca"
                else "${codes.size} DTC ditemukan"
        }
    }

    fun setConnectionState(connected: Boolean) {
        isConnected.value = connected
        isKontakOn.value = connected
        if (!connected) stopPolling()
    }

    fun startPolling() {
        if (pollJob?.isActive == true) return
        pollJob = viewModelScope.launch {
            while (isActive && isConnected.value) {
                if (operationJob?.isActive != true) {
                    val ok = try { kLineManager?.requestLiveData() == true }
                    catch (e: Exception) { addLog("Polling error: ${e.message}"); false }
                    if (!ok) addLog("Pembacaan live data gagal / tidak ada respons.")
                    pollCounter++
                    if (pollCounter >= 10) {
                        kLineManager?.sendKeepAlive()
                        pollCounter = 0
                    }
                }
                delay(250)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    fun requestFullSensorData() {
        if (isScanningSensor.value) return
        operationJob?.cancel()
        operationJob = viewModelScope.launch {
            isScanningSensor.value = true
            try {
                for (table in listOf(0x11, 0x13, 0x17, 0x20, 0x21, 0xD1)) {
                    kLineManager?.requestLiveTable(table)
                    delay(70)
                }
                addLog("Pembacaan tabel sensor selesai.")
            } catch (e: Exception) {
                addLog("Scan sensor gagal: ${e.message}")
            } finally { isScanningSensor.value = false }
        }
    }

    fun scanDtc() {
        if (isScanningDtc.value) return
        operationJob?.cancel()
        operationJob = viewModelScope.launch {
            isScanningDtc.value = true
            dtcList.clear()
            try {
                kLineManager?.readDtcTables()
                kLineManager?.readCurrentDtcTables()
            } catch (e: Exception) {
                dtcMessage.value = "Scan DTC gagal: ${e.message}"
                addLog(dtcMessage.value)
            } finally { isScanningDtc.value = false }
        }
    }

    fun clearDtc() {
        operationJob?.cancel()
        operationJob = viewModelScope.launch {
            try {
                val ack = kLineManager?.clearDtcTable01()
                addLog(if (ack != null) "RESET ECM / CLEAR DTC: ACK valid."
                    else "RESET ECM / CLEAR DTC gagal.")
            } catch (e: Exception) { addLog("Clear DTC error: ${e.message}") }
        }
    }

    fun resetTp() {
        operationJob?.cancel()
        operationJob = viewModelScope.launch {
            try {
                addLog("Pastikan mesin mati dan gas tertutup penuh sebelum RESET TP.")
                val ack = kLineManager?.resetTp()
                if (ack != null) {
                    addLog("ACK RESET TP diterima. Membaca ulang TPS dari tabel 17.")
                    delay(100)
                    kLineManager?.requestLiveTable(0x17)
                } else addLog("RESET TP gagal: ACK tidak diterima.")
            } catch (e: Exception) { addLog("Reset TP error: ${e.message}") }
        }
    }

    fun updateGpsSpeed(location: Location) {
        val kmh = (location.speed * 3.6f).coerceAtLeast(0f)
        speedGps.value = kmh
        if (kmh > topSpeedGps.value) topSpeedGps.value = kmh
    }

    fun selectBike(bike: BikeModel) { selectedBike.value = bike }

    fun disconnect() {
        stopPolling()
        operationJob?.cancel()
        operationJob = null
        kLineManager?.onLog = null
        kLineManager?.onDataReceived = null
        kLineManager?.onDtcReceived = null
        kLineManager?.onSensorDetailReceived = null
        kLineManager?.closePort()
        kLineManager = null
        setConnectionState(false)
    }

    override fun onCleared() {
        disconnect()
        super.onCleared()
    }
}
