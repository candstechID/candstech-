package com.cands.ecureader.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.Location
import android.os.Looper
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val Context.dataStore by preferencesDataStore(name = "ecu_prefs")

data class EcuState(
    val speedEcu: Int = 0,
    val speedGps: Int = 0,
    val topSpeed: Int = 0,
    val rpm: Int = 0,
    val tpsDeg: Float = 0f,
    val tpsVolt: Float = 0.5f,
    val afr: Float = 14.7f,
    val ectC: Int = 85,
    val batteryV: Float = 12.8f,
    val engineLoadPct: Int = 22,
    val mapKpa: Int = 32,
    val iatC: Int = 30,
    val iacvPct: Int = 28,
    val injectorMs: Float = 2.4f,
    val dtcList: List<String> = emptyList(),
    val isScanning: Boolean = false,
    val logStatus: String = "Idle",
    
    // EXTENDED DIAGNOSTIC DATA FOR SERVICE
    val ignAdvanceDeg: Float = 12.5f,
    val o2Volt: Float = 0.45f,
    val targetIdle: Int = 1500,
    val fuelPumpOn: Boolean = true,
    val starterOn: Boolean = false,
    val milOn: Boolean = false,
    val sideStandDown: Boolean = false
)

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    private val _state = MutableStateFlow(EcuState())
    val state: StateFlow<EcuState> = _state.asStateFlow()

    private val topSpeedKey = floatPreferencesKey("top_speed")
    private var diagnosticJob: Job? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    init {
        loadTopSpeed()
        initGps(application)
        startSimulatedLiveStream()
    }

    private fun loadTopSpeed() {
        viewModelScope.launch {
            getApplication<Application>().dataStore.data
                .map { prefs -> prefs[topSpeedKey] ?: 0f }
                .collect { ts ->
                    _state.value = _state.value.copy(topSpeed = ts.toInt())
                }
        }
    }

    fun resetTopSpeed() {
        viewModelScope.launch {
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[topSpeedKey] = 0f
            }
            _state.value = _state.value.copy(topSpeed = 0)
        }
    }

    @SuppressLint("MissingPermission")
    private fun initGps(context: Context) {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    val speedKmh = (loc.speed * 3.6f).roundToInt().coerceAtLeast(0)
                    val currentTop = _state.value.topSpeed
                    if (speedKmh > currentTop) {
                        viewModelScope.launch {
                            getApplication<Application>().dataStore.edit { prefs ->
                                prefs[topSpeedKey] = speedKmh.toFloat()
                            }
                        }
                    }
                    _state.value = _state.value.copy(
                        speedGps = speedKmh,
                        topSpeed = maxOf(currentTop, speedKmh)
                    )
                }
            }
        }
        try {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
        } catch (_: Exception) {}
    }

    private fun startSimulatedLiveStream() {
        diagnosticJob?.cancel()
        diagnosticJob = viewModelScope.launch(Dispatchers.Default) {
            var counter = 0
            while (true) {
                delay(200)
                counter++
                val simRpm = 1200 + ((counter * 180) % 7500)
                val simSpeed = (simRpm / 115).coerceIn(0, 140)
                val simTpsDeg = (simRpm / 110f).coerceIn(0f, 80f)
                val simTpsVolt = 0.5f + (simTpsDeg / 80f) * 4.0f
                val simAfr = if (counter % 7 == 0) 12.8f else 14.7f
                val simEct = 82 + (counter % 15)
                
                // Extended simulation
                val simO2 = 0.1f + ((counter % 9) * 0.1f)
                val simIgn = 10f + (simRpm / 500f)

                _state.value = _state.value.copy(
                    speedEcu = simSpeed,
                    rpm = simRpm,
                    tpsDeg = simTpsDeg,
                    tpsVolt = simTpsVolt,
                    afr = simAfr,
                    ectC = simEct,
                    batteryV = 13.2f + (counter % 5) * 0.05f,
                    engineLoadPct = 20 + (simRpm / 200),
                    mapKpa = 30 + (simRpm / 300),
                    iatC = 32,
                    iacvPct = 25,
                    injectorMs = 2.1f + (simRpm / 4000f),
                    ignAdvanceDeg = simIgn,
                    o2Volt = simO2,
                    targetIdle = 1500,
                    fuelPumpOn = simRpm > 0 || counter % 20 < 15,
                    starterOn = false,
                    milOn = _state.value.dtcList.isNotEmpty(),
                    sideStandDown = false
                )
            }
        }
    }

    fun scanDtc() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isScanning = true, logStatus = "Scanning DTC (02 04 10 EA)...")
            delay(1000)
            _state.value = _state.value.copy(
                isScanning = false,
                dtcList = listOf("P0112 - IAT Sensor Circuit Low", "P0230 - Fuel Pump Primary Circuit"),
                logStatus = "DTC Scan Complete: 2 Trouble Codes Found",
                milOn = true
            )
        }
    }

    fun clearDtc() {
        viewModelScope.launch {
            _state.value = _state.value.copy(logStatus = "Clearing DTC (02 04 20 DA)...")
            delay(800)
            _state.value = _state.value.copy(dtcList = emptyList(), logStatus = "DTC Cleared Successfully", milOn = false)
        }
    }

    fun resetTp() {
        viewModelScope.launch {
            _state.value = _state.value.copy(logStatus = "Resetting Throttle Position (02 04 60 9A)...")
            delay(800)
            _state.value = _state.value.copy(tpsDeg = 0f, logStatus = "TP Sensor Reset Complete")
        }
    }

    fun startCsvLogger() {
        _state.value = _state.value.copy(logStatus = "CSV Logger active: /Download/ECU_Log.csv")
    }

    override fun onCleared() {
        super.onCleared()
        diagnosticJob?.cancel()
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (_: Exception) {}
    }
}
