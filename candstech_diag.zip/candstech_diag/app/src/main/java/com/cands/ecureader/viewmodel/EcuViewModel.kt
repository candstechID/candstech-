package com.cands.ecureader.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null

    var isConnected by mutableStateOf(false)
    var isKontakOn by mutableStateOf(false)
    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)
    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    var ectVolt by mutableFloatStateOf(0.0f)
    var iat by mutableIntStateOf(0)
    var iatVolt by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var mapVolt by mutableFloatStateOf(0.0f)
    var batteryVolt by mutableFloatStateOf(0.0f)
    var injectorMs by mutableFloatStateOf(0.0f)

    var isScanningDtc by mutableStateOf(false)
    var dtcList by mutableStateOf<List<String>>(emptyList())
    var dtcMessage by mutableStateOf("")

    // BARU: State untuk Dialog Sensor Detail
    var sensorDetailList by mutableStateOf<List<SensorItem>>(emptyList())
    var showSensorDialog by mutableStateOf(false)

    private var lastDataTimestamp = System.currentTimeMillis()

    fun selectBike(bike: BikeModel) { selectedBike = bike }
    fun resetTopEcu() { topSpeedEcu = 0 }
    fun resetTopGps() { topSpeedGps = 0 }

    // BARU: Fungsi request semua tabel sensor
    fun requestFullSensorData() {
        val manager = kLineManager ?: return
        if (!isConnected) return
        
        showSensorDialog = true
        sensorDetailList = emptyList() // Reset list
        isScanningDtc = true // Pause polling sementara

        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_T11); delay(300)
            manager.sendCommand(manager.CMD_T13); delay(300)
            manager.sendCommand(manager.CMD_T20); delay(300)
            manager.sendCommand(manager.CMD_TD1); delay(300)
            isScanningDtc = false
        }
    }

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        isConnected = true; isKontakOn = true
        lastDataTimestamp = System.currentTimeMillis()

        manager.onDataReceived = { data ->
            viewModelScope.launch(Dispatchers.Main) {
                isKontakOn = true; lastDataTimestamp = System.currentTimeMillis()
                rpm = data.rpm; tpsDegrees = data.tpsDeg; tpsVolt = data.tpsVolt
                ect = data.ect; ectVolt = data.ectVolt; iat = data.iat; iatVolt = data.iatVolt
                mapKpa = data.mapKpa; mapVolt = data.mapVolt; batteryVolt = data.battery
                injectorMs = data.injectorMs; speedEcu = data.speedKmh
                if (speedEcu > topSpeedEcu) topSpeedEcu = speedEcu
            }
        }

        // BARU: Terima data detail sensor
        manager.onSensorDetailReceived = { items ->
            viewModelScope.launch(Dispatchers.Main) {
                // Tambahkan ke list yang sudah ada (jangan di-replace, karena kita request bertahap)
                sensorDetailList = sensorDetailList + items
            }
        }

        manager.onDtcReceived = { dtcs ->
            viewModelScope.launch(Dispatchers.Main) {
                dtcList = dtcs
                dtcMessage = if (dtcs.isEmpty()) "Tidak Ada DTC Tersimpan" else "${dtcs.size} Kode DTC Terdeteksi!"
            }
        }
    }

    fun scanDtc() {
        if (!isConnected) return; isScanningDtc = true; dtcMessage = "Memindai DTC..."
        viewModelScope.launch(Dispatchers.IO) {
            kLineManager?.sendCommand(kLineManager?.CMD_READ_DTC ?: return@launch); delay(1000); isScanningDtc = false
        }
    }

    fun clearDtc() {
        if (!isConnected) return; isScanningDtc = true; dtcMessage = "Menghapus DTC..."
        viewModelScope.launch(Dispatchers.IO) {
            kLineManager?.sendCommand(kLineManager?.CMD_CLEAR_DTC ?: return@launch)
            delay(500); withContext(Dispatchers.Main) { dtcList = emptyList(); dtcMessage = "DTC Berhasil Dihapus!" }
            delay(1000); isScanningDtc = false
        }
    }

    fun resetTp() {
        if (!isConnected) return; isScanningDtc = true; dtcMessage = "Melakukan Reset TP..."
        viewModelScope.launch(Dispatchers.IO) {
            kLineManager?.sendCommand(kLineManager?.CMD_RESET_TP ?: return@launch)
            delay(500); withContext(Dispatchers.Main) { dtcMessage = "Reset TP Berhasil Dikirim!" }
            delay(1000); isScanningDtc = false
        }
    }

    fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                if (isConnected && System.currentTimeMillis() - lastDataTimestamp > 2500) isKontakOn = false
                if (isConnected && !isScanningDtc) {
                    val cmd = kLineManager?.CMD_LIVE_DATA
                    if (cmd != null) { kLineManager?.sendCommand(cmd); kLineManager?.pollEngineData() } else { break }
                }
                delay(150)
            }
        }
    }

    fun stopPolling() { pollJob?.cancel(); isConnected = false; isKontakOn = false }
    fun updateGpsSpeed(speed: Float) { val kmh = (speed * 3.6f).toInt(); speedGps = kmh; if (kmh > topSpeedGps) topSpeedGps = kmh }
    override fun onCleared() { super.onCleared(); stopPolling(); kLineManager = null }
}