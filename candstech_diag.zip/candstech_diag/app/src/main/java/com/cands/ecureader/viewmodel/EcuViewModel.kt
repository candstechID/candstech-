package com.cands.ecureader.viewmodel

import android.app.Application
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.HondaKLineManager
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    var kLineManager: HondaKLineManager? = null

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)

    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(5.0f)
    var tpsVolt by mutableFloatStateOf(0.45f)
    var afr by mutableFloatStateOf(14.7f)
    var ect by mutableIntStateOf(85)
    
    var batteryVolt by mutableFloatStateOf(12.4f)
    var engineLoad by mutableFloatStateOf(0f)
    var mapKpa by mutableIntStateOf(30)
    var iat by mutableIntStateOf(32)
    var iacv by mutableIntStateOf(40)
    var injectorMs by mutableFloatStateOf(2.5f)

    fun resetTopEcu() { topSpeedEcu = 0 }
    fun resetTopGps() { topSpeedGps = 0 }
    
    fun scanDtc() {
        kLineManager?.sendCommand(kLineManager?.CMD_READ_DTC ?: return)
        Toast.makeText(getApplication(), "Scanning DTC...", Toast.LENGTH_SHORT).show()
    }
    
    fun clearDtc() {
        kLineManager?.sendCommand(kLineManager?.CMD_CLEAR_DTC ?: return)
        Toast.makeText(getApplication(), "Menghapus DTC...", Toast.LENGTH_SHORT).show()
    }
    
    fun resetTp() {
        kLineManager?.sendCommand(kLineManager?.CMD_RESET_TP ?: return)
        Toast.makeText(getApplication(), "Reset TP Terkirim", Toast.LENGTH_SHORT).show()
    }
    
    fun exportCsvLogger() {
        viewModelScope.launch {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "ECU_Log_$timestamp.csv"
                
                // Gunakan folder Downloads agar mudah dicari user
                val path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(path, fileName)
                
                val writer = FileWriter(file)
                writer.append("Timestamp,RPM,SpeedECU,SpeedGPS,TPS_Deg,TPS_V,AFR,ECT,BATT,LOAD,MAP,IAT,IACV,INJ_ms\n")
                
                val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
                writer.append("$time,$rpm,$speedEcu,$speedGps,$tpsDegrees,$tpsVolt,$afr,$ect,$batteryVolt,$engineLoad,$mapKpa,$iat,$iacv,$injectorMs\n")
                
                writer.flush()
                writer.close()
                
                Toast.makeText(getApplication(), "Tersimpan: $fileName di folder Downloads", Toast.LENGTH_LONG).show()
                Log.d("EcuViewModel", "CSV Tersimpan di: ${file.absolutePath}")
            } catch (e: Exception) {
                Log.e("EcuViewModel", "Gagal menyimpan CSV: ${e.message}")
                Toast.makeText(getApplication(), "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
