
package com.cands.ecureader.viewmodel

import android.app.Application
import android.location.Location
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {

    private var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null
    private var operationJob: Job? = null
    private var pollCounter = 0

    // CONNECTION
    var isConnected by mutableStateOf(false)
        private set

    var isKontakOn by mutableStateOf(false)
        private set

    // SPEED ECU - sumber data dari ECU melalui K-Line
    var speedEcu by mutableStateOf(0f)
        private set

    var topSpeedEcu by mutableStateOf(0f)
        private set

    // SPEED GPS - sumber data dari Android Location
    var speedGps by mutableStateOf(0f)
        private set

    var topSpeedGps by mutableStateOf(0f)
        private set

    // ENGINE DATA
    var rpm by mutableStateOf(0)
        private set

    var tpsDegrees by mutableStateOf(0f)
        private set

    var tpsVolt by mutableStateOf(0f)
        private set

    var ect by mutableStateOf(0)
        private set

    var afr by mutableStateOf(0f)
        private set

    var batteryVolt by mutableStateOf(0f)
        private set

    var engineLoad by mutableStateOf(0f)
        private set

    var mapKpa by mutableStateOf(0)
        private set

    var iat by mutableStateOf(0)
        private set

    var iacv by mutableStateOf(0)
        private set

    var injectorMs by mutableStateOf(0f)
        private set

    // DTC
    var dtcMessage by mutableStateOf("Belum ada pemeriksaan DTC")
        private set

    val dtcList = mutableStateListOf<String>()

    var isScanningDtc by mutableStateOf(false)
        private set

    var isScanningSensor by mutableStateOf(false)
        private set

    // SENSOR DETAIL
    val sensorDetailList = mutableStateListOf<SensorItem>()

    var showSensorDialog by mutableStateOf(false)

    // LOG
    val uiLogs = mutableStateListOf<String>()

    // MOTOR PROFILE
    var selectedBike by mutableStateOf(HondaBikeProfiles.list.first())
        private set

    fun addLog(message: String) {
        val stamp = SimpleDateFormat(
            "HH:mm:ss",
            Locale.getDefault()
        ).format(Date())

        uiLogs.add(0, "[$stamp] $message")

        while (uiLogs.size > 250) {
            uiLogs.removeAt(uiLogs.lastIndex)
        }
    }

    // =====================================================
    // K-LINE LISTENER
    // =====================================================

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager

        manager.onLog = { message ->
            addLog(message)
        }

        manager.onDataReceived = { data ->

            // DATA ECU
            if (data.rpm >= 0) {
                rpm = data.rpm
            }

            if (data.tpsDeg.isFinite()) {
                tpsDegrees = data.tpsDeg
            }

            if (data.tpsVolt.isFinite()) {
                tpsVolt = data.tpsVolt
            }

            if (data.ect >= -40) {
                ect = data.ect
            }

            if (data.battery.isFinite()) {
                batteryVolt = data.battery
            }

            if (data.mapKpa >= 0) {
                mapKpa = data.mapKpa
            }

            if (data.iat >= -40) {
                iat = data.iat
            }

            if (data.injectorMs.isFinite()) {
                injectorMs = data.injectorMs
            }

            // SPEED ECU: MURNI DARI DATA ECU
            if (data.speedKmh >= 0) {
                speedEcu = data.speedKmh.toFloat()

                if (speedEcu > topSpeedEcu) {
                    topSpeedEcu = speedEcu
                }
            }
        }

        manager.onSensorDetailReceived = { items ->
            sensorDetailList.clear()
            sensorDetailList.addAll(items)
        }

        manager.onDtcReceived = { codes ->
            dtcList.clear()
            dtcList.addAll(codes)

            dtcMessage = if (codes.isEmpty()) {
                "Tidak ada DTC pada tabel yang terbaca"
            } else {
                "${codes.size} DTC ditemukan"
            }
        }
    }

    // =====================================================
    // CONNECTION
    // =====================================================

    fun setConnectionState(connected: Boolean) {
        isConnected = connected
        isKontakOn = connected

        if (!connected) {
            stopPolling()
        }
    }

    // =====================================================
    // POLLING
    // =====================================================

    fun startPolling() {
        if (pollJob?.isActive == true) return

        pollJob = viewModelScope.launch {
            while (isActive && isConnected) {

                if (operationJob?.isActive != true) {

                    val ok = try {
                        kLineManager?.requestLiveData() == true
                    } catch (e: Exception) {
                        addLog("Polling error: ${e.message}")
                        false
                    }

                    if (!ok) {
                        addLog("Pembacaan live data gagal / tidak ada respons.")
                    }

                    pollCounter++

                    if (pollCounter >= 10) {
                        kLineManager?.sendKeepAlive()
                        pollCounter = 0
                    }
                }

                delay(250)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    // =====================================================
    // SENSOR SCAN
    // =====================================================

    fun requestFullSensorData() {
        if (isScanningSensor) return

        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            isScanningSensor = true

            try {
                for (table in listOf(
                    0x11,
                    0x13,
                    0x17,
                    0x20,
                    0x21,
                    0xD1
                )) {
                    kLineManager?.requestLiveTable(table)
                    delay(70)
                }

                addLog("Pembacaan tabel sensor selesai.")

            } catch (e: Exception) {
                addLog("Scan sensor gagal: ${e.message}")

            } finally {
                isScanningSensor = false
            }
        }
    }

    // =====================================================
    // DTC
    // =====================================================

    fun scanDtc() {
        if (isScanningDtc) return

        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            isScanningDtc = true
            dtcList.clear()

            try {
                kLineManager?.readDtcTables()
                kLineManager?.readCurrentDtcTables()

            } catch (e: Exception) {
                dtcMessage = "Scan DTC gagal: ${e.message}"
                addLog(dtcMessage)

            } finally {
                isScanningDtc = false
            }
        }
    }

    fun clearDtc() {
        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            try {
                val ack = kLineManager?.clearDtcTable01()

                addLog(
                    if (ack != null) {
                        "RESET ECM / CLEAR DTC: ACK valid."
                    } else {
                        "RESET ECM / CLEAR DTC gagal."
                    }
                )

            } catch (e: Exception) {
                addLog("Clear DTC error: ${e.message}")
            }
        }
    }

    // =====================================================
    // RESET TP
    // =====================================================

    fun resetTp() {
        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            try {
                addLog(
                    "Pastikan mesin mati dan gas tertutup penuh sebelum RESET TP."
                )

                val ack = kLineManager?.resetTp()

                if (ack != null) {
                    addLog(
                        "ACK RESET TP diterima. Membaca ulang TPS dari tabel 17."
                    )

                    delay(100)
                    kLineManager?.requestLiveTable(0x17)

                } else {
                    addLog("RESET TP gagal: ACK tidak diterima.")
                }

            } catch (e: Exception) {
                addLog("Reset TP error: ${e.message}")
            }
        }
    }

    // =====================================================
    // GPS SPEED
    // =====================================================

    // Dipanggil dengan kecepatan Location.speed dalam m/s
    fun updateGpsSpeed(speedMps: Float) {
        val kmh = (speedMps * 3.6f).coerceAtLeast(0f)

        speedGps = kmh

        if (kmh > topSpeedGps) {
            topSpeedGps = kmh
        }
    }

    // Kompatibilitas jika pemanggil masih mengirim Location
    fun updateGpsSpeed(location: Location) {
        updateGpsSpeed(location.speed)
    }

    // =====================================================
    // RESET TOP SPEED
    // =====================================================

    fun resetTopEcu() {
        topSpeedEcu = 0f
        addLog("Top Speed ECU direset.")
    }

    fun resetTopGps() {
        topSpeedGps = 0f
        addLog("Top Speed GPS direset.")
    }

    // =====================================================
    // BIKE SELECTION
    // =====================================================

    fun selectBike(bike: BikeModel) {
        selectedBike = bike
    }

    // =====================================================
    // DISCONNECT
    // =====================================================

    fun disconnect() {
        stopPolling()

        operationJob?.cancel()
        operationJob = null

        kLineManager?.onLog = null
        kLineManager?.onDataReceived = null
        kLineManager?.onDtcReceived = null
        kLineManager?.onSensorDetailReceived = null

        kLineManager?.closePort()
        kLineManager = null

        setConnectionState(false)
    }

    override fun onCleared() {
        disconnect()
        super.onCleared()
    }
}
