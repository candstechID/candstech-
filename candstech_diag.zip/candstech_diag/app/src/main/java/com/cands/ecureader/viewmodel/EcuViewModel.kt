
package com.cands.ecureader.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {

    var kLineManager: HondaKLineManager? = null
        private set

    private var pollJob: Job? = null
    private var operationJob: Job? = null

    var isConnected by mutableStateOf(false)
        private set

    var isKontakOn by mutableStateOf(false)
        private set

    var isScanningDtc by mutableStateOf(false)
    var isScanningSensor by mutableStateOf(false)
        private set

    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)

    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    var ectVolt by mutableFloatStateOf(0.0f)
    var iat by mutableIntStateOf(0)
    var iatVolt by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var mapVolt by mutableFloatStateOf(0.0f)
    var batteryVolt by mutableFloatStateOf(0.0f)
    var afr by mutableFloatStateOf(0.0f)
    var o2Volt by mutableFloatStateOf(0.0f)
    var engineLoad by mutableFloatStateOf(0.0f)
    var iacv by mutableIntStateOf(0)
    var injectorMs by mutableFloatStateOf(0.0f)

    var dtcList by mutableStateOf<List<String>>(emptyList())
    var dtcMessage by mutableStateOf("")

    var sensorDetailList by mutableStateOf<List<SensorItem>>(emptyList())
    var showSensorDialog by mutableStateOf(false)

    var uiLogs by mutableStateOf("")
        private set

    private var lastDataTimestamp = 0L

    fun addLog(msg: String) {
        val time = SimpleDateFormat(
            "HH:mm:ss",
            Locale.getDefault()
        ).format(Date())

        val newLog = "[$time] $msg"

        val logs = uiLogs
            .split("\n")
            .filter { it.isNotBlank() }
            .toMutableList()

        logs.add(newLog)
        uiLogs = logs.takeLast(50).joinToString("\n")
    }

    fun selectBike(bike: BikeModel) {
        selectedBike = bike
    }

    fun resetTopEcu() {
        topSpeedEcu = 0
    }

    fun resetTopGps() {
        topSpeedGps = 0
    }

    /**
     * Pasang callback terlebih dahulu.
     *
     * Fungsi ini TIDAK otomatis menganggap ECU sudah terhubung.
     * Status koneksi baru diaktifkan setelah handshake berhasil
     * dan MainActivity memanggil setConnectionState(true).
     */
    fun initKLineListener(manager: HondaKLineManager) {
        stopPolling()

        kLineManager = manager
        isConnected = false
        isKontakOn = false
        lastDataTimestamp = 0L

        manager.onLog = { message ->
            viewModelScope.launch(Dispatchers.Main) {
                addLog(message)
            }
        }

        manager.onDataReceived = { data ->
            viewModelScope.launch(Dispatchers.Main) {
                lastDataTimestamp = System.currentTimeMillis()
                isKontakOn = true

                rpm = data.rpm

                if (data.tpsDeg.isFinite()) {
                    tpsDegrees = data.tpsDeg
                }

                if (data.tpsVolt.isFinite()) {
                    tpsVolt = data.tpsVolt
                }

                if (data.ect >= 0) {
                    ect = data.ect
                }

                if (data.ectVolt.isFinite()) {
                    ectVolt = data.ectVolt
                }

                if (data.iat >= 0) {
                    iat = data.iat
                }

                if (data.iatVolt.isFinite()) {
                    iatVolt = data.iatVolt
                }

                // Jangan mengganti data dashboard dengan nilai
                // -1 atau NaN yang menandakan data belum tersedia.
                if (data.mapKpa >= 0) {
                    mapKpa = data.mapKpa
                }

                if (data.mapVolt.isFinite()) {
                    mapVolt = data.mapVolt
                }

                if (data.battery.isFinite()) {
                    batteryVolt = data.battery
                }

                if (data.afr.isFinite()) {
                    afr = data.afr
                }

                if (data.o2Volt.isFinite()) {
                    o2Volt = data.o2Volt
                }

                if (data.engineLoad.isFinite()) {
                    engineLoad = data.engineLoad
                }

                if (data.iacv >= 0) {
                    iacv = data.iacv
                }

                if (data.injectorMs.isFinite()) {
                    injectorMs = data.injectorMs
                }

                if (data.speedKmh >= 0) {
                    speedEcu = data.speedKmh

                    if (speedEcu > topSpeedEcu) {
                        topSpeedEcu = speedEcu
                    }
                }
            }
        }

        manager.onSensorDetailReceived = { items ->
            viewModelScope.launch(Dispatchers.Main) {
                sensorDetailList = sensorDetailList + items
            }
        }

        manager.onDtcReceived = { dtcs ->
            viewModelScope.launch(Dispatchers.Main) {
                dtcList = dtcs

                dtcMessage = if (dtcs.isEmpty()) {
                    "Tidak Ada DTC Tersimpan"
                } else {
                    "${dtcs.size} Kode DTC Terdeteksi!"
                }
            }
        }

        addLog("Listener ECU siap. Menunggu handshake.")
    }

    /**
     * Dipanggil MainActivity setelah performFastInit().
     */
    fun setConnectionState(connected: Boolean) {
        isConnected = connected
        isKontakOn = connected

        if (connected) {
            lastDataTimestamp = System.currentTimeMillis()
            addLog("Komunikasi ECU berhasil diinisialisasi.")
        } else {
            lastDataTimestamp = 0L
            stopPolling()
            addLog("Koneksi ECU tidak aktif.")
        }
    }

    /**
     * Membaca tabel sensor secara berurutan.
     * Tidak mengirim perintah mentah yang tidak menunggu respons.
     */
    fun requestFullSensorData() {
        val manager = kLineManager ?: return

        if (!isConnected || isScanningSensor || isScanningDtc) {
            return
        }

        showSensorDialog = true
        sensorDetailList = emptyList()
        isScanningSensor = true

        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            try {
                addLog("Memulai pembacaan tabel sensor.")

                val tables = listOf(
                    0x11,
                    0x13,
                    0x20,
                    0xD1
                )

                for (table in tables) {
                    if (!isActive || !isConnected) break

                    val response = manager.requestLiveTable(table)

                    if (response == null) {
                        addLog(
                            "Tabel %02X tidak menerima respons.".format(table)
                        )
                    }

                    delay(100)
                }

                addLog("Pembacaan tabel sensor selesai.")

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                addLog("Kesalahan pembacaan sensor: ${e.message}")
            } finally {
                isScanningSensor = false
            }
        }
    }

    /**
     * Scan DTC menggunakan fungsi pembacaan DTC dari Manager.
     */
    fun scanDtc() {
        val manager = kLineManager ?: return

        if (!isConnected || isScanningDtc || isScanningSensor) {
            return
        }

        isScanningDtc = true
        dtcMessage = "Memindai DTC..."
        dtcList = emptyList()

        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            try {
                addLog("Memulai scan DTC.")

                val responses = manager.readDtcTables()

                if (responses.isEmpty()) {
                    dtcMessage = "Tidak ada respons DTC dari ECU."
                    addLog("Scan DTC belum mendapatkan respons.")
                } else {
                    addLog(
                        "Respons DTC diterima: ${responses.size} frame."
                    )
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dtcMessage = "Gagal membaca DTC."
                addLog("Kesalahan scan DTC: ${e.message}")
            } finally {
                isScanningDtc = false
            }
        }
    }

    /**
     * Clear DTC.
     *
     * Respons yang diterima belum otomatis membuktikan
     * bahwa ECU benar-benar menghapus seluruh DTC.
     */
    fun clearDtc() {
        val manager = kLineManager ?: return

        if (!isConnected || isScanningDtc || isScanningSensor) {
            return
        }

        isScanningDtc = true
        dtcMessage = "Mengirim perintah Clear DTC..."

        operationJob?.cancel()

        operationJob = viewModelScope.launch {
            try {
                addLog("Mengirim perintah Clear DTC.")

                val response = manager.clearDtcTable01()

                if (response != null) {
                    dtcMessage =
                        "Respons Clear DTC diterima. Silakan scan ulang untuk verifikasi."

                    addLog(
                        "Frame respons Clear DTC diterima. Penghapusan belum diverifikasi."
                    )
                } else {
                    dtcMessage =
                        "Tidak ada respons konfirmasi Clear DTC."

                    addLog("Clear DTC belum terkonfirmasi.")
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dtcMessage = "Kesalahan Clear DTC."
                addLog("Kesalahan Clear DTC: ${e.message}")
            } finally {
                isScanningDtc = false
            }
        }
    }

    /**
     * Manager yang tersedia belum memiliki implementasi
     * protokol Reset TP yang terverifikasi.
     *
     * Tidak mengirim perintah tebakan ke ECU.
     */
    fun resetTp() {
        if (!isConnected) return

        dtcMessage = "Reset TP belum tersedia pada protokol Manager."
        addLog("Reset TP tidak dikirim: command belum diverifikasi.")
    }

    /**
     * Polling serial:
     * satu request live data ditunggu sebelum request berikutnya.
     * Keep Alive juga menunggu giliran, tidak dikirim bersamaan.
     */
    fun startPolling() {
        val manager = kLineManager ?: return

        if (!isConnected) {
            addLog("Polling tidak dimulai: ECU belum terhubung.")
            return
        }

        pollJob?.cancel()

        pollJob = viewModelScope.launch {
            var keepAliveCounter = 0

            while (isActive) {
                if (!isConnected) break

                val busy =
                    isScanningDtc || isScanningSensor

                if (!busy && operationJob?.isActive != true) {
                    try {
                        val success = manager.requestLiveData()

                        if (!success) {
                            addLog("Live data tidak menerima respons.")
                        }

                        keepAliveCounter++

                        if (keepAliveCounter >= 10) {
                            val keepAliveOk = manager.sendKeepAlive()

                            if (!keepAliveOk) {
                                addLog("Keep Alive tidak mendapat ACK.")
                            }

                            keepAliveCounter = 0
                        }

                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        addLog("Kesalahan polling: ${e.message}")
                    }
                }

                if (
                    lastDataTimestamp > 0L &&
                    System.currentTimeMillis() - lastDataTimestamp > 2500L
                ) {
                    isKontakOn = false
                }

                delay(150)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        pollJob = null

        isKontakOn = false
    }

    /**
     * Putuskan koneksi dan lepaskan callback.
     */
    fun disconnect() {
        stopPolling()

        operationJob?.cancel()
        operationJob = null

        isConnected = false
        isKontakOn = false

        kLineManager?.closePort()
        kLineManager = null

        addLog("Koneksi ECU diputus.")
    }

    /**
     * GPS speed dalam km/h.
     * Nilai speed berasal dari Location.speed dalam m/s.
     */
    fun updateGpsSpeed(speed: Float) {
        if (!speed.isFinite() || speed < 0f) return

        val kmh = (speed * 3.6f).toInt()

        speedGps = kmh

        if (kmh > topSpeedGps) {
            topSpeedGps = kmh
        }
    }

    override fun onCleared() {
        pollJob?.cancel()
        operationJob?.cancel()

        kLineManager?.closePort()
        kLineManager = null

        super.onCleared()
    }
}
