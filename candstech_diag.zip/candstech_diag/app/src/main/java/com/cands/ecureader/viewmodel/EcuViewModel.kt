package com.cands.ecureader.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.*
import kotlinx.coroutines.*

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null

    var isConnected by mutableStateOf(false)
    var isKontakOn by mutableStateOf(false)
    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)

    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    var ectVolt by mutableFloatStateOf(0.0f)
    var iat by mutableIntStateOf(0)
    var iatVolt by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var mapVolt by mutableFloatStateOf(0.0f)
    var batteryVolt by mutableFloatStateOf(0.0f)
    var afr by mutableFloatStateOf(0.0f)
    var o2Volt by mutableFloatStateOf(0.0f)
    var engineLoad by mutableFloatStateOf(0.0f)
    var iacv by mutableIntStateOf(0)
    var injectorMs by mutableFloatStateOf(0.0f)

    var isScanningDtc by mutableStateOf(false)
    val dtcList = mutableStateListOf<String>()

    private var lastDataTimestamp = System.currentTimeMillis()

    fun selectBike(bike: BikeModel) {
        selectedBike = bike
    }

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        isConnected = true
        isKontakOn = true
        lastDataTimestamp = System.currentTimeMillis()

        manager.onDataReceived = { data ->
            isKontakOn = true
            lastDataTimestamp = System.currentTimeMillis()
            
            rpm = data.rpm
            tpsDegrees = data.tpsDeg
            tpsVolt = data.tpsVolt
            ect = data.ect
            ectVolt = data.ectVolt
            iat = data.iat
            iatVolt = data.iatVolt
            mapKpa = data.mapKpa
            mapVolt = data.mapVolt
            batteryVolt = data.battery
            afr = data.afr
            o2Volt = data.o2Volt
            engineLoad = data.engineLoad
            iacv = data.iacv
            injectorMs = data.injectorMs
            
            speedEcu = (rpm / 150).coerceIn(0, 160) 
            if (speedEcu > topSpeedEcu) topSpeedEcu = speedEcu
        }
    }

    fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (isActive) {
                if (isConnected && System.currentTimeMillis() - lastDataTimestamp > 2500) {
                    isKontakOn = false // Timeout jika data putus
                }
                if (!isScanningDtc && isConnected) {
                    kLineManager?.sendCommand(kLineManager?.CMD_LIVE_DATA ?: break)
                    kLineManager?.pollEngineData()
                }
                delay(100) // Polling 100ms agar ECU tidak drop (Keep-Alive)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        isConnected = false
        isKontakOn = false
    }

    fun resetTopEcu() { topSpeedEcu = 0 }
    fun resetTopGps() { topSpeedGps = 0 }
    
    fun updateGpsSpeed(speed: Float) {
        val kmh = (speed * 3.6f).toInt()
        speedGps = kmh
        if (kmh > topSpeedGps) topSpeedGps = kmh
    }
}
