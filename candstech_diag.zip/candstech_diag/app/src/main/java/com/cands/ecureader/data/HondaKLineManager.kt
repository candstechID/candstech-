package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)
    
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.setDTR(false)
        serialPort.setRTS(false)
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Init KWP2000 (70ms LOW)")
            serialPort.setBaudRate(128)
            serialPort.write(byteArrayOf(0x00))
            delay(100) 
            
            serialPort.setBaudRate(10400)
            delay(120)
            
            serialPort.write(CMD_WAKEUP)
            delay(200)
            
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP)
            return@withContext true
        } catch (e: Exception) {
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    // NEW SMART BUFFER LOGIC: NO MORE FRAGMENTATION!
    fun pollEngineData() {
        // Hapus sampah: Cari byte 0x02 (Header balasan standar dari ECU ke Tester)
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) {
            rxQueue.poll()
        }

        // Jika ada minimal 2 byte, kita bisa baca panjang (length) paketnya
        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF // KWP2000 nyimpen panjang paket di byte ke-2

            // Pastikan panjang masuk akal (hindari crash)
            if (expectedLength in 4..50) {
                // Tunggu sampai semua byte masuk sepenuhnya sebelum diproses!
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) {
                        buffer[i] = rxQueue.poll()!!
                    }
                    parseHondaResponse(buffer)
                }
            } else {
                // Byte rusak, buang byte pertama agar bisa mencari header 0x02 selanjutnya
                rxQueue.poll()
            }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val destAddress = data.getOrNull(0)?.toInt()?.and(0xFF) ?: 0
            val length = data.getOrNull(1)?.toInt()?.and(0xFF) ?: 0
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            // KWP2000 Table 0x10 parsing (Length is usually 22 -> 0x16)
            if (responseType == 0x71 && data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && data.size >= 21) {
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineLoad = (tpsPercentRaw / 255.0f) * 100f
                val afr = 14.7f
                val o2Volt = 0.0f
                val iacv = 0
                val injectorMs = 0.0f

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, afr = afr, o2Volt = o2Volt,
                    engineLoad = engineLoad, iacv = iacv, injectorMs = injectorMs
                )
                onDataReceived?.invoke(engineData)
            }
            // Fast Init Wakeup Ack
            else if (destAddress == 0x02 && length == 0x04 && responseType == 0x00) {
                 Log.d(TAG, "ECU Awake confirmed via 0x02 0x04 0x00 0xFA")
                 onDataReceived?.invoke(EngineData(0, 0f, 0f, 40, 0f, 30, 0f, 0, 0f, 12f, 14.7f, 0f, 0f, 0, 0f))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parsing Error: ${e.message}")
        }
    }
}
