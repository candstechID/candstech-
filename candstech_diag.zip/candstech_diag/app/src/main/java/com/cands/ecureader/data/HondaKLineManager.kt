package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float,
    val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float,
    val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    val CMD_LIVE_DATA = byteArrayOf(0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0xFA.toByte())
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    val CMD_TEST_FUEL_PUMP = byteArrayOf(0x02, 0x04, 0x70, 0x01, 0x89.toByte())
    val CMD_TEST_FAN = byteArrayOf(0x02, 0x04, 0x70, 0x02, 0x88.toByte())
    val CMD_TEST_INJ = byteArrayOf(0x02, 0x04, 0x70, 0x03, 0x87.toByte())
    val CMD_TEST_COIL = byteArrayOf(0x02, 0x04, 0x70, 0x04, 0x86.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        // Konfigurasi dasar sebelum hack baudrate
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        // Matikan DTR dan RTS agar tidak mengganggu sinyal K-Line
        serialPort.setDTR(false)
        serialPort.setRTS(false)
        
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Memulai Fast Init K-Line (Trik 360 Baud untuk presisi 25ms LOW)")
            
            // 1. Trik Baudrate: Set ke 360 baud
            // Mengirim 1 byte 0x00 pada 360 baud (8N1) = 9 bit LOW. 
            // Waktu = 9 / 360 = 0.025 detik = 25ms tepat di level hardware!
            serialPort.setBaudRate(360)
            serialPort.write(byteArrayOf(0x00))
            
            // Tunggu 50ms (25ms untuk byte terkirim + 25ms jeda sinyal HIGH)
            delay(50) 
            
            // 2. Kembalikan ke Baudrate ECU (10400)
            serialPort.setBaudRate(10400)
            delay(20) // Waktu agar clock UART stabil
            
            rxQueue.clear()
            serialPort.write(CMD_LIVE_DATA)
            Log.d(TAG, "Fast Init Sukses, menunggu respon ECU...")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Fast Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        Log.d(TAG, "Mengirim Command: ${command.joinToString("") { "%02x ".format(it) }}")
        serialPort.write(command)
    }

    fun pollEngineData() {
        if (rxQueue.size >= 10) {
            val buffer = mutableListOf<Byte>()
            while (rxQueue.isNotEmpty()) {
                buffer.add(rxQueue.poll() ?: break)
            }
            parseHondaResponse(buffer.toByteArray())
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            if (responseType == 0x00 && data.size >= 15) {
                val byteA = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
                val byteB = data.getOrNull(3)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = ((byteA * 256) + byteB) / 4

                val tpsRaw = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsRaw / 255f) * 5.0f
                val tpsDegrees = ((tpsVolt - 0.45f) / (4.5f - 0.45f)).coerceIn(0f, 85f) * 80f

                val ectRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 40
                val ect = ectRaw - 40
                val ectVolt = (ectRaw / 255f) * 5.0f

                val mapRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 30
                val mapKpa = mapRaw
                val mapVolt = (mapRaw / 255f) * 5.0f

                val battRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                val engineLoad = (tpsRaw / 255.0f) * 100f

                val iatRaw = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 70
                val iat = iatRaw - 40
                val iatVolt = (iatRaw / 255f) * 5.0f
                
                val afrRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 147
                val afr = afrRaw / 10.0f
                
                val iacv = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 0
                
                val injRaw1 = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val injRaw2 = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0
                val injectorMs = ((injRaw1 * 256) + injRaw2) * 0.001f
                
                val o2Raw = data.getOrNull(14)?.toInt()?.and(0xFF) ?: 0
                val o2Volt = (o2Raw / 255f) * 5.0f

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ect, ectVolt = ectVolt,
                    iat = iat, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt,
                    battery = battery, afr = afr, o2Volt = o2Volt,
                    engineLoad = engineLoad, iacv = iacv, injectorMs = injectorMs
                )
                onDataReceived?.invoke(engineData)
            }
            else if (responseType == 0x10) {
                val dtcCount = data.getOrNull(3)?.toInt()?.and(0xFF) ?: 0
                val codes = mutableListOf<String>()
                if (dtcCount == 0) {
                    codes.add("Sistem Normal (Tidak Ada Kerusakan)")
                } else {
                    for (i in 0 until dtcCount) {
                        val errorCode = data.getOrNull(4 + (i * 2))?.toInt()?.and(0xFF) ?: 0
                        codes.add(getDtcDescription(errorCode))
                    }
                }
                onDtcReceived?.invoke(codes)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gagal parsing data ECU: ${e.message}")
        }
    }
    
    private fun getDtcDescription(code: Int): String {
        return when (code) {
            7 -> "DTC 7: Sensor EOT / ECT (Suhu Mesin)"
            8 -> "DTC 8: Sensor TP (Bukaan Gas)"
            9 -> "DTC 9: Sensor IAT (Suhu Udara)"
            11 -> "DTC 11: Sensor VS (Kecepatan)"
            12 -> "DTC 12: Injektor (Rangkaian Malfungsi)"
            21 -> "DTC 21: Sensor O2 (Oksigen)"
            29 -> "DTC 29: IACV (Idle Air Control Valve)"
            33 -> "DTC 33: ECM (EEPROM Error)"
            52 -> "DTC 52: Sensor CKP (Crank Position)"
            54 -> "DTC 54: Bank Angle Sensor"
            else -> "DTC $code: Unknown Error Code"
        }
    }
}
