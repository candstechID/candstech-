package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Honda PGM-FI K-Line communication based on the two protocol reference posters
 * supplied by the user.
 *
 * Important:
 * - Wake-up timing and command bytes follow the supplied reference.
 * - The actual ECU family must be verified before relying on scaling/table layouts.
 * - This class does not implement ROM read/write or remapping.
 */
data class EngineData(
    val rpm: Int,
    val tpsDeg: Float,
    val tpsVolt: Float,
    val ect: Int,
    val ectVolt: Float,
    val iat: Int,
    val iatVolt: Float,
    val mapKpa: Int,
    val mapVolt: Float,
    val battery: Float,
    val afr: Float,
    val o2Volt: Float,
    val engineLoad: Float,
    val iacv: Int,
    val injectorMs: Float,
    val speedKmh: Int
)

data class SensorItem(
    val category: String,
    val name: String,
    val value: String,
    val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val tag = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private val rxBuffer = mutableListOf<Byte>()
    private val txLock = Any()

    @Volatile
    private var portOpened = false

    @Volatile
    private var sessionStarted = false

    @Volatile
    private var keepAliveRunning = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onRawFrameReceived: ((ByteArray) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // Poster 2: START COMMUNICATION
    // REQ: FE 04 72 8C
    // RES: 0E 04 72 7C
    private val cmdStartCommunication = byteArrayOf(
        0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()
    )

    // Poster 2: KEEP ALIVE
    // REQ: 72 05 00 F0 99
    // RES: 02 04 00 FA
    private val cmdKeepAlive = byteArrayOf(
        0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()
    )

    // Poster 1: Query 71, Table 10
    private val cmdLiveData = byteArrayOf(
        0x72, 0x05, 0x71, 0x10, 0x08
    )

    private val readCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (byteValue in data) {
                rxQueue.offer(byteValue)
            }
        }
    }

    fun setupPort() {
        try {
            onLog?.invoke("Membuka USB serial 10400 baud...")
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.read(readCallback)
            portOpened = true
            onLog?.invoke("Port terbuka. Format serial: 10400, 8N1.")
        } catch (e: Exception) {
            portOpened = false
            onLog?.invoke("Gagal membuka port: ${e.message}")
            Log.e(tag, "setupPort failed", e)
        }
    }

    fun closePort() {
        try {
            keepAliveRunning = false
            sessionStarted = false
            portOpened = false
            serialPort.close()
            onLog?.invoke("Port ditutup.")
        } catch (e: Exception) {
            onLog?.invoke("Kesalahan saat menutup port: ${e.message}")
        }
    }

    private fun hex(data: ByteArray): String =
        data.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun logRx(data: ByteArray) {
        if (data.isNotEmpty()) {
            onLog?.invoke("RX: ${hex(data)}")
            onRawFrameReceived?.invoke(data.copyOf())
        }
    }

    /**
     * Checksum from poster 1:
     * CS = 0x100 - (SUM(DATA) AND 0xFF)
     *
     * 'length' is the number of bytes included in the sum.
     */
    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length.coerceAtMost(data.size)) {
            sum += data[i].toInt() and 0xFF
        }
        return ((0x100 - (sum and 0xFF)) and 0xFF).toByte()
    }

    private fun buildQuery(query: Int, table: Int): ByteArray {
        val frame = byteArrayOf(
            0x72,
            0x05,
            query.toByte(),
            table.toByte(),
            0x00
        )
        frame[4] = calculateChecksum(frame, 4)
        return frame
    }

    private fun clearRx() {
        rxQueue.clear()
        rxBuffer.clear()
    }

    private fun writeFrame(frame: ByteArray) {
        synchronized(txLock) {
            onLog?.invoke("TX: ${hex(frame)}")
            serialPort.write(frame)
        }
    }

    /**
     * Collect bytes until the requested fixed response is found or timeout.
     * This tolerates fragmented USB reads and ignores bytes preceding the ACK.
     */
    private suspend fun waitForExactResponse(
        expected: ByteArray,
        timeoutMs: Long = 1500
    ): ByteArray? {
        val received = mutableListOf<Byte>()
        val start = System.currentTimeMillis()

        while (System.currentTimeMillis() - start < timeoutMs) {
            while (true) {
                val next = rxQueue.poll() ?: break
                received.add(next)

                while (received.size > expected.size) {
                    received.removeAt(0)
                }

                if (received.size == expected.size &&
                    received.indices.all { received[it] == expected[it] }
                ) {
                    val response = received.toByteArray()
                    logRx(response)
                    return response
                }
            }
            delay(5)
        }

        if (received.isNotEmpty()) {
            onLog?.invoke("RX tidak cocok: ${hex(received.toByteArray())}")
        } else {
            onLog?.invoke("Timeout: tidak ada respons ECU.")
        }
        return null
    }

    /**
     * Reads a variable response frame using the poster's normal response layout:
     * 02, LEN, QUERY, TABLE, DATA..., CHECKSUM
     *
     * The posters also show a special 4-byte keep-alive response, handled
     * separately by waitForExactResponse().
     */
    private suspend fun readDataFrame(timeoutMs: Long = 1200): ByteArray? {
        val start = System.currentTimeMillis()
        val bytes = mutableListOf<Byte>()

        while (System.currentTimeMillis() - start < timeoutMs) {
            while (true) {
                val b = rxQueue.poll() ?: break
                bytes.add(b)
            }

            // Find response header 0x02.
            val headerIndex = bytes.indexOfFirst { (it.toInt() and 0xFF) == 0x02 }
            if (headerIndex > 0) {
                repeat(headerIndex) { bytes.removeAt(0) }
            }

            if (bytes.size >= 2) {
                val lengthField = bytes[1].toInt() and 0xFF

                // Honda response LEN is the total frame size, including header
                // and checksum. Example: 02 05 71 10 78 is exactly 5 bytes.
                val totalLength = lengthField

                if (lengthField in 4..0x40 && totalLength in 4..64) {
                    if (bytes.size >= totalLength) {
                        val frame = ByteArray(totalLength) { bytes[it] }
                        repeat(totalLength) { bytes.removeAt(0) }
                        logRx(frame)
                        return frame
                    }
                } else {
                    // Drop invalid leading byte and resynchronize.
                    bytes.removeAt(0)
                }
            }
            delay(5)
        }

        if (bytes.isNotEmpty()) {
            onLog?.invoke("Frame data timeout. Buffer: ${hex(bytes.toByteArray())}")
        } else {
            onLog?.invoke("Timeout menunggu frame data.")
        }
        return null
    }

    /**
     * Wake-up follows poster 2:
     * TX LOW 70 ms, TX HIGH 120 ms, then 10400 bps.
     *
     * On USB-UART adapters, setBreak() controls UART BREAK. Verify with an
     * oscilloscope/logic analyzer that this produces the required physical
     * K-Line wake-up waveform through the actual interface circuit.
     */
    private suspend fun performWakeUp(): Boolean {
        return try {
            clearRx()
            onLog?.invoke("WAKE UP: TX LOW 70 ms")
            serialPort.setBreak(true)
            delay(70)

            onLog?.invoke("WAKE UP: TX HIGH 120 ms")
            serialPort.setBreak(false)
            delay(120)

            true
        } catch (e: Exception) {
            onLog?.invoke("Wake-up gagal: ${e.message}")
            false
        }
    }

    /**
     * Sequence from supplied poster:
     * 1) Wake up: LOW 70 ms, HIGH 120 ms
     * 2) Start communication: FE 04 72 8C -> 0E 04 72 7C
     * 3) Keep alive: 72 05 00 F0 99 -> 02 04 00 FA
     */
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!portOpened) {
                onLog?.invoke("Port belum dibuka. Panggil setupPort() dahulu.")
                return@withContext false
            }

            sessionStarted = false
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)

            // Step 1: Wake-up
            if (!performWakeUp()) return@withContext false

            // Step 2: Start communication
            clearRx()
            onLog?.invoke("Mengirim START COMMUNICATION...")
            writeFrame(cmdStartCommunication)

            val startAck = waitForExactResponse(
                byteArrayOf(0x0E, 0x04, 0x72, 0x7C),
                1500
            )

            if (startAck == null) {
                onLog?.invoke("START COMMUNICATION GAGAL.")
                return@withContext false
            }

            onLog?.invoke("START COMMUNICATION berhasil.")

            // Step 3: Keep alive
            clearRx()
            onLog?.invoke("Mengirim KEEP ALIVE...")
            writeFrame(cmdKeepAlive)

            val keepAliveAck = waitForExactResponse(
                byteArrayOf(0x02, 0x04, 0x00, 0xFA.toByte()),
                1500
            )

            if (keepAliveAck == null) {
                onLog?.invoke("KEEP ALIVE gagal.")
                return@withContext false
            }

            sessionStarted = true
            onLog?.invoke("ECU SESSION AKTIF.")
            true

        } catch (e: Exception) {
            sessionStarted = false
            onLog?.invoke("Error inisialisasi: ${e.message}")
            Log.e(tag, "performFastInit failed", e)
            false
        }
    }

    /**
     * Send a query 71 table. Table numbers are based on poster 1.
     * Examples: 10, 11, 13, 17, 20, 21, D1.
     */
    suspend fun requestLiveTable(table: Int): ByteArray? =
        withContext(Dispatchers.IO) {
            if (!sessionStarted) {
                onLog?.invoke("Sesi ECU belum aktif. Jalankan performFastInit().")
                return@withContext null
            }

            clearRx()
            val request = buildQuery(0x71, table)
            writeFrame(request)
            val frame = readDataFrame()
            if (frame != null) parseHondaResponse(frame)
            frame
        }

    /**
     * Table 0x10 pada referensi dapat dijawab ECU dengan frame unsupported
     * 02 05 71 10 78. Jika tidak menghasilkan data terpetakan, coba Table 0x17.
     */
    suspend fun requestLiveData(): Boolean = withContext(Dispatchers.IO) {
        if (!sessionStarted) {
            onLog?.invoke("Sesi ECU belum aktif.")
            return@withContext false
        }

        val first = requestLiveTable(0x10)
        if (first != null && HondaProtocolParser.parseLive(first)?.hasLiveValues() == true) {
            return@withContext true
        }

        onLog?.invoke("Table 10 tidak menyediakan data live; mencoba Table 17...")
        val fallback = requestLiveTable(0x17)
        fallback != null && HondaProtocolParser.parseLive(fallback)?.hasLiveValues() == true
    }

    /**
     * Poster 2: Read stored DTC uses Query 73, tables 01/02/03.
     * Responses should be checked against the ECU-specific reference.
     */
    suspend fun readDtcTables(): List<ByteArray> =
        withContext(Dispatchers.IO) {
            if (!sessionStarted) {
                onLog?.invoke("Sesi ECU belum aktif.")
                return@withContext emptyList()
            }

            val results = mutableListOf<ByteArray>()
            for (table in 0x01..0x03) {
                clearRx()
                val request = buildQuery(0x73, table)
                writeFrame(request)
                val response = readDataFrame(1500)
                if (response != null) {
                    results.add(response)
                    parseHondaResponse(response)
                }
                delay(40)
            }
            results
        }

    /**
     * Poster 2: current DTC uses Query 74, tables 01/02/03.
     */
    suspend fun readCurrentDtcTables(): List<ByteArray> =
        withContext(Dispatchers.IO) {
            if (!sessionStarted) {
                onLog?.invoke("Sesi ECU belum aktif.")
                return@withContext emptyList()
            }

            val results = mutableListOf<ByteArray>()
            for (table in 0x01..0x03) {
                clearRx()
                val request = buildQuery(0x74, table)
                writeFrame(request)
                val response = readDataFrame(1500)
                if (response != null) {
                    results.add(response)
                    parseHondaResponse(response)
                }
                delay(40)
            }
            results
        }

    /**
     * Poster 2 clear DTC example: Query 60, Table 01.
     * Clearing DTC changes ECU diagnostic state; invoke only intentionally.
     */
    suspend fun clearDtcTable01(): ByteArray? =
        withContext(Dispatchers.IO) {
            if (!sessionStarted) {
                onLog?.invoke("Sesi ECU belum aktif.")
                return@withContext null
            }

            clearRx()
            val request = buildQuery(0x60, 0x01)
            writeFrame(request)
            waitForExactResponse(
                byteArrayOf(0x02, 0x05, 0x60, 0x01, 0x98.toByte()),
                1500
            )
        }

    /**
     * RESET TP / ECM initialization: Query 60 Table 03.
     * User must ensure engine OFF and throttle fully closed before calling.
     */
    suspend fun resetTp(): ByteArray? = withContext(Dispatchers.IO) {
        if (!sessionStarted) {
            onLog?.invoke("Sesi ECU belum aktif.")
            return@withContext null
        }

        clearRx()
        val request = buildQuery(0x60, 0x03)
        writeFrame(request)
        waitForExactResponse(
            byteArrayOf(0x02, 0x05, 0x60, 0x03, 0x96.toByte()),
            1500
        )
    }

    /**
     * Send keep-alive periodically from the caller while the diagnostic session
     * is active. This function sends one keep-alive request and checks its ACK.
     */
    suspend fun sendKeepAlive(): Boolean =
        withContext(Dispatchers.IO) {
            if (!sessionStarted) return@withContext false

            clearRx()
            writeFrame(cmdKeepAlive)

            val response = waitForExactResponse(
                byteArrayOf(0x02, 0x04, 0x00, 0xFA.toByte()),
                1000
            )
            response != null
        }

    fun sendCommand(command: ByteArray) {
        if (!portOpened) {
            onLog?.invoke("Port belum terbuka.")
            return
        }
        writeFrame(command)
    }

    /**
     * Validate normal response checksum.
     * For poster data frames, checksum is the final byte and all preceding
     * bytes in the response frame are included in the sum.
     */
    private fun isValidResponseChecksum(frame: ByteArray): Boolean {
        if (frame.size < 4) return false
        val expected = calculateChecksum(frame, frame.size - 1)
        return expected == frame.last()
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (!HondaProtocolParser.isValidFrame(data)) {
            onLog?.invoke("Frame respons tidak valid (header/LEN/checksum): ${hex(data)}")
            return
        }

        try {
            val responseType = u(data, 2)
            val tableId = u(data, 3)

            if (responseType == 0x73 || responseType == 0x74) {
                val parsed = HondaProtocolParser.parseDtc(data)
                val codes = parsed.map { "${it.code} — ${it.description}" }
                onDtcReceived?.invoke(codes)
                onLog?.invoke(
                    "DTC response Query %02X Table %02X: %s".format(
                        responseType, tableId,
                        if (codes.isEmpty()) "tidak ada kode pada frame ini"
                        else parsed.joinToString(", ") { it.code }
                    )
                )
                return
            }

            if (responseType != 0x71) {
                onLog?.invoke("Query respons tidak dikenal: %02X".format(responseType))
                return
            }

            val parsed = HondaProtocolParser.parseLive(data)
            if (parsed == null) {
                onSensorDetailReceived?.invoke(
                    listOf(SensorItem("TABEL %02X".format(tableId), "Raw response", hex(data)))
                )
                onLog?.invoke("Table %02X valid tetapi belum memiliki payload live yang dapat dipetakan.".format(tableId))
                return
            }

            val unavailable = Float.NaN
            onDataReceived?.invoke(
                EngineData(
                    rpm = parsed.rpm ?: -1,
                    tpsDeg = parsed.tpsDeg ?: unavailable,
                    tpsVolt = parsed.tpsVolt ?: unavailable,
                    ect = parsed.ect ?: -999,
                    ectVolt = parsed.ectVolt ?: unavailable,
                    iat = parsed.iat ?: -999,
                    iatVolt = parsed.iatVolt ?: unavailable,
                    mapKpa = parsed.mapKpa ?: -1,
                    mapVolt = parsed.mapVolt ?: unavailable,
                    battery = parsed.battery ?: unavailable,
                    afr = unavailable,
                    o2Volt = parsed.o2Volt ?: unavailable,
                    engineLoad = unavailable,
                    iacv = -1,
                    injectorMs = parsed.injectorMs ?: unavailable,
                    speedKmh = parsed.speedKmh ?: -1
                )
            )

            val sensors = mutableListOf<SensorItem>()
            fun add(name: String, value: Any?, voltage: Float? = null) {
                if (value == null) return
                sensors += SensorItem(
                    "TABEL %02X".format(tableId), name, value.toString(),
                    voltage?.takeIf { it.isFinite() }?.let { "%.2f V".format(it) } ?: "--"
                )
            }
            add("RPM", parsed.rpm)
            add("TPS", parsed.tpsDeg?.let { "%.1f°".format(it) }, parsed.tpsVolt)
            add("ECT", parsed.ect?.let { "$it °C" }, parsed.ectVolt)
            add("IAT", parsed.iat?.let { "$it °C" }, parsed.iatVolt)
            add("MAP", parsed.mapKpa?.let { "$it kPa" }, parsed.mapVolt)
            add("Battery", parsed.battery?.let { "%.1f V".format(it) })
            add("Injector", parsed.injectorMs?.let { "%.2f ms".format(it) })
            add("Ignition", parsed.ignitionDeg?.let { "%.1f°".format(it) })
            add("Speed", parsed.speedKmh?.let { "$it km/h" })
            add("O2", parsed.o2Volt?.let { "%.3f V".format(it) })
            add("STFT", parsed.stft)
            add("O2 Heater", parsed.o2HeaterVolt?.let { "%.3f V".format(it) })
            add("Fast Idle", parsed.fastIdle)
            add("Status", parsed.statusText)
            add("Fuel Pump", parsed.fuelPumpOn)
            add("Cooling Fan", parsed.coolingFanOn)
            if (sensors.isEmpty()) sensors += SensorItem("TABEL %02X".format(tableId), "Raw response", hex(data))
            onSensorDetailReceived?.invoke(sensors)
        } catch (e: Exception) {
            Log.e(tag, "Error parsing response", e)
            onLog?.invoke("Error parsing: ${e.message}")
        }
    }

    private fun u(data: ByteArray, index: Int): Int =
        data[index].toInt() and 0xFF

    private fun HondaParsedData.hasLiveValues(): Boolean =
        rpm != null || tpsDeg != null || tpsVolt != null || ect != null ||
            iat != null || mapKpa != null || battery != null ||
            injectorMs != null || speedKmh != null || o2Volt != null ||
            statusText != null

}
