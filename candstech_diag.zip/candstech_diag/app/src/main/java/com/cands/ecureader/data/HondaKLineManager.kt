package com.cands.ecureader.data

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class HondaKLineManager(private val usbManager: UsbManager) {
    private var serialDevice: UsbSerialDevice? = null
    private var connection: UsbDeviceConnection? = null
    var isConnected: Boolean = false
        private set

    suspend fun connect(device: UsbDevice): Boolean = withContext(Dispatchers.IO) {
        try {
            connection = usbManager.openDevice(device)
            if (connection == null) return@withContext false

            val deviceInstance = UsbSerialDevice.createUsbSerialDevice(device, connection)
            serialDevice = deviceInstance
            
            if (deviceInstance == null || !deviceInstance.open()) {
                connection?.close()
                return@withContext false
            }

            // Baud rate standar K-Line Honda PGM-FI: 10400
            deviceInstance.setBaudRate(10400)
            deviceInstance.setDataBits(UsbSerialInterface.DATA_BITS_8)
            deviceInstance.setStopBits(UsbSerialInterface.STOP_BITS_1)
            deviceInstance.setParity(UsbSerialInterface.PARITY_NONE)
            deviceInstance.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            
            delay(50)

            // 1. Lakukan Fast Initialization (Tarik K-Line ke Low beberapa milidetik sesuai catatan remap)
            deviceInstance.setBreak(true)
            delay(50)
            deviceInstance.setBreak(false)
            delay(100)

            // 2. Kirim Header Wake-up / Start Diagnostic Session KWP2000 Honda
            val startSession = hexStringToByteArray("81 11 F1 81 02") // atau FE 04 72 8C
            deviceInstance.syncWrite(startSession, 300)
            delay(50)

            isConnected = true
            true
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Connection error", e)
            disconnect()
            false
        }
    }

    suspend fun requestLiveData(): Map<String, Any> = withContext(Dispatchers.IO) {
        val result = mutableMapOf<String, Any>(
            "rpm" to "0",
            "tps" to "0°",
            "temp" to "--°C",
            "voltage" to "13.2 V",
            "map" to "30 kPa",
            "iat" to "29°C",
            "iacv" to "15 %",
            "injector" to "2.5 ms"
        )
        val device = serialDevice
        if (!isConnected || device == null) return@withContext result

        try {
            // Menggunakan Service ID ReadDataByLocalIdentifier (0x21) atau PID Live Data Honda berformat KWP2000 (82 11 F1 21 01 XX)
            // Contoh request PID 21 01 dengan checksum kalkulasi sederhana
            val requestBytes = hexStringToByteArray("82 11 F1 21 01 A5")
            device.syncWrite(requestBytes, 300)

            val buffer = ByteArray(128)
            val bytesRead = device.syncRead(buffer, 300)
            if (bytesRead > 0) {
                val response = buffer.copyOfRange(0, bytesRead)
                Log.d("HondaKLineManager", "ECU Response (${response.size}): ${response.contentToString()}")
                
                // Parsing respons KWP2000 positif (biasanya 0x61 adalah respon dari 0x21)
                if (response.size >= 10 && (response[3].toInt() and 0xFF) == 0x61) {
                    val rawRpm = ((response[5].toInt() and 0xFF) shl 8) or (response[6].toInt() and 0xFF)
                    if (rawRpm > 0) {
                        result["rpm"] = (rawRpm / 4).toString()
                    }
                    val rawTps = response[7].toInt() and 0xFF
                    result["tps"] = "$rawTps°"
                }
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Error reading live data", e)
        }
        return@withContext result
    }

    suspend fun sendCommand(hexCommand: String): ByteArray? = withContext(Dispatchers.IO) {
        val device = serialDevice
        if (!isConnected || device == null) return@withContext null
        try {
            val bytes = hexStringToByteArray(hexCommand)
            device.syncWrite(bytes, 1000)
            val buffer = ByteArray(64)
            val n = device.syncRead(buffer, 500)
            if (n > 0) return@withContext buffer.copyOfRange(0, n)
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Command error", e)
        }
        return@withContext null
    }

    fun disconnect() {
        try {
            serialDevice?.close()
            connection?.close()
        } catch (_: Exception) {}
        serialDevice = null
        connection = null
        isConnected = false
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val clean = s.replace(" ", "")
        val len = clean.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(clean[i], 16) shl 4) + Character.digit(clean[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
