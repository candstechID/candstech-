package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

// Data class dasar untuk UI utama
data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val speedKmh: Int
)

// BARU: Format data untuk dialog detail (Nama, Nilai, Voltase)
data class SensorItem(
    val category: String,
    val name: String,
    val value: String,
    val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val TAG = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null

    // Command Dasar
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08) // Tabel 10

    // Command Tabel Tambahan (Sesuai Dokumen SMK)
    val CMD_T11 = byteArrayOf(0x72, 0x05, 0x71, 0x11, 0x07) // Injector & Voltase
    val CMD_T13 = byteArrayOf(0x72, 0x05, 0x71, 0x13, 0x05) // Ignition Timing
    val CMD_T20 = byteArrayOf(0x72, 0x05, 0x71, 0x20, 0xF8) // O2 Sensor & STFT
    val CMD_TD1 = byteArrayOf(0x72, 0x05, 0x71, 0xD1, 0x47) // Status Komponen

    // Diagnostik
    val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)
    val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) for (b in data) rxQueue.add(b)
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
    }

    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length) sum += data[i].toInt() and 0xFF
        return (0x100 - (sum and 0xFF)).toByte()
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            serialPort.setBreak(true); delay(70)
            serialPort.setBreak(false); delay(120)
            serialPort.write(CMD_WAKEUP); delay(50)
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP); delay(100)
            return@withContext true
        } catch (e: Exception) { return@withContext false }
    }

    fun sendCommand(command: ByteArray) { serialPort.write(command) }

    fun pollEngineData() {
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) rxQueue.poll()
        if (rxQueue.size >= 2) {
            val expectedLength = rxQueue.toList()[1].toInt() and 0xFF
            if (expectedLength in 5..60 && rxQueue.size >= expectedLength) {
                val buffer = ByteArray(expectedLength)
                for (i in 0 until expectedLength) buffer[i] = rxQueue.poll()!!
                if (calculateChecksum(buffer, expectedLength - 1) == buffer[expectedLength - 1]) {
                    parseHondaResponse(buffer)
                }
            } else if (expectedLength !in 5..60) { rxQueue.poll() }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val resType = data[2].toInt() and 0xFF
            val tableId = data[3].toInt() and 0xFF
            val sensorList = mutableListOf<SensorItem>()

            // 1. TABEL 10 (Data Utama)
            if (resType == 0x71 && tableId == 0x10 && data.size >= 22) {
                val rpm = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
                val tpsV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val tpsD = (data[7].toInt() and 0xFF) * 0.5f
                val ectV = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                val ect = (data[9].toInt() and 0xFF) - 40
                val iatV = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                val iat = (data[11].toInt() and 0xFF) - 40
                val mapV = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapKpa = data[13].toInt() and 0xFF
                val bat = (data[16].toInt() and 0xFF) * 0.1f
                val spd = data[21].toInt() and 0xFF

                onDataReceived?.invoke(EngineData(rpm, tpsD, tpsV, ect, ectV, iat, iatV, mapKpa, mapV, bat, spd))
            }
            // 2. TABEL 11 (Injector & Voltase Detail)
            else if (resType == 0x71 && tableId == 0x11 && data.size >= 15) {
                val tpsV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapV = (data[7].toInt() and 0xFF) * (5.0f / 256.0f)
                val bat = (data[9].toInt() and 0xFF) * 0.1f
                val injMs = ((data[10].toInt() and 0xFF) * 256 + (data[11].toInt() and 0xFF)) * 0.001f

                sensorList.add(SensorItem("TABEL 11", "TPS Voltage", "--", String.format("%.2f V", tpsV)))
                sensorList.add(SensorItem("TABEL 11", "MAP Voltage", "--", String.format("%.2f V", mapV)))
                sensorList.add(SensorItem("TABEL 11", "Battery Voltage", "--", String.format("%.1f V", bat)))
                sensorList.add(SensorItem("TABEL 11", "Injector Pulse", String.format("%.2f ms", injMs), "--"))
                onSensorDetailReceived?.invoke(sensorList)
            }
            // 3. TABEL 13 (Ignition Timing)
            else if (resType == 0x71 && tableId == 0x13 && data.size >= 15) {
                val ign = ((data[10].toInt() and 0xFF) - 64) * 0.5f
                sensorList.add(SensorItem("TABEL 13", "Ignition Timing", String.format("%.1f °BTDC", ign), "--"))
                onSensorDetailReceived?.invoke(sensorList)
            }
            // 4. TABEL 20 (O2 Sensor & STFT)
            else if (resType == 0x71 && tableId == 0x20 && data.size >= 10) {
                val o2V = (data[4].toInt() and 0xFF) * (5.0f / 256.0f)
                val stft = ((data[5].toInt() and 0xFF) / 128.0f) * 100f
                sensorList.add(SensorItem("TABEL 20", "O2 Sensor Voltage", "--", String.format("%.2f V", o2V)))
                sensorList.add(SensorItem("TABEL 20", "Short Term Fuel Trim", String.format("%.1f %%", stft), "--"))
                onSensorDetailReceived?.invoke(sensorList)
            }
            // 5. TABEL D1 (Status Komponen)
            else if (resType == 0x71 && tableId == 0xD1 && data.size >= 15) {
                val d9 = data[4].toInt() and 0xFF
                val d13 = data[8].toInt() and 0xFF
                sensorList.add(SensorItem("TABEL D1", "Fuel Pump", if (d9 == 0x01 || d9 == 0x05) "ON" else "OFF", "--"))
                sensorList.add(SensorItem("TABEL D1", "Cooling Fan", if (d13 == 0x01) "ON" else "OFF", "--"))
                onSensorDetailReceived?.invoke(sensorList)
            }
            // 6. DTC
            else if (resType == 0x73) {
                val dtcList = mutableListOf<String>()
                for (i in 4 until (data.size - 1) step 2) {
                    if (i + 1 < data.size - 1) {
                        val c1 = data[i].toInt() and 0xFF; val c2 = data[i+1].toInt() and 0xFF
                        if (c1 != 0 || c2 != 0) dtcList.add(String.format("%02d-%02d", c1, c2))
                    }
                }
                onDtcReceived?.invoke(dtcList)
            }
        } catch (e: Exception) { Log.e(TAG, "Parse Error: ${e.message}") }
    }
}