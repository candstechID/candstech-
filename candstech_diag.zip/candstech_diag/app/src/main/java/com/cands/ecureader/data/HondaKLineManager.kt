package com.cands.ecureader.data

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class HondaKLineManager(private val usbManager: UsbManager) {
    private var serialDevice: UsbSerialDevice? = null
    private var connection: UsbDeviceConnection? = null
    var isConnected: Boolean = false
        private set

    var connectedMotorName: String = "Tidak Diketahui"
        private set

    suspend fun connect(device: UsbDevice, mode: String, motorType: String): Boolean = withContext(Dispatchers.IO) {
        try {
            connection = usbManager.openDevice(device)
            if (connection == null) return@withContext false

            val deviceInstance = UsbSerialDevice.createUsbSerialDevice(device, connection)
            serialDevice = deviceInstance
            
            if (deviceInstance == null || !deviceInstance.open()) {
                connection?.close()
                return@withContext false
            }

            // Baud rate 10400, 8N1 (Standar Honda K-Line)
            deviceInstance.setBaudRate(10400)
            deviceInstance.setDataBits(UsbSerialInterface.DATA_BITS_8)
            deviceInstance.setStopBits(UsbSerialInterface.STOP_BITS_1)
            deviceInstance.setParity(UsbSerialInterface.PARITY_NONE)
            deviceInstance.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            
            delay(100)
            
            // Bersihkan buffer sisa sebelum memulai jabat tangan
            deviceInstance.syncRead(ByteArray(256), 100)

            var handshakeSuccess = false
            if (mode == "Auto") {
                Log.d("HondaKLineManager", "Mencoba Auto Mode (Protokol KWP2000 Baru)")
                handshakeSuccess = executeHandshake(deviceInstance, "81 11 F1 81")
                if (handshakeSuccess) {
                    connectedMotorName = "Honda Vario 150/PCX/Baru (KWP)"
                } else {
                    Log.d("HondaKLineManager", "Mencoba Auto Mode (Protokol K-Line Lama)")
                    handshakeSuccess = executeHandshakeRaw(deviceInstance, "72 05 00 F0 99")
                    if (handshakeSuccess) {
                         connectedMotorName = "Honda BeAT/Scoopy/Lama"
                    }
                }
            } else {
                connectedMotorName = motorType
                if (motorType.contains("BeAT") || motorType.contains("Scoopy") || motorType.contains("Verza")) {
                    handshakeSuccess = executeHandshakeRaw(deviceInstance, "72 05 00 F0 99")
                } else {
                    handshakeSuccess = executeHandshake(deviceInstance, "81 11 F1 81")
                }
            }

            if (handshakeSuccess) {
                isConnected = true
                return@withContext true
            } else {
                disconnect() // Gagal handshake? Putuskan koneksi agar UI tetap Merah
                return@withContext false
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Connection error", e)
            disconnect()
            false
        }
    }

    private suspend fun executeHandshake(device: UsbSerialDevice, headerStr: String): Boolean {
        device.setBreak(true)
        delay(70)
        device.setBreak(false)
        delay(120)

        val wakeup = buildKWPFrame(hexStringToByteArray(headerStr))
        device.syncWrite(wakeup, 500)
        
        val buffer = ByteArray(128)
        val bytesRead = device.syncRead(buffer, 400)
        
        if (bytesRead <= 0) return false
        
        val response = buffer.copyOfRange(0, bytesRead)
        // FILTER ECHO: Jika data yang diterima persis sama dengan yang dikirim, berarti ECU bungkam (hanya pantulan kabel)
        if (response.size == wakeup.size && response.contentEquals(wakeup)) {
            Log.w("HondaKLineManager", "Terdeteksi Echo Kabel (KWP), ECU Tidak Merespon!")
            return false
        }
        
        return true 
    }

    private suspend fun executeHandshakeRaw(device: UsbSerialDevice, rawStr: String): Boolean {
        device.setBreak(true)
        delay(70)
        device.setBreak(false)
        delay(120)

        val wakeup = hexStringToByteArray(rawStr)
        device.syncWrite(wakeup, 500)
        
        val buffer = ByteArray(128)
        val bytesRead = device.syncRead(buffer, 400)
        
        if (bytesRead <= 0) return false
        
        val response = buffer.copyOfRange(0, bytesRead)
        if (response.size == wakeup.size && response.contentEquals(wakeup)) {
            Log.w("HondaKLineManager", "Terdeteksi Echo Kabel (Raw), ECU Tidak Merespon!")
            return false
        }
        
        return true 
    }

    suspend fun requestLiveData(): Map<String, Any> = withContext(Dispatchers.IO) {
        val result = mutableMapOf<String, Any>(
            "rpm" to "0", "tps" to "0°", "temp" to "--°C", "voltage" to "0.0 V",
            "map" to "0 kPa", "iat" to "--°C", "iacv" to "0 %", "injector" to "0.0 ms"
        )
        val device = serialDevice
        if (!isConnected || device == null) return@withContext result

        try {
            // Header standar request Live Data PID 01 (0x21 0x01)
            val requestBytes = buildKWPFrame(hexStringToByteArray("82 11 F1 21 01"))
            device.syncWrite(requestBytes, 300)
            
            val buffer = ByteArray(256)
            val bytesRead = device.syncRead(buffer, 400)
            
            if (bytesRead > requestBytes.size) { 
                val response = buffer.copyOfRange(0, bytesRead)
                // Cari index 0x61 yang menandakan "Positive Response" dari ECU, mengabaikan byte echo di depan
                val startIndex = response.indexOfFirst { (it.toInt() and 0xFF) == 0x61 }
                
                if (startIndex != -1 && response.size >= startIndex + 4) {
                    // Struktur umum balasan: [61] [01] [RPM_H] [RPM_L] [TPS] [TEMP] ...
                    val rawRpm = ((response[startIndex + 2].toInt() and 0xFF) shl 8) or (response[startIndex + 3].toInt() and 0xFF)
                    if (rawRpm > 0) {
                        result["rpm"] = (rawRpm / 4).toString()
                    }
                    
                    if (response.size >= startIndex + 5) {
                        val rawTps = response[startIndex + 4].toInt() and 0xFF
                        result["tps"] = "$rawTps°"
                    }
                    
                    if (response.size >= startIndex + 6) {
                        val rawTemp = (response[startIndex + 5].toInt() and 0xFF) - 40
                        result["temp"] = "$rawTemp°C"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Gagal membaca live data", e)
        }
        return@withContext result
    }

    suspend fun sendCommand(hexCommand: String): ByteArray? = withContext(Dispatchers.IO) {
        val device = serialDevice ?: return@withContext null
        try {
            val bytes = buildKWPFrame(hexStringToByteArray(hexCommand))
            device.syncWrite(bytes, 500)
            val buffer = ByteArray(128)
            val n = device.syncRead(buffer, 500)
            if (n > bytes.size) { // Mengabaikan echo
                return@withContext buffer.copyOfRange(bytes.size, n)
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Command error", e)
        }
        return@withContext null
    }

    fun disconnect() {
        try { 
            serialDevice?.close()
            connection?.close() 
        } catch (_: Exception) {}
        serialDevice = null
        connection = null
        isConnected = false
    }

    private fun buildKWPFrame(payload: ByteArray): ByteArray {
        var checksum = 0
        for (b in payload) {
            checksum += (b.toInt() and 0xFF)
        }
        val frame = ByteArray(payload.size + 1)
        System.arraycopy(payload, 0, frame, 0, payload.size)
        frame[payload.size] = (checksum and 0xFF).toByte()
        return frame
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val clean = s.replace(" ", "")
        val data = ByteArray(clean.length / 2)
        for (i in clean.indices step 2) {
            data[i / 2] = ((Character.digit(clean[i], 16) shl 4) + Character.digit(clean[i + 1], 16)).toByte()
        }
        return data
    }
}
