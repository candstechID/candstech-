package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    // ===== COMMANDS HONDA KEIHIN K-LINE =====
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)
    
    // Slow Init handshake
    val CMD_SLOW_INIT_START = byteArrayOf(0x33)
    val CMD_SLOW_INIT_ACK = byteArrayOf(0x08)

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            Log.d(TAG, "USB RX Raw: ${data.joinToString(" ") { "%02X".format(it) }}")
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        try {
            if (serialPort.isOpen) serialPort.close()
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.setDTR(false)
            serialPort.setRTS(false)
            serialPort.read(mCallback)
            Log.d(TAG, "Port dibuka @ 10400 baud")
        } catch (e: Exception) {
            Log.e(TAG, "Gagal setup port: ${e.message}")
        }
    }

    // ============================================
    // SLOW INIT (ISO 9141) - Coba PERTAMA
    // Kompatibel dengan ECU Honda lama (Supra, Tiger, dll)
    // ============================================
    suspend fun performSlowInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "=== SLOW INIT (ISO 9141) ===")
            
            // Step 1: Tarik line LOW dengan 5 baud (~200ms)
            serialPort.setBaudRate(5)
            delay(50)
            serialPort.write(byteArrayOf(0x33))
            delay(200)
            
            // Step 2: Kembali ke 10400 baud
            serialPort.setBaudRate(10400)
            delay(120)
            
            // Step 3: Clear queue & baca respons ECU
            safeClearQueue()
            Log.d(TAG, "Menunggu respons ECU (0x55 atau 0x4B)...")
            val resp1 = readAvailableBytes(5, 300)
            Log.d(TAG, "Slow Init Resp 1: ${resp1.joinToString(" ") { "%02X".format(it) }}")
            
            // Validasi: ECU harus balas 0x55 atau 0x4B
            val hasAck = resp1.contains(0x55.toByte()) || resp1.contains(0x4B.toByte())
            if (!hasAck) {
                Log.e(TAG, "Slow Init: ECU tidak merespons 0x55/0x4B")
                return@withContext false
            }
            
            // Step 4: Kirim 0x08 untuk konfirmasi handshake
            delay(25)
            serialPort.write(byteArrayOf(0x08))
            Log.d(TAG, "Kirim ACK 0x08")
            
            // Step 5: ECU harus balas 0x08
            delay(50)
            val resp2 = readAvailableBytes(5, 200)
            Log.d(TAG, "Slow Init Resp 2: ${resp2.joinToString(" ") { "%02X".format(it) }}")
            
            if (resp2.contains(0x08.toByte())) {
                Log.d(TAG, "✅ SLOW INIT BERHASIL")
                return@withContext true
            }
            
            Log.e(TAG, "Slow Init: ACK 0x08 tidak diterima")
            return@withContext false
            
        } catch (e: Exception) {
            Log.e(TAG, "Slow Init exception: ${e.message}")
            return@withContext false
        }
    }

    // ============================================
    // FAST INIT (KWP2000) - Coba KEDUA jika Slow Init gagal
    // Kompatibel dengan ECU Honda baru (Vario, PCX, Beat FI, dll)
    // ============================================
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "=== FAST INIT (KWP2000) ===")
            
            // Step 1: Tarik LOW dengan 300 baud (~70ms)
            serialPort.setBaudRate(300)
            delay(50)
            serialPort.write(byteArrayOf(0x00, 0x00))
            delay(70)
            
            // Step 2: HIGH 120ms
            serialPort.setBaudRate(10400)
            delay(120)
            
            // Step 3: Kirim Wakeup FE 04 72 8C
            safeClearQueue()
            Log.d(TAG, "Kirim WAKEUP: ${CMD_WAKEUP.joinToString(" ") { "%02X".format(it) }}")
            serialPort.write(CMD_WAKEUP)
            delay(150)
            
            val wakeupResp = readAvailableBytes(10, 200)
            Log.d(TAG, "Wakeup Resp: ${wakeupResp.joinToString(" ") { "%02X".format(it) }}")
            
            val wakeupValid = wakeupResp.contains(0x72.toByte()) && 
                             wakeupResp.contains(0x7C.toByte())
            if (!wakeupValid) {
                Log.e(TAG, "Fast Init: Wakeup gagal")
                return@withContext false
            }
            
            // Step 4: Kirim Init 72 05 00 F0 99
            safeClearQueue()
            Log.d(TAG, "Kirim INIT: ${CMD_INIT_KWP.joinToString(" ") { "%02X".format(it) }}")
            serialPort.write(CMD_INIT_KWP)
            delay(150)
            
            val initResp = readAvailableBytes(10, 200)
            Log.d(TAG, "Init Resp: ${initResp.joinToString(" ") { "%02X".format(it) }}")
            
            val initValid = initResp.size >= 4 &&
                           initResp[0] == 0x02.toByte() &&
                           initResp[1] == 0x04.toByte() &&
                           initResp[2] == 0x00.toByte() &&
                           initResp[3] == 0xFA.toByte()
            
            if (initValid) {
                Log.d(TAG, "✅ FAST INIT BERHASIL")
                return@withContext true
            }
            
            Log.e(TAG, "Fast Init: Response init tidak valid")
            return@withContext false
            
        } catch (e: Exception) {
            Log.e(TAG, "Fast Init exception: ${e.message}")
            return@withContext false
        }
    }

    // ============================================
    // UNIVERSAL INIT: Coba Slow dulu, lalu Fast
    // ============================================
    suspend fun performUniversalInit(): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 UNIVERSAL INIT: Mencoba Slow Init...")
        
        // Coba Slow Init dulu
        val slowSuccess = performSlowInit()
        if (slowSuccess) {
            return@withContext true
        }
        
        // Jika gagal, reset port dan coba Fast Init
        Log.d(TAG, "⚠️ Slow Init gagal, mencoba Fast Init...")
        delay(500)
        
        // Reset port ke kondisi awal
        try {
            serialPort.setBaudRate(10400)
            delay(100)
        } catch (e: Exception) {
            Log.e(TAG, "Reset baud rate gagal: ${e.message}")
        }
        
        val fastSuccess = performFastInit()
        return@withContext fastSuccess
    }

    fun sendCommand(command: ByteArray) {
        try {
            serialPort.write(command)
        } catch (e: Exception) {
            Log.e(TAG, "Send command failed: ${e.message}")
        }
    }

    fun pollEngineData() {
        try {
            while (rxQueue.isNotEmpty() && 
                   rxQueue.peek() != 0x02.toByte() && 
                   rxQueue.peek() != 0x72.toByte()) {
                rxQueue.poll()
            }

            if (rxQueue.size >= 2) {
                val iterator = rxQueue.iterator()
                if (!iterator.hasNext()) return
                iterator.next()
                if (!iterator.hasNext()) return
                
                val expectedLength = iterator.next().toInt() and 0xFF

                if (expectedLength in 4..50) {
                    if (rxQueue.size >= expectedLength) {
                        val buffer = ByteArray(expectedLength)
                        for (i in 0 until expectedLength) {
                            buffer[i] = rxQueue.poll()!!
                        }
                        parseHondaResponse(buffer)
                    }
                } else {
                    rxQueue.poll()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Poll error: ${e.message}")
        }
    }

    private fun safeClearQueue() {
        while (rxQueue.isNotEmpty()) {
            rxQueue.poll()
        }
    }

    private suspend fun readAvailableBytes(maxBytes: Int, timeoutMs: Long): ByteArray {
        val result = mutableListOf<Byte>()
        val startTime = System.currentTimeMillis()
        
        while (result.size < maxBytes && 
               (System.currentTimeMillis() - startTime) < timeoutMs) {
            if (rxQueue.isNotEmpty()) {
                result.add(rxQueue.poll()!!)
            } else {
                delay(10)
            }
        }
        
        return result.toByteArray()
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            if (responseType == 0x71 && 
                data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && 
                data.size >= 21) {
                
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, 
                    afr = 14.7f, o2Volt = 0.0f, engineLoad = tpsDegrees, 
                    iacv = 0, injectorMs = 0.0f
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parsing error: ${e.message}")
        }
    }
}