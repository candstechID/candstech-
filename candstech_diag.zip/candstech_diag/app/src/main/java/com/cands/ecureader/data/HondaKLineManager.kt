package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    // COMMANDS (Checksum Anda sudah BENAR: 0x100 - (sum & 0xFF))
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08) // Table 0x10

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.setDTR(false)
        serialPort.setRTS(false)
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Mulai Fast Init (70ms LOW, 120ms HIGH)")
            
            // 1. PERBAIKAN TIMING: Gunakan 300 baud, bukan 128.
            // Di 300 baud, 1 byte (10 bits) = 33.3ms. Mengirim 2 byte 0x00 = ~66.6ms LOW.
            // Ini jauh lebih stabil dan didukung penuh oleh chip FTDI.
            serialPort.setBaudRate(300)
            delay(50) // Beri waktu driver USB stabil di baud rate baru
            serialPort.write(byteArrayOf(0x00, 0x00))
            delay(70) // Pastikan total waktu LOW mencapai ~70ms
            
            // 2. Lepas jalur ke HIGH (12V) selama 120ms
            serialPort.setBaudRate(10400)
            delay(120)
            
            // 3. Kirim Wakeup
            Log.d(TAG, "Kirim Wakeup: FE 04 72 8C")
            safeClearQueue()
            serialPort.write(CMD_WAKEUP)
            
            // 4. BACA & VALIDASI RESPONSE WAKEUP (PENTING!)
            // ECU Honda seharusnya membalas dengan: FE 04 72 7C (atau 0E 04 72 7C)
            delay(100)
            val wakeupResponse = readAvailableBytes(5)
            if (!isValidWakeupResponse(wakeupResponse)) {
                Log.e(TAG, "Wakeup Gagal. Response ECU: ${wakeupResponse.joinToString(" ") { "%02X".format(it) }}")
                return@withContext false
            }
            Log.d(TAG, "Wakeup Berhasil: ${wakeupResponse.joinToString(" ") { "%02X".format(it) }}")

            // 5. Kirim Init Command
            safeClearQueue()
            Log.d(TAG, "Kirim Init Command: 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            
            // 6. BACA & VALIDASI RESPONSE INIT
            // ECU seharusnya membalas dengan: 02 04 00 FA
            delay(100)
            val initResponse = readAvailableBytes(4)
            if (!isValidInitResponse(initResponse)) {
                Log.e(TAG, "Init Gagal. Response ECU: ${initResponse.joinToString(" ") { "%02X".format(it) }}")
                return@withContext false
            }
            Log.d(TAG, "Init Berhasil: ${initResponse.joinToString(" ") { "%02X".format(it) }}")
            
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Init Gagal Exception: ${e.message}")
            return@withContext false
        }
    }

    // --- HELPER FUNCTIONS ---

    private fun safeClearQueue() {
        // Menghindari race condition dengan membaca dan membuang data, bukan clear() langsung
        while (rxQueue.isNotEmpty()) {
            rxQueue.poll()
        }
    }

    private fun readAvailableBytes(maxBytes: Int): ByteArray {
        val result = mutableListOf<Byte>()
        var attempts = 0
        // Timeout maksimal ~200ms untuk menunggu data lengkap
        while (result.size < maxBytes && attempts < 20) {
            if (rxQueue.isNotEmpty()) {
                result.add(rxQueue.poll()!!)
            } else {
                Thread.sleep(10)
                attempts++
            }
        }
        return result.toByteArray()
    }

    private fun isValidWakeupResponse(response: ByteArray): Boolean {
        if (response.size < 4) return false
        // Cek apakah byte ke-3 adalah 0x72 dan byte ke-4 (checksum) adalah 0x7C
        return (response[2] == 0x72.toByte()) && (response[3] == 0x7C.toByte())
    }

    private fun isValidInitResponse(response: ByteArray): Boolean {
        if (response.size < 4) return false
        // Pola respon init standar Honda: 02 04 00 FA
        return response[0] == 0x02.toByte() && 
               response[1] == 0x04.toByte() && 
               response[2] == 0x00.toByte() && 
               response[3] == 0xFA.toByte()
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    fun pollEngineData() {
        // Sinkronisasi: cari header 0x02 atau 0x72
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte() && rxQueue.peek() != 0x72.toByte()) {
            rxQueue.poll()
        }

        if (rxQueue.size >= 2) {
            // Kita perlu mengintip (peek) tanpa menghapus untuk membaca panjang
            val iterator = rxQueue.iterator()
            if (!iterator.hasNext()) return
            iterator.next() // skip byte pertama (header)
            if (!iterator.hasNext()) return
            
            val expectedLength = iterator.next().toInt() and 0xFF

            if (expectedLength in 4..50) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) {
                        buffer[i] = rxQueue.poll()!!
                    }
                    parseHondaResponse(buffer)
                }
            } else {
                rxQueue.poll() // Buang byte yang tidak valid
            }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            // Table 0x10 Response (Length 22 -> 0x16)
            if (responseType == 0x71 && data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && data.size >= 21) {
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, 
                    afr = 14.7f, o2Volt = 0.0f, engineLoad = tpsDegrees, iacv = 0, injectorMs = 0.0f
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parsing Error: ${e.message}")
        }
    }
}