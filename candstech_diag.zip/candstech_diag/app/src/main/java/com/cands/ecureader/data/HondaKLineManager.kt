suspend fun performUniversalInit(): Boolean = withContext(Dispatchers.IO) {
        logToUi("🔄 UNIVERSAL INIT: Brute Force Mode")
        
        // Step 1: Reset ECU dengan delay panjang (simulasi cabut aki)
        logToUi("Step 1: Reset ECU (tunggu 3 detik)...")
        delay(3000)
        
        // Step 2: Coba Fast Init dengan retry 3x
        for (attempt in 1..3) {
            logToUi("=== FAST INIT ATTEMPT $attempt/3 ===")
            
            val success = performFastInitWithRetry()
            if (success) {
                return@withContext true
            }
            
            logToUi("Attempt $attempt gagal, tunggu 2 detik...")
            delay(2000)
        }
        
        // Step 3: Jika Fast Init gagal semua, coba Slow Init
        logToUi("⚠️ Fast Init gagal 3x, coba Slow Init...")
        delay(1000)
        
        val slowSuccess = performSlowInit()
        if (slowSuccess) {
            return@withContext true
        }
        
        logToUi("❌ SEMUA INIT GAGAL")
        logToUi("💡 Saran: Cabut aki motor 10 detik, pasang lagi, coba lagi")
        return@withContext false
    }

    private suspend fun performFastInitWithRetry(): Boolean = withContext(Dispatchers.IO) {
        try {
            // 1. Tarik LOW ~76ms dengan 300 baud
            serialPort.setBaudRate(300)
            delay(150) // Delay untuk USB switching
            
            // Kirim banyak 0x00 untuk pastikan LOW stabil
            val lowPulse = ByteArray(80) { 0x00 }
            serialPort.write(lowPulse)
            logToUi("Kirim 80 byte 0x00 (LOW ~76ms)")
            delay(100)
            
            // 2. HIGH 120ms
            serialPort.setBaudRate(10400)
            delay(200) // Delay lebih lama
            
            // 3. Clear queue & kirim Wakeup
            safeClearQueue()
            logToUi("Kirim WAKEUP: FE 04 72 8C")
            serialPort.write(CMD_WAKEUP)
            delay(300) // Tunggu lebih lama
            
            // 4. Baca respons
            safeClearQueue() // Buang echo
            delay(100)
            
            val wakeupResp = readAvailableBytes(20, 500)
            logToUi("Wakeup Resp: ${wakeupResp.joinToString(" ") { "%02X".format(it) }}")
            
            if (wakeupResp.isEmpty()) {
                logToUi("❌ Tidak ada respons")
                return@withContext false
            }
            
            // Cek apakah ada pola 72 7C di respons
            val hasWakeupAck = wakeupResp.contains(0x72.toByte()) && 
                              wakeupResp.contains(0x7C.toByte())
            
            if (!hasWakeupAck) {
                logToUi("⚠️ Respons ada tapi bukan Wakeup ACK")
                // Coba kirim Wakeup lagi
                delay(100)
                serialPort.write(CMD_WAKEUP)
                delay(300)
                safeClearQueue()
                delay(100)
                
                val resp2 = readAvailableBytes(20, 500)
                logToUi("Wakeup Retry Resp: ${resp2.joinToString(" ") { "%02X".format(it) }}")
                
                val hasAck2 = resp2.contains(0x72.toByte()) && resp2.contains(0x7C.toByte())
                if (!hasAck2) {
                    return@withContext false
                }
            }
            
            logToUi("✅ Wakeup berhasil!")
            
            // 5. Kirim Init
            safeClearQueue()
            delay(100)
            logToUi("Kirim INIT: 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            delay(300)
            
            safeClearQueue()
            delay(100)
            
            val initResp = readAvailableBytes(20, 500)
            logToUi("Init Resp: ${initResp.joinToString(" ") { "%02X".format(it) }}")
            
            if (initResp.isEmpty()) {
                logToUi("❌ Init: Tidak ada respons")
                return@withContext false
            }
            
            val initValid = initResp.size >= 4 &&
                           initResp[0] == 0x02.toByte() &&
                           initResp[1] == 0x04.toByte() &&
                           initResp[2] == 0x00.toByte() &&
                           initResp[3] == 0xFA.toByte()
            
            if (initValid) {
                logToUi("✅ FAST INIT BERHASIL!")
                return@withContext true
            }
            
            logToUi("❌ Init: Respons tidak valid")
            return@withContext false
            
        } catch (e: Exception) {
            logToUi("Fast Init exception: ${e.message}")
            return@withContext false
        }
    }