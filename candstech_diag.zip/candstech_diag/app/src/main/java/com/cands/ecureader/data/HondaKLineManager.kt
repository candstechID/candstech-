package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float,
    val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float,
    val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    // GITHUB ANDREIBAW REPO COMMANDS:
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08) // Read Table 0x10
    
    // Fallback standard DTC commands
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())
    val CMD_TEST_FUEL_PUMP = byteArrayOf(0x02, 0x04, 0x70, 0x01, 0x89.toByte())
    val CMD_TEST_FAN = byteArrayOf(0x02, 0x04, 0x70, 0x02, 0x88.toByte())
    val CMD_TEST_INJ = byteArrayOf(0x02, 0x04, 0x70, 0x03, 0x87.toByte())
    val CMD_TEST_COIL = byteArrayOf(0x02, 0x04, 0x70, 0x04, 0x86.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.setDTR(false)
        serialPort.setRTS(false)
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Memulai Init KWP2000 Honda (70ms LOW, 120ms HIGH)")
            
            // 1. Pull Low for 70ms (Baudrate trick: 128 baud = ~70.3ms for 1 byte)
            serialPort.setBaudRate(128)
            serialPort.write(byteArrayOf(0x00))
            delay(100) // Waktu pengiriman byte di 128 baud + jeda
            
            // 2. Idle High for 120ms
            serialPort.setBaudRate(10400)
            delay(120)
            
            // 3. Send Wakeup (FE 04 FF FF) - No response expected
            Log.d(TAG, "Mengirim WakeUp FE 04 FF FF")
            serialPort.write(CMD_WAKEUP)
            delay(200) // Wait 200ms
            
            // 4. Send Init Message (72 05 00 F0 99)
            rxQueue.clear()
            Log.d(TAG, "Mengirim Init 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            
            Log.d(TAG, "Fast Init Sukses, menunggu respon 0x02 0x04 0x00 0xFA ECU...")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Fast Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        Log.d(TAG, "Mengirim Command: ${command.joinToString("") { "%02x ".format(it) }}")
        serialPort.write(command)
    }

    fun pollEngineData() {
        if (rxQueue.size >= 5) {
            val buffer = mutableListOf<Byte>()
            while (rxQueue.isNotEmpty()) {
                buffer.add(rxQueue.poll() ?: break)
            }
            parseHondaResponse(buffer.toByteArray())
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val destAddress = data.getOrNull(0)?.toInt()?.and(0xFF) ?: 0
            val length = data.getOrNull(1)?.toInt()?.and(0xFF) ?: 0
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            // Parsing berdasarkan repo Andreibaw: Table 0x10 Response Length = 0x16 (22 bytes)
            if (responseType == 0x71 && data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && data.size >= 21) {
                // RPM is High/Low bytes at offset 4 and 5
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow // Repo doesn't divide by 4

                // TPS
                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f // Mapped to percent or degree based on repo

                // ECT
                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40 // offset handling maybe required

                // IAT
                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                // MAP
                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                // Battery Voltage
                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                // Speed is at 17
                val speed = data.getOrNull(17)?.toInt()?.and(0xFF) ?: 0

                // Default values for missing explicit fields in this specific table
                val engineLoad = (tpsPercentRaw / 255.0f) * 100f
                val afr = 14.7f
                val o2Volt = 0.0f
                val iacv = 0
                val injectorMs = 0.0f

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt,
                    iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt,
                    battery = battery, afr = afr, o2Volt = o2Volt,
                    engineLoad = engineLoad, iacv = iacv, injectorMs = injectorMs
                )
                onDataReceived?.invoke(engineData)
            }
            // Standard Fast Init Response `02 04 00 FA`
            else if (destAddress == 0x02 && length == 0x04 && responseType == 0x00) {
                 // ECU is awake and ready
                 Log.d(TAG, "ECU Awake confirmed via 0x02 0x04 0x00 0xFA")
            }
            // Standard Live Data Response (Old Method Fallback)
            else if (responseType == 0x00 && data.size >= 15 && destAddress == 0x02) {
                 val byteA = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
                 val byteB = data.getOrNull(3)?.toInt()?.and(0xFF) ?: 0
                 val calculatedRpm = ((byteA * 256) + byteB) / 4
                 // ... (fallback parsing for standard protocol, skipped for brevity, prioritizing KWP table)
                 val tpsVolt = ((data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0) / 255f) * 5.0f
                 onDataReceived?.invoke(EngineData(calculatedRpm, 0f, tpsVolt, 40, 0f, 30, 0f, 0, 0f, 12f, 14.7f, 0f, 0f, 0, 0f))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gagal parsing data ECU: ${e.message}")
        }
    }
}
