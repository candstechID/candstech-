package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int,
    val tpsDeg: Float,
    val tpsVolt: Float,
    val ect: Int,
    val ectVolt: Float,
    val iat: Int,
    val iatVolt: Float,
    val mapKpa: Int,
    val mapVolt: Float,
    val battery: Float,
    val afr: Float,
    val o2Volt: Float,
    val engineLoad: Float,
    val iacv: Int,
    val injectorMs: Float,
    val speedKmh: Int
)

data class SensorItem(
    val category: String,
    val name: String,
    val value: String,
    val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val tag = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private val txLock = Any()
    private val transactionMutex = Mutex()

    @Volatile private var portOpened = false
    @Volatile private var sessionStarted = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onRawFrameReceived: ((ByteArray) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    private val startCommand = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
    private val keepAliveCommand = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    private val readCallback = UsbSerialInterface.UsbReadCallback { data ->
        data?.forEach { rxQueue.offer(it) }
    }

    fun setupPort() {
        try {
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.read(readCallback)
            portOpened = true
            log("Port terbuka: 10400 baud, 8N1.")
        } catch (e: Exception) {
            portOpened = false
            log("Gagal membuka port: ${e.message}")
            Log.e(tag, "setupPort", e)
        }
    }

    fun closePort() {
        sessionStarted = false
        portOpened = false
        try { serialPort.close() } catch (e: Exception) { log("Close port: ${e.message}") }
        rxQueue.clear()
    }

    private fun hex(data: ByteArray) =
        data.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun log(message: String) { onLog?.invoke(message) }

    private fun clearRx() { rxQueue.clear() }

    private fun write(frame: ByteArray) {
        synchronized(txLock) {
            log("TX: ${hex(frame)}")
            serialPort.write(frame)
        }
    }

    private suspend fun awaitExact(expected: ByteArray, timeoutMs: Long): ByteArray? {
        val seen = ArrayList<Byte>()
        val started = System.currentTimeMillis()
        while (System.currentTimeMillis() - started < timeoutMs) {
            while (true) {
                val b = rxQueue.poll() ?: break
                seen.add(b)
                while (seen.size > expected.size) seen.removeAt(0)
                if (seen.size == expected.size && seen.indices.all { seen[it] == expected[it] }) {
                    val result = seen.toByteArray()
                    log("RX: ${hex(result)}")
                    onRawFrameReceived?.invoke(result)
                    return result
                }
            }
            delay(5)
        }
        log("Timeout menunggu respons ${hex(expected)}")
        return null
    }

    /** LEN adalah jumlah seluruh byte frame, termasuk header dan checksum. */
    private suspend fun readFrame(timeoutMs: Long = 1200): ByteArray? {
        val buffer = ArrayList<Byte>()
        val started = System.currentTimeMillis()
        while (System.currentTimeMillis() - started < timeoutMs) {
            while (true) {
                val b = rxQueue.poll() ?: break
                buffer.add(b)
            }
            val header = buffer.indexOfFirst { (it.toInt() and 0xFF) == 0x02 }
            if (header > 0) repeat(header) { buffer.removeAt(0) }
            if (buffer.size >= 2) {
                val length = buffer[1].toInt() and 0xFF
                if (length in 4..0x40) {
                    if (buffer.size >= length) {
                        val frame = ByteArray(length) { buffer[it] }
                        repeat(length) { buffer.removeAt(0) }
                        log("RX: ${hex(frame)}")
                        onRawFrameReceived?.invoke(frame.copyOf())
                        if (!HondaProtocolParser.isValidFrame(frame)) {
                            log("Frame checksum/length tidak valid: ${hex(frame)}")
                            return null
                        }
                        return frame
                    }
                } else {
                    buffer.removeAt(0)
                }
            }
            delay(5)
        }
        if (buffer.isNotEmpty()) log("Timeout frame. Buffer: ${hex(buffer.toByteArray())}")
        return null
    }

    suspend fun performFastInit(): Boolean = transactionMutex.withLock {
        withContext(Dispatchers.IO) {
            if (!portOpened) { log("Port belum dibuka."); return@withContext false }
            try {
                sessionStarted = false
                serialPort.setBaudRate(10400)
                serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
                serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
                serialPort.setParity(UsbSerialInterface.PARITY_NONE)
                serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)

                clearRx()
                log("WAKE UP: LOW 70 ms")
                serialPort.setBreak(true)
                delay(70)
                log("WAKE UP: HIGH 120 ms")
                serialPort.setBreak(false)
                delay(120)

                clearRx()
                log("START COMMUNICATION")
                write(startCommand)
                if (awaitExact(byteArrayOf(0x0E, 0x04, 0x72, 0x7C), 1500) == null) {
                    log("START COMMUNICATION gagal.")
                    return@withContext false
                }

                clearRx()
                log("KEEP ALIVE")
                write(keepAliveCommand)
                if (awaitExact(byteArrayOf(0x02, 0x04, 0x00, 0xFA.toByte()), 1500) == null) {
                    log("KEEP ALIVE gagal.")
                    return@withContext false
                }
                sessionStarted = true
                log("ECU SESSION AKTIF.")
                true
            } catch (e: Exception) {
                sessionStarted = false
                log("Fast Init error: ${e.message}")
                Log.e(tag, "performFastInit", e)
                false
            }
        }
    }

    private suspend fun transact(query: Int, table: Int, timeout: Long = 1200): ByteArray? {
        if (!sessionStarted) { log("Sesi ECU belum aktif."); return null }
        clearRx()
        val request = HondaProtocolParser.buildQuery(query, table)
        write(request)
        // Echo TX boleh muncul sebelum frame ECU; readFrame mencari header 02.
        return readFrame(timeout)
    }

    suspend fun requestLiveTable(table: Int): ByteArray? =
        transactionMutex.withLock { withContext(Dispatchers.IO) {
            val frame = transact(0x71, table)
            if (frame != null) parseLiveFrame(frame)
            frame
        } }

    suspend fun requestLiveData(): Boolean = requestLiveTable(0x10) != null

    suspend fun requestTableAndParse(table: Int): ByteArray? = requestLiveTable(table)

    private fun parseLiveFrame(frame: ByteArray) {
        val parsed = HondaProtocolParser.parseLive(frame) ?: return
        val na = Float.NaN
        val data = EngineData(
            rpm = parsed.rpm ?: -1,
            tpsDeg = parsed.tpsDeg ?: na,
            tpsVolt = parsed.tpsVolt ?: na,
            ect = parsed.ect ?: -1,
            ectVolt = parsed.ectVolt ?: na,
            iat = parsed.iat ?: -1,
            iatVolt = parsed.iatVolt ?: na,
            mapKpa = parsed.mapKpa ?: -1,
            mapVolt = parsed.mapVolt ?: na,
            battery = parsed.battery ?: na,
            afr = na,
            o2Volt = parsed.o2Volt ?: na,
            engineLoad = na,
            iacv = -1,
            injectorMs = parsed.injectorMs ?: na,
            speedKmh = parsed.speedKmh ?: -1
        )
        if (parsed.rpm != null || parsed.tpsDeg != null) onDataReceived?.invoke(data)

        val table = frame[3].toInt() and 0xFF
        val items = mutableListOf<SensorItem>()
        fun add(name: String, value: Any?, voltage: String = "--") {
            if (value != null) items += SensorItem("TABEL %02X".format(table), name, value.toString(), voltage)
        }
        add("RPM", parsed.rpm)
        add("TPS", parsed.tpsDeg?.let { "%.1f°".format(it) }, parsed.tpsVolt?.let { "%.3f V".format(it) } ?: "--")
        add("ECT", parsed.ect?.let { "$it °C" }, parsed.ectVolt?.let { "%.3f V".format(it) } ?: "--")
        add("IAT", parsed.iat?.let { "$it °C" }, parsed.iatVolt?.let { "%.3f V".format(it) } ?: "--")
        add("MAP", parsed.mapKpa?.let { "$it kPa" }, parsed.mapVolt?.let { "%.3f V".format(it) } ?: "--")
        add("Battery", parsed.battery?.let { "%.1f V".format(it) })
        add("Injector", parsed.injectorMs?.let { "%.2f ms".format(it) })
        add("Ignition", parsed.ignitionDeg?.let { "%.1f°".format(it) })
        add("Speed", parsed.speedKmh?.let { "$it km/h" })
        add("O2", parsed.o2Volt?.let { "%.3f V".format(it) })
        add("STFT", parsed.stft)
        add("O2 Heater", parsed.o2HeaterVolt?.let { "%.3f V".format(it) })
        add("Status", parsed.statusText)
        add("Fuel Pump", parsed.fuelPumpOn?.let { if (it) "ON" else "OFF" })
        add("Cooling Fan", parsed.coolingFanOn?.let { if (it) "ON" else "OFF" })
        if (items.isNotEmpty()) onSensorDetailReceived?.invoke(items)
    }

    suspend fun readDtcTables(): List<ByteArray> = readDtcQuery(0x73)
    suspend fun readCurrentDtcTables(): List<ByteArray> = readDtcQuery(0x74)

    private suspend fun readDtcQuery(query: Int): List<ByteArray> =
        transactionMutex.withLock { withContext(Dispatchers.IO) {
            val frames = mutableListOf<ByteArray>()
            val codes = linkedSetOf<String>()
            for (table in 1..3) {
                val frame = transact(query, table, 1500)
                if (frame != null && frame.size == 12 &&
                    (frame[2].toInt() and 0xFF) == query &&
                    (frame[3].toInt() and 0xFF) == table) {
                    frames += frame
                    HondaProtocolParser.parseDtc(frame).forEach { codes += "${it.code}: ${it.description}" }
                } else log("Respons DTC query %02X tabel %02X tidak valid.".format(query, table))
                delay(40)
            }
            onDtcReceived?.invoke(codes.toList())
            frames
        } }

    /** Clear DTC ECM sesuai pilihan pengguna: tabel 01 saja. */
    suspend fun clearDtcTable01(): ByteArray? = clearDtcTable(0x01)

    suspend fun clearDtcTable(table: Int): ByteArray? =
        transactionMutex.withLock { withContext(Dispatchers.IO) {
            if (!sessionStarted || table !in 1..3) return@withContext null
            val expected = byteArrayOf(0x02, 0x05, 0x60, table.toByte(),
                (when (table) { 1 -> 0x98; 2 -> 0x97; else -> 0x96 }).toByte())
            clearRx()
            write(HondaProtocolParser.buildQuery(0x60, table))
            val ack = awaitExact(expected, 1500)
            if (ack != null && HondaProtocolParser.isChecksumValid(ack)) {
                log("CLEAR DTC tabel %02X ACK valid.".format(table))
                ack
            } else {
                log("CLEAR DTC tabel %02X gagal / ACK tidak cocok.".format(table))
                null
            }
        } }

    /** Perintah pilihan pengguna untuk Reset TP / ECM Initialization. */
    suspend fun resetTp(): ByteArray? =
        transactionMutex.withLock { withContext(Dispatchers.IO) {
            if (!sessionStarted) { log("Sesi ECU belum aktif."); return@withContext null }
            val command = byteArrayOf(0x72, 0x05, 0x60, 0x03, 0x26)
            val expected = byteArrayOf(0x02, 0x05, 0x60, 0x03, 0x96.toByte())
            clearRx()
            log("RESET TP: throttle harus tertutup penuh dan mesin mati.")
            write(command)
            val ack = awaitExact(expected, 1500)
            if (ack != null) log("RESET TP: ACK diterima; verifikasi TPS dengan tabel 17.")
            else log("RESET TP: tidak menerima ACK yang diharapkan.")
            ack
        } }

    suspend fun sendKeepAlive(): Boolean = transactionMutex.withLock {
        withContext(Dispatchers.IO) {
            if (!sessionStarted) return@withContext false
            clearRx()
            write(keepAliveCommand)
            awaitExact(byteArrayOf(0x02, 0x04, 0x00, 0xFA.toByte()), 1000) != null
        }
    }

    fun sendCommand(command: ByteArray) {
        if (!portOpened) { log("Port belum terbuka."); return }
        write(command)
    }
}
