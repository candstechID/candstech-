
package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int,
    val tpsDeg: Float,
    val tpsVolt: Float,
    val ect: Int,
    val ectVolt: Float,
    val iat: Int,
    val iatVolt: Float,
    val mapKpa: Int,
    val mapVolt: Float,
    val battery: Float,
    val afr: Float,
    val o2Volt: Float,
    val engineLoad: Float,
    val iacv: Int,
    val injectorMs: Float,
    val speedKmh: Int
)

data class SensorItem(
    val category: String,
    val name: String,
    val value: String,
    val voltage: String = "--"
)

class HondaKLineManager(
    private val serialPort: UsbSerialDevice
) {
    private val TAG = "HondaKLine"

    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private val rxBuffer = mutableListOf<Byte>()

    private val transactionMutex = Mutex()

    @Volatile
    private var portOpened = false

    @Volatile
    private var communicationStarted = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // =========================================================
    // COMMAND
    // =========================================================

    val CMD_START_COMM = byteArrayOf(
        0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()
    )

    val CMD_KEEP_ALIVE = byteArrayOf(
        0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()
    )

    val CMD_LIVE_DATA = byteArrayOf(
        0x72, 0x05, 0x71, 0x10, 0x08
    )

    val CMD_T11 = byteArrayOf(
        0x72, 0x05, 0x71, 0x11, 0x07
    )

    val CMD_T13 = byteArrayOf(
        0x72, 0x05, 0x71, 0x13, 0x05
    )

    val CMD_T20 = byteArrayOf(
        0x72, 0x05, 0x71, 0x20, 0xF8.toByte()
    )

    val CMD_TD1 = byteArrayOf(
        0x72, 0x05, 0x71, 0xD1.toByte(), 0x47
    )

    val CMD_READ_DTC = byteArrayOf(
        0x72, 0x05, 0x73, 0x01, 0x15
    )

    val CMD_CLEAR_DTC = byteArrayOf(
        0x72, 0x05, 0x60, 0x01, 0x28
    )

    val CMD_RESET_TP = byteArrayOf(
        0x02, 0x04, 0x60, 0x9A.toByte()
    )

    private val CMD_READ_DTC_TABLE_01 = byteArrayOf(
        0x72, 0x05, 0x74, 0x01, 0x14
    )

    private val EXPECTED_START_RESPONSE = byteArrayOf(
        0x0E, 0x04, 0x72, 0x7C
    )

    private val EXPECTED_KEEP_ALIVE_RESPONSE = byteArrayOf(
        0x02, 0x04, 0x00, 0xFA.toByte()
    )

    private val mCallback =
        UsbSerialInterface.UsbReadCallback { data ->
            if (data != null) {
                for (b in data) {
                    rxQueue.add(b)
                }
            }
        }

    // =========================================================
    // LOGGING
    // =========================================================

    private fun log(message: String) {
        Log.d(TAG, message)

        try {
            onLog?.invoke(message)
        } catch (e: Exception) {
            Log.e(TAG, "Log callback error", e)
        }
    }

    private fun ByteArray.toHex(): String {
        return joinToString(" ") {
            "%02X".format(it.toInt() and 0xFF)
        }
    }

    private fun bytesToHex(bytes: List<Byte>): String {
        return bytes.toByteArray().toHex()
    }

    // =========================================================
    // PORT
    // =========================================================

    @Synchronized
    fun setupPort() {
        if (portOpened) {
            log("Port sudah terbuka.")
            return
        }

        log("Membuka port serial 10400 baud, 8N1...")

        try {
            val opened = serialPort.open()

            if (!opened) {
                throw IllegalStateException(
                    "USB Serial gagal membuka port."
                )
            }

            serialPort.setBaudRate(10400)

            serialPort.setDataBits(
                UsbSerialInterface.DATA_BITS_8
            )

            serialPort.setStopBits(
                UsbSerialInterface.STOP_BITS_1
            )

            serialPort.setParity(
                UsbSerialInterface.PARITY_NONE
            )

            serialPort.setFlowControl(
                UsbSerialInterface.FLOW_CONTROL_OFF
            )

            rxQueue.clear()
            rxBuffer.clear()

            serialPort.read(mCallback)

            portOpened = true
            communicationStarted = false

            log("Port serial berhasil dibuka.")
            log("Serial: 10400 bps, 8N1.")

        } catch (e: Exception) {
            portOpened = false

            log("Gagal membuka port: ${e.message}")

            try {
                serialPort.close()
            } catch (_: Exception) {
            }

            throw e
        }
    }

    @Synchronized
    fun closePort() {
        if (!portOpened) return

        try {
            serialPort.close()
        } catch (e: Exception) {
            Log.e(TAG, "Close port error", e)
        }

        portOpened = false
        communicationStarted = false

        rxQueue.clear()
        rxBuffer.clear()

        log("Port ditutup.")
    }

    // =========================================================
    // CHECKSUM
    // =========================================================

    private fun calculateChecksum(
        data: ByteArray,
        length: Int
    ): Byte {
        var sum = 0

        for (i in 0 until length) {
            sum += data[i].toInt() and 0xFF
        }

        return (0x100 - (sum and 0xFF)).toByte()
    }

    private fun isChecksumValid(data: ByteArray): Boolean {
        if (data.size < 2) return false

        val calculated = calculateChecksum(
            data,
            data.size - 1
        )

        return calculated == data.last()
    }

    // =========================================================
    // RECEIVE BUFFER
    // =========================================================

    private fun clearReceiveBuffers() {
        rxQueue.clear()
        rxBuffer.clear()
    }

    // =========================================================
    // FRAME READER
    // =========================================================

    private suspend fun readFrame(
        timeoutMs: Long = 700L
    ): ByteArray? {
        val startTime = System.currentTimeMillis()

        while (
            System.currentTimeMillis() - startTime < timeoutMs
        ) {
            while (true) {
                val next = rxQueue.poll() ?: break
                rxBuffer.add(next)
            }

            val headerIndex = rxBuffer.indexOf(0x02.toByte())

            if (headerIndex < 0) {
                rxBuffer.clear()
                delay(2)
                continue
            }

            if (headerIndex > 0) {
                repeat(headerIndex) {
                    rxBuffer.removeAt(0)
                }
            }

            if (rxBuffer.size < 2) {
                delay(2)
                continue
            }

            val expectedLength =
                rxBuffer[1].toInt() and 0xFF

            // Respons Keep Alive adalah 4 byte.
            if (expectedLength !in 4..60) {
                log(
                    "Panjang frame tidak valid: $expectedLength"
                )

                rxBuffer.removeAt(0)
                continue
            }

            if (rxBuffer.size < expectedLength) {
                delay(2)
                continue
            }

            val frame = ByteArray(expectedLength)

            for (i in 0 until expectedLength) {
                frame[i] = rxBuffer.removeAt(0)
            }

            if (!isChecksumValid(frame)) {
                log("Checksum frame salah: ${frame.toHex()}")
                continue
            }

            return frame
        }

        return null
    }

    // =========================================================
    // START RESPONSE READER
    // =========================================================

    private suspend fun readStartResponse(
        timeoutMs: Long = 500L
    ): Boolean {
        val received = mutableListOf<Byte>()

        val startTime = System.currentTimeMillis()

        while (
            System.currentTimeMillis() - startTime < timeoutMs
        ) {
            while (true) {
                val b = rxQueue.poll() ?: break
                received.add(b)
            }

            val responseIndex = received.indices.firstOrNull { i ->
                i + EXPECTED_START_RESPONSE.size <= received.size &&
                    EXPECTED_START_RESPONSE.indices.all { j ->
                        received[i + j] == EXPECTED_START_RESPONSE[j]
                    }
            }

            if (responseIndex != null) {
                log(
                    "RX START: ${bytesToHex(received)}"
                )

                if (responseIndex > 0) {
                    log(
                        "Data sebelum respons: " +
                            bytesToHex(received.take(responseIndex))
                    )
                }

                return true
            }

            delay(2)
        }

        val raw = received.toByteArray()

        val echoPresent =
            raw.size >= CMD_START_COMM.size &&
                CMD_START_COMM.indices.all { i ->
                    raw[i] == CMD_START_COMM[i]
                }

        if (echoPresent) {
            log("Echo START terdeteksi.")

            log(
                "RX ECU: ${
                    raw.copyOfRange(
                        CMD_START_COMM.size,
                        raw.size
                    ).toHex()
                }"
            )
        } else {
            log("RX START: ${raw.toHex()}")
        }

        log("Start Communication tidak mendapat respons valid.")

        return false
    }

    // =========================================================
    // FAST INIT
    // =========================================================

    suspend fun performFastInit(): Boolean =
        transactionMutex.withLock {
            withContext(Dispatchers.IO) {
                if (!portOpened) {
                    log("Fast Init gagal: port belum terbuka.")
                    return@withContext false
                }

                communicationStarted = false

                try {
                    log("=== MULAI FAST INIT ===")

                    clearReceiveBuffers()

                    log("Wake-up: LOW 70 ms, HIGH 120 ms")

                    serialPort.setBreak(true)
                    delay(70)

                    serialPort.setBreak(false)
                    delay(120)

                    clearReceiveBuffers()

                    log("TX START: ${CMD_START_COMM.toHex()}")

                    serialPort.write(CMD_START_COMM)

                    val startResponse = readStartResponse(500L)

                    if (!startResponse) {
                        log("Start Communication gagal.")
                        return@withContext false
                    }

                    log("Start Communication diterima.")

                    // Beri waktu singkat sebelum Keep Alive.
                    delay(10)

                    clearReceiveBuffers()

                    log("TX KEEP ALIVE: ${CMD_KEEP_ALIVE.toHex()}")

                    serialPort.write(CMD_KEEP_ALIVE)

                    val keepAliveResponse = readFrame(500L)

                    if (keepAliveResponse == null) {
                        log("Keep Alive tidak mendapat respons.")
                        return@withContext false
                    }

                    if (
                        !keepAliveResponse.contentEquals(
                            EXPECTED_KEEP_ALIVE_RESPONSE
                        )
                    ) {
                        log(
                            "Respons Keep Alive tidak cocok: " +
                                keepAliveResponse.toHex()
                        )

                        return@withContext false
                    }

                    communicationStarted = true

                    log(
                        "Keep Alive diterima: " +
                            keepAliveResponse.toHex()
                    )

                    log("=== FAST INIT BERHASIL ===")

                    true

                } catch (e: Exception) {
                    communicationStarted = false

                    log("Fast Init error: ${e.message}")

                    false
                }
            }
        }

    // =========================================================
    // TRANSACTION
    // =========================================================

    private suspend fun transact(
        command: ByteArray,
        timeoutMs: Long = 700L,
        expectedType: Int? = null,
        expectedTable: Int? = null
    ): ByteArray? {
        return transactionMutex.withLock {
            withContext(Dispatchers.IO) {
                if (!portOpened || !communicationStarted) {
                    log("Transaksi dibatalkan: ECU belum siap.")
                    return@withContext null
                }

                try {
                    // Bersihkan sisa data transaksi sebelumnya.
                    clearReceiveBuffers()

                    log("TX: ${command.toHex()}")

                    serialPort.write(command)

                    val startTime = System.currentTimeMillis()

                    while (
                        System.currentTimeMillis() - startTime < timeoutMs
                    ) {
                        val remaining =
                            timeoutMs -
                                (System.currentTimeMillis() - startTime)

                        if (remaining <= 0) break

                        val frame = readFrame(
                            minOf(150L, remaining)
                        ) ?: continue

                        val type =
                            frame.getOrNull(2)?.toInt()?.and(0xFF)

                        val table =
                            frame.getOrNull(3)?.toInt()?.and(0xFF)

                        if (
                            expectedType != null &&
                            type != expectedType
                        ) {
                            log(
                                "Frame diabaikan, tipe tidak cocok: " +
                                    frame.toHex()
                            )
                            continue
                        }

                        if (
                            expectedTable != null &&
                            table != expectedTable
                        ) {
                            log(
                                "Frame diabaikan, tabel tidak cocok: " +
                                    frame.toHex()
                            )
                            continue
                        }

                        log("RX: ${frame.toHex()}")

                        parseHondaResponse(frame)

                        return@withContext frame
                    }

                    log("Timeout menunggu respons ECU.")

                    null

                } catch (e: Exception) {
                    log("Transaksi error: ${e.message}")
                    null
                }
            }
        }
    }

    // =========================================================
    // LIVE DATA API
    // =========================================================

    suspend fun requestLiveTable(
        table: Int
    ): ByteArray? {
        val command = when (table) {
            0x10 -> CMD_LIVE_DATA
            0x11 -> CMD_T11
            0x13 -> CMD_T13
            0x20 -> CMD_T20
            0xD1 -> CMD_TD1

            else -> {
                log(
                    "Tabel live data tidak dikenal: " +
                        table.toString(16)
                )
                return null
            }
        }

        return transact(
            command = command,
            timeoutMs = 800L,
            expectedType = 0x71,
            expectedTable = table
        )
    }

    suspend fun requestLiveData(): Boolean {
        return requestLiveTable(0x10) != null
    }

    // =========================================================
    // KEEP ALIVE
    // =========================================================

    suspend fun sendKeepAlive(): Boolean {
        val response = transact(
            command = CMD_KEEP_ALIVE,
            timeoutMs = 500L
        ) ?: return false

        val valid = response.contentEquals(
            EXPECTED_KEEP_ALIVE_RESPONSE
        )

        if (!valid) {
            log("Keep Alive tidak valid: ${response.toHex()}")
        }

        return valid
    }

    // =========================================================
    // DTC
    // =========================================================

    suspend fun readDtcTables(): List<ByteArray> {
        val results = mutableListOf<ByteArray>()

        val first = transact(
            command = CMD_READ_DTC,
            timeoutMs = 900L,
            expectedType = 0x73
        )

        if (first != null) {
            results.add(first)
        }

        val second = transact(
            command = CMD_READ_DTC_TABLE_01,
            timeoutMs = 700L
        )

        if (second != null) {
            results.add(second)
        }

        if (results.isEmpty()) {
            log("Tidak ada respons pembacaan DTC.")
        }

        return results
    }

    suspend fun clearDtcTable01(): ByteArray? {
        return transact(
            command = CMD_CLEAR_DTC,
            timeoutMs = 800L
        )
    }

    // =========================================================
    // RAW COMMAND
    // =========================================================

    fun sendCommand(command: ByteArray) {
        if (!portOpened) {
            log("Perintah gagal: port belum terbuka.")
            return
        }

        try {
            log("TX RAW: ${command.toHex()}")
            serialPort.write(command)
        } catch (e: Exception) {
            log("TX RAW error: ${e.message}")
        }
    }

    // =========================================================
    // LEGACY POLLING
    // =========================================================

    fun pollEngineData() {
        // Semua pembacaan harus menggunakan transact().
    }

    // =========================================================
    // RESPONSE PARSER
    // =========================================================

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return

        try {
            val responseType =
                data[2].toInt() and 0xFF

            val tableId =
                data[3].toInt() and 0xFF

            val sensorList = mutableListOf<SensorItem>()

            // -------------------------------------------------
            // TABLE 10
            // -------------------------------------------------

            if (
                responseType == 0x71 &&
                tableId == 0x10 &&
                data.size >= 22
            ) {
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF

                val calculatedRpm =
                    (rpmH shl 8) or rpmL

                val tpsVolt =
                    (data[6].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val tpsDeg =
                    (data[7].toInt() and 0xFF) * 0.5f

                val ectVolt =
                    (data[8].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val ect =
                    (data[9].toInt() and 0xFF) - 40

                val iatVolt =
                    (data[10].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val iat =
                    (data[11].toInt() and 0xFF) - 40

                val mapVolt =
                    (data[12].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val mapKpa =
                    data[13].toInt() and 0xFF

                val battery =
                    (data[16].toInt() and 0xFF) * 0.1f

                val speed =
                    data[21].toInt() and 0xFF

                val engineData = EngineData(
                    rpm = calculatedRpm,
                    tpsDeg = tpsDeg,
                    tpsVolt = tpsVolt,
                    ect = ect,
                    ectVolt = ectVolt,
                    iat = iat,
                    iatVolt = iatVolt,
                    mapKpa = mapKpa,
                    mapVolt = mapVolt,
                    battery = battery,
                    afr = Float.NaN,
                    o2Volt = Float.NaN,
                    engineLoad = Float.NaN,
                    iacv = -1,
                    injectorMs = Float.NaN,
                    speedKmh = speed
                )

                onDataReceived?.invoke(engineData)

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "RPM",
                        "$calculatedRpm"
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "TPS",
                        String.format("%.1f°", tpsDeg),
                        String.format("%.2f V", tpsVolt)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "ECT",
                        "${ect} °C",
                        String.format("%.2f V", ectVolt)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "IAT",
                        "${iat} °C",
                        String.format("%.2f V", iatVolt)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "MAP",
                        "$mapKpa kPa",
                        String.format("%.2f V", mapVolt)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 10",
                        "Battery",
                        String.format("%.1f V", battery)
                    )
                )

                onSensorDetailReceived?.invoke(sensorList)
            }

            // -------------------------------------------------
            // TABLE 11
            // -------------------------------------------------

            else if (
                responseType == 0x71 &&
                tableId == 0x11 &&
                data.size >= 15
            ) {
                val tpsV =
                    (data[6].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val mapV =
                    (data[7].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val bat =
                    (data[9].toInt() and 0xFF) * 0.1f

                val injMs =
                    (
                        (data[10].toInt() and 0xFF) * 256 +
                            (data[11].toInt() and 0xFF)
                    ) * 0.001f

                sensorList.add(
                    SensorItem(
                        "TABEL 11",
                        "TPS Voltage",
                        "--",
                        String.format("%.2f V", tpsV)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 11",
                        "MAP Voltage",
                        "--",
                        String.format("%.2f V", mapV)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 11",
                        "Battery Voltage",
                        "--",
                        String.format("%.1f V", bat)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 11",
                        "Injector Pulse",
                        String.format("%.2f ms", injMs)
                    )
                )

                onSensorDetailReceived?.invoke(sensorList)
            }

            // -------------------------------------------------
            // TABLE 13
            // -------------------------------------------------

            else if (
                responseType == 0x71 &&
                tableId == 0x13 &&
                data.size >= 15
            ) {
                val ign =
                    (
                        (data[10].toInt() and 0xFF) - 64
                    ) * 0.5f

                sensorList.add(
                    SensorItem(
                        "TABEL 13",
                        "Ignition Timing",
                        String.format("%.1f BTDC", ign)
                    )
                )

                onSensorDetailReceived?.invoke(sensorList)
            }

            // -------------------------------------------------
            // TABLE 20
            // -------------------------------------------------

            else if (
                responseType == 0x71 &&
                tableId == 0x20 &&
                data.size >= 10
            ) {
                val o2V =
                    (data[4].toInt() and 0xFF) *
                        (5.0f / 256.0f)

                val stft =
                    (
                        (data[5].toInt() and 0xFF) /
                            128.0f
                    ) * 100f

                sensorList.add(
                    SensorItem(
                        "TABEL 20",
                        "O2 Sensor Voltage",
                        "--",
                        String.format("%.2f V", o2V)
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL 20",
                        "Short Term Fuel Trim",
                        String.format("%.1f %%", stft)
                    )
                )

                onSensorDetailReceived?.invoke(sensorList)
            }

            // -------------------------------------------------
            // TABLE D1
            // -------------------------------------------------

            else if (
                responseType == 0x71 &&
                tableId == 0xD1 &&
                data.size >= 15
            ) {
                val d9 =
                    data[4].toInt() and 0xFF

                val d13 =
                    data[8].toInt() and 0xFF

                sensorList.add(
                    SensorItem(
                        "TABEL D1",
                        "Fuel Pump",
                        if (d9 == 0x01 || d9 == 0x05) {
                            "ON"
                        } else {
                            "OFF"
                        }
                    )
                )

                sensorList.add(
                    SensorItem(
                        "TABEL D1",
                        "Cooling Fan",
                        if (d13 == 0x01) "ON" else "OFF"
                    )
                )

                onSensorDetailReceived?.invoke(sensorList)
            }

            // -------------------------------------------------
            // DTC RESPONSE
            // -------------------------------------------------

            else if (responseType == 0x73) {
                val dtcList = mutableListOf<String>()

                for (i in 4 until data.size - 1 step 2) {
                    if (i + 1 >= data.size - 1) break

                    val code1 =
                        data[i].toInt() and 0xFF

                    val code2 =
                        data[i + 1].toInt() and 0xFF

                    if (code1 != 0 || code2 != 0) {
                        dtcList.add(
                            String.format(
                                "%02d-%02d",
                                code1,
                                code2
                            )
                        )
                    }
                }

                onDtcReceived?.invoke(dtcList)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error parsing response", e)
            log("Kesalahan parsing respons ECU: ${e.message}")
        }
    }
}
