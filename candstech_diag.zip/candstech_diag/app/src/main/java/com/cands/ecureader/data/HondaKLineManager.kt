package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null

    // EXACT COMMANDS FROM DOCUMENTATION SCREENSHOT:
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()) // FE 04 72 8C
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()) // 72 05 00 F0 99
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08) // Read Table 0x10
    
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.setDTR(false)
        serialPort.setRTS(false)
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Mulai Init KWP2000 Sesuai Dokumentasi (70ms LOW, 120ms HIGH)")
            
            // 1. Tarik LOW selama 70ms (Menggunakan trik 128 baud untuk 1 byte 0x00)
            serialPort.setBaudRate(128)
            serialPort.write(byteArrayOf(0x00))
            delay(90) // Jeda hardware 70ms + buffer
            
            // 2. Lepas jalur ke HIGH (12V) selama 120ms
            serialPort.setBaudRate(10400)
            delay(120)
            
            // 3. Kirim Paket Wakeup: FE 04 72 8C
            Log.d(TAG, "Kirim Wakeup: FE 04 72 8C")
            serialPort.write(CMD_WAKEUP)
            delay(150) // Tunggu ECU siap
            
            // 4. Kirim Init Command: 72 05 00 F0 99
            rxQueue.clear()
            Log.d(TAG, "Kirim Init Command: 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            delay(100)
            
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    fun pollEngineData() {
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte() && rxQueue.peek() != 0x72.toByte()) {
            rxQueue.poll()
        }

        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF

            if (expectedLength in 4..50) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) {
                        buffer[i] = rxQueue.poll()!!
                    }
                    parseHondaResponse(buffer)
                }
            } else {
                rxQueue.poll()
            }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            // Table 0x10 Response (Length 22 -> 0x16)
            if (responseType == 0x71 && data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && data.size >= 21) {
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineLoad = (tpsPercentRaw / 255.0f) * 100f
                val afr = 14.7f
                val o2Volt = 0.0f
                val iacv = 0
                val injectorMs = 0.0f

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, afr = afr, o2Volt = o2Volt,
                    engineLoad = engineLoad, iacv = iacv, injectorMs = injectorMs
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parsing Error: ${e.message}")
        }
    }
}
