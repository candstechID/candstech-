package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float, val speedKmh: Int
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val TAG = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    var onDataReceived: ((EngineData) -> Unit)? = null

    // 1. Pesan Protokol sesuai kode C++ andreibaw
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    // Query 71 Tabel 10 sesuai Gambar SMK Gajah Mada
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08) 

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) rxQueue.add(b)
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
    }

    // 2. Fungsi Perhitungan Checksum Otomatis (CS = 100h - SUM)
    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length) {
            sum += data[i].toInt() and 0xFF
        }
        return (0x100 - (sum and 0xFF)).toByte()
    }

    // 3. Proses Inisialisasi / Wake Up Presisi
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Memulai Wake Up K-Line")
            
            // Tx = Low (70 ms) menggunakan fitur Set Break FTDI
            serialPort.setBreak(true)
            delay(70)
            serialPort.setBreak(false)
            
            // Tx = High (120 ms)
            delay(120)
            
            // Kirim Wakeup (FE 04 FF FF)
            serialPort.write(CMD_WAKEUP)
            delay(50) 
            
            // Bersihkan sisa buffer lalu kirim Init (72 05 00 F0 99)
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP)
            delay(100) 
            
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    fun pollEngineData() {
        // Cari header response (0x02)
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) {
            rxQueue.poll()
        }

        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF 

            if (expectedLength in 5..60) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) buffer[i] = rxQueue.poll()!!
                    
                    // Verifikasi Checksum sebelum parsing
                    val calcCs = calculateChecksum(buffer, expectedLength - 1)
                    val rxCs = buffer[expectedLength - 1]
                    
                    if (calcCs == rxCs) {
                        parseHondaResponse(buffer)
                    }
                }
            } else {
                rxQueue.poll()
            }
        }
    }

    // 4. Parser Data Tabel 10 Sesuai Rumus Gambar 1 & C++
    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 22) return 
        
        try {
            val responseType = data[2].toInt() and 0xFF
            val tableId = data[3].toInt() and 0xFF

            if (responseType == 0x71 && tableId == 0x10) {
                // Header length = 4, jadi D9 dimulai dari index 4
                
                // RPM = (D9 * 256) + D10
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF
                val calculatedRpm = (rpmH shl 8) or rpmL

                // TPS Volt (D11) & TPS % (D12)
                val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f

                // ECT Volt (D13) & ECT °C (D14)
                val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                val ect = (data[9].toInt() and 0xFF) - 40

                // IAT Volt (D15) & IAT °C (D16)
                val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                val iat = (data[11].toInt() and 0xFF) - 40

                // MAP Volt (D17) & MAP kPa (D18)
                val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapKpa = data[13].toInt() and 0xFF

                // Baterai (D21)
                val battery = (data[16].toInt() and 0xFF) * 0.1f

                // Kecepatan (D26)
                val speed = data[21].toInt() and 0xFF

                val engineData = EngineData(
                    rpm = calculatedRpm,
                    tpsDeg = tpsDeg,
                    tpsVolt = tpsVolt,
                    ect = ect,
                    ectVolt = ectVolt,
                    iat = iat,
                    iatVolt = iatVolt,
                    mapKpa = mapKpa,
                    mapVolt = mapVolt,
                    battery = battery,
                    speedKmh = speed,
                    afr = 14.7f,
                    o2Volt = 0.45f,
                    engineLoad = (tpsVolt / 5f) * 100f,
                    iacv = 30,
                    injectorMs = 2.5f
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error Parsing: ${e.message}")
        }
    }
}
