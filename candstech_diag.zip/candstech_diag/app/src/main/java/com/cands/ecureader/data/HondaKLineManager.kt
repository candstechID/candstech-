package com.cands.ecureader.data

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class HondaKLineManager(private val usbManager: UsbManager) {
    private var serialDevice: UsbSerialDevice? = null
    private var connection: UsbDeviceConnection? = null
    var isConnected: Boolean = false
        private set

    suspend fun connect(device: UsbDevice): Boolean = withContext(Dispatchers.IO) {
        try {
            connection = usbManager.openDevice(device)
            if (connection == null) return@withContext false

            val deviceInstance = UsbSerialDevice.createUsbSerialDevice(device, connection)
            serialDevice = deviceInstance
            
            if (deviceInstance == null || !deviceInstance.open()) {
                connection?.close()
                return@withContext false
            }

            // Baud rate standar K-Line Honda PGM-FI: 10400
            deviceInstance.setBaudRate(10400)
            deviceInstance.setDataBits(UsbSerialInterface.DATA_BITS_8)
            deviceInstance.setStopBits(UsbSerialInterface.STOP_BITS_1)
            deviceInstance.setParity(UsbSerialInterface.PARITY_NONE)
            deviceInstance.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)

            // Eksekusi Inisialisasi Cepat & Wakeup KWP2000 Honda
            performHondaFastInit(deviceInstance)

            isConnected = true
            true
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Connection error", e)
            disconnect()
            false
        }
    }

    private suspend fun performHondaFastInit(device: UsbSerialDevice) = withContext(Dispatchers.IO) {
        try {
            // Timing Fast Init Honda: Break Low 70ms, High 120ms
            device.setBreak(true)
            delay(70)
            device.setBreak(false)
            delay(120)
            
            // Kirim frame Wake-up / Start Diagnostic Session
            val wakeupBytes = hexStringToByteArray("FE 04 72 8C")
            device.syncWrite(wakeupBytes, 300)
            delay(50)

            // Kirim frame konfirmasi Inisialisasi Sesi
            val initBytes = hexStringToByteArray("72 05 00 F0 99")
            device.syncWrite(initBytes, 300)
            delay(50)

            Log.d("HondaKLineManager", "Honda Fast Init & Wakeup berhasil dikirim.")
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Fast init gagal", e)
        }
    }

    suspend fun requestLiveData(): Map<String, Any> = withContext(Dispatchers.IO) {
        val result = mutableMapOf<String, Any>(
            "rpm" to "0",
            "tps" to "0°",
            "temp" to "--°C",
            "voltage" to "13.2 V",
            "map" to "0 kPa",
            "iat" to "--°C",
            "iacv" to "0 %",
            "injector" to "0.0 ms"
        )
        val device = serialDevice
        if (!isConnected || device == null) return@withContext result

        try {
            // Frame request Live Data PGM-FI (PID 71 17 01)
            val requestBytes = hexStringToByteArray("72 05 71 17 01")
            device.syncWrite(requestBytes, 300)

            val buffer = ByteArray(128)
            val bytesRead = device.syncRead(buffer, 300)
            if (bytesRead > 0) {
                val response = buffer.copyOfRange(0, bytesRead)
                Log.d("HondaKLineManager", "Respon ECU (${response.size} bytes): ${response.contentToString()}")
                
                if (response.size >= 12) {
                    // Parsing RPM (Byte ke-6 & 7)
                    val rawRpm = ((response[6].toInt() and 0xFF) shl 8) or (response[7].toInt() and 0xFF)
                    result["rpm"] = if (rawRpm > 0) (rawRpm / 4).toString() else "0"
                    
                    // Parsing TPS (Byte ke-8)
                    val rawTps = response[8].toInt() and 0xFF
                    result["tps"] = "$rawTps°"
                    
                    // Parsing Suhu Mesin (Byte ke-10)
                    val rawTemp = (response[10].toInt() and 0xFF) - 40
                    result["temp"] = "$rawTemp°C"
                }
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Gagal membaca live data", e)
        }
        return@withContext result
    }

    suspend fun sendCommand(hexCommand: String): ByteArray? = withContext(Dispatchers.IO) {
        val device = serialDevice
        if (!isConnected || device == null) return@withContext null
        try {
            val bytes = hexStringToByteArray(hexCommand)
            device.syncWrite(bytes, 1000)
            val buffer = ByteArray(64)
            val n = device.syncRead(buffer, 500)
            if (n > 0) return@withContext buffer.copyOfRange(0, n)
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Command error: $hexCommand", e)
        }
        return@withContext null
    }

    fun disconnect() {
        try {
            serialDevice?.close()
            connection?.close()
        } catch (_: Exception) {}
        serialDevice = null
        connection = null
        isConnected = false
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val clean = s.replace(" ", "")
        val len = clean.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(clean[i], 16) shl 4) + Character.digit(clean[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
