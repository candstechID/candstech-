package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onLogReceived: ((String) -> Unit)? = null

    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    private fun logToUi(msg: String) {
        Log.d(TAG, msg)
        onLogReceived?.invoke(msg)
    }

    fun setupPort() {
        try {
            if (serialPort.isOpen) serialPort.close()
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.setDTR(false)
            serialPort.setRTS(false)
            serialPort.read(mCallback)
            logToUi("Port dibuka @ 10400 baud")
        } catch (e: Exception) {
            logToUi("Gagal setup port: ${e.message}")
        }
    }

    suspend fun performSlowInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            logToUi("=== SLOW INIT (ISO 9141) ===")
            
            serialPort.setBaudRate(5)
            delay(50)
            serialPort.write(byteArrayOf(0x33))
            delay(200)
            
            serialPort.setBaudRate(10400)
            delay(120)
            
            safeClearQueue()
            logToUi("Menunggu respons ECU (0x55 atau 0x4B)...")
            val resp1 = readAvailableBytes(5, 300)
            logToUi("Slow Init Resp 1: ${resp1.joinToString(" ") { "%02X".format(it) }}")
            
            val hasAck = resp1.contains(0x55.toByte()) || resp1.contains(0x4B.toByte())
            if (!hasAck) {
                logToUi("Slow Init: ECU tidak merespons 0x55/0x4B")
                return@withContext false
            }
            
            delay(25)
            serialPort.write(byteArrayOf(0x08))
            logToUi("Kirim ACK 0x08")
            
            delay(50)
            val resp2 = readAvailableBytes(5, 200)
            logToUi("Slow Init Resp 2: ${resp2.joinToString(" ") { "%02X".format(it) }}")
            
            if (resp2.contains(0x08.toByte())) {
                logToUi("✅ SLOW INIT BERHASIL")
                return@withContext true
            }
            
            logToUi("Slow Init: ACK 0x08 tidak diterima")
            return@withContext false
            
        } catch (e: Exception) {
            logToUi("Slow Init exception: ${e.message}")
            return@withContext false
        }
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            logToUi("=== FAST INIT (KWP2000) ===")
            
            serialPort.setBaudRate(300)
            delay(50)
            serialPort.write(byteArrayOf(0x00, 0x00))
            delay(70)
            
            serialPort.setBaudRate(10400)
            delay(120)
            
            safeClearQueue()
            logToUi("Kirim WAKEUP: FE 04 72 8C")
            serialPort.write(CMD_WAKEUP)
            delay(150)
            
            val wakeupResp = readAvailableBytes(10, 200)
            logToUi("Wakeup Resp: ${wakeupResp.joinToString(" ") { "%02X".format(it) }}")
            
            val wakeupValid = wakeupResp.contains(0x72.toByte()) && 
                             wakeupResp.contains(0x7C.toByte())
            if (!wakeupValid) {
                logToUi("Fast Init: Wakeup gagal")
                return@withContext false
            }
            
            safeClearQueue()
            logToUi("Kirim INIT: 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            delay(150)
            
            val initResp = readAvailableBytes(10, 200)
            logToUi("Init Resp: ${initResp.joinToString(" ") { "%02X".format(it) }}")
            
            val initValid = initResp.size >= 4 &&
                           initResp[0] == 0x02.toByte() &&
                           initResp[1] == 0x04.toByte() &&
                           initResp[2] == 0x00.toByte() &&
                           initResp[3] == 0xFA.toByte()
            
            if (initValid) {
                logToUi("✅ FAST INIT BERHASIL")
                return@withContext true
            }
            
            logToUi("Fast Init: Response init tidak valid")
            return@withContext false
            
        } catch (e: Exception) {
            logToUi("Fast Init exception: ${e.message}")
            return@withContext false
        }
    }

    suspend fun performUniversalInit(): Boolean = withContext(Dispatchers.IO) {
        logToUi("🔄 UNIVERSAL INIT: Mencoba Slow Init...")
        
        val slowSuccess = performSlowInit()
        if (slowSuccess) {
            return@withContext true
        }
        
        logToUi("⚠️ Slow Init gagal, mencoba Fast Init...")
        delay(500)
        
        try {
            serialPort.setBaudRate(10400)
            delay(100)
        } catch (e: Exception) {
            logToUi("Reset baud rate gagal: ${e.message}")
        }
        
        val fastSuccess = performFastInit()
        return@withContext fastSuccess
    }

    fun sendCommand(command: ByteArray) {
        try {
            serialPort.write(command)
        } catch (e: Exception) {
            logToUi("Send command failed: ${e.message}")
        }
    }

    fun pollEngineData() {
        try {
            while (rxQueue.isNotEmpty() && 
                   rxQueue.peek() != 0x02.toByte() && 
                   rxQueue.peek() != 0x72.toByte()) {
                rxQueue.poll()
            }

            if (rxQueue.size >= 2) {
                val iterator = rxQueue.iterator()
                if (!iterator.hasNext()) return
                iterator.next()
                if (!iterator.hasNext()) return
                
                val expectedLength = iterator.next().toInt() and 0xFF

                if (expectedLength in 4..50) {
                    if (rxQueue.size >= expectedLength) {
                        val buffer = ByteArray(expectedLength)
                        for (i in 0 until expectedLength) {
                            buffer[i] = rxQueue.poll()!!
                        }
                        parseHondaResponse(buffer)
                    }
                } else {
                    rxQueue.poll()
                }
            }
        } catch (e: Exception) {
            logToUi("Poll error: ${e.message}")
        }
    }

    private fun safeClearQueue() {
        while (rxQueue.isNotEmpty()) {
            rxQueue.poll()
        }
    }

    private suspend fun readAvailableBytes(maxBytes: Int, timeoutMs: Long): ByteArray {
        val result = mutableListOf<Byte>()
        val startTime = System.currentTimeMillis()
        
        while (result.size < maxBytes && 
               (System.currentTimeMillis() - startTime) < timeoutMs) {
            if (rxQueue.isNotEmpty()) {
                result.add(rxQueue.poll()!!)
            } else {
                delay(10)
            }
        }
        
        return result.toByteArray()
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            if (responseType == 0x71 && 
                data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && 
                data.size >= 21) {
                
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, 
                    afr = 14.7f, o2Volt = 0.0f, engineLoad = tpsDegrees, 
                    iacv = 0, injectorMs = 0.0f
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            logToUi("Parsing error: ${e.message}")
        }
    }
}