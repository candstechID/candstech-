package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onLogReceived: ((String) -> Unit)? = null

    // Perintah sesuai Poster Protokol Honda PGM-FI
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    private fun logToUi(msg: String) {
        Log.d(TAG, msg)
        onLogReceived?.invoke(msg)
    }

    fun setupPort() {
        try {
            if (serialPort.isOpen) serialPort.close()
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.setDTR(true)
            serialPort.setRTS(true)
            serialPort.read(mCallback)
            logToUi("Port siap @ 10400 baud")
        } catch (e: Exception) {
            logToUi("Gagal setup port: ${e.message}")
        }
    }

    // ==========================================
    // FAST INIT (Sesuai Poster SMK Gajah Mada)
    // Menggunakan "Port Reopen Trick" untuk timing hardware yang presisi di Android
    // ==========================================
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            logToUi("=== FAST INIT (Hardware Reset Method) ===")
            
            // STEP 1: WAKE UP PHYSICAL LAYER (Tx LOW 70ms)
            logToUi("Step 1: Force Tx LOW (Reopen @ 300 baud)")
            serialPort.close()
            delay(100)
            serialPort.open()
            serialPort.setBaudRate(300)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.setDTR(true)
            serialPort.setRTS(true)
            serialPort.read(mCallback)
            delay(50)
            
            // Kirim 0x00. Di 300 baud, 3 byte = ~100ms (aman, > 70ms requirement)
            serialPort.write(byteArrayOf(0x00, 0x00, 0x00))
            delay(50) 
            
            // STEP 2: Tx HIGH 120ms
            logToUi("Step 2: Force Tx HIGH (Reopen @ 10400 baud)")
            serialPort.close()
            delay(100)
            serialPort.open()
            serialPort.setBaudRate(10400)
            serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort.setDTR(true)
            serialPort.setRTS(true)
            serialPort.read(mCallback)
            
            delay(120) // Tunggu HIGH stabil 120ms sesuai poster
            
            // STEP 3: START COMMUNICATION
            safeClearQueue()
            logToUi("Step 3: Kirim START COMM: FE 04 72 8C")
            serialPort.write(CMD_WAKEUP)
            delay(300)
            
            val wakeupResp = readAvailableBytes(30, 500)
            logToUi("Wakeup Resp: ${wakeupResp.joinToString(" ") { "%02X".format(it) }}")
            
            // Validasi: Harus ada pola 0E 04 72 7C (mengabaikan echo FTDI di depannya)
            val hasWakeupAck = findPattern(wakeupResp, byteArrayOf(
                0x0E.toByte(), 0x04.toByte(), 0x72.toByte(), 0x7C.toByte()
            ))
            
            if (!hasWakeupAck) {
                logToUi("❌ Start Communication gagal")
                logToUi("   Expected: 0E 04 72 7C")
                return@withContext false
            }
            
            logToUi("✅ Start Communication berhasil!")
            
            // STEP 4: KEEP ALIVE (Init)
            delay(50)
            safeClearQueue()
            logToUi("Step 4: Kirim KEEP ALIVE: 72 05 00 F0 99")
            serialPort.write(CMD_INIT_KWP)
            delay(300)
            
            val initResp = readAvailableBytes(30, 500)
            logToUi("Keep Alive Resp: ${initResp.joinToString(" ") { "%02X".format(it) }}")
            
            // Validasi: Harus ada pola 02 04 00 FA
            val hasInitAck = findPattern(initResp, byteArrayOf(
                0x02.toByte(), 0x04.toByte(), 0x00.toByte(), 0xFA.toByte()
            ))
            
            if (hasInitAck) {
                logToUi("✅ KEEP ALIVE BERHASIL - ECU SIAP!")
                return@withContext true
            }
            
            logToUi("❌ Keep Alive gagal")
            logToUi("   Expected: 02 04 00 FA")
            return@withContext false
            
        } catch (e: Exception) {
            logToUi("Fast Init exception: ${e.message}")
            return@withContext false
        }
    }

    suspend fun performSlowInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            logToUi("=== SLOW INIT (Fallback) ===")
            serialPort.setBaudRate(5)
            delay(100)
            serialPort.write(byteArrayOf(0x33))
            delay(250)
            serialPort.setBaudRate(10400)
            delay(150)
            safeClearQueue()
            
            val resp1 = readAvailableBytes(5, 400)
            logToUi("Slow Resp 1: ${resp1.joinToString(" ") { "%02X".format(it) }}")
            
            if (resp1.contains(0x55.toByte()) || resp1.contains(0x4B.toByte())) {
                delay(30)
                serialPort.write(byteArrayOf(0x08))
                delay(100)
                val resp2 = readAvailableBytes(5, 300)
                if (resp2.contains(0x08.toByte())) {
                    logToUi("✅ SLOW INIT BERHASIL")
                    return@withContext true
                }
            }
            logToUi("❌ SLOW INIT GAGAL")
            return@withContext false
        } catch (e: Exception) {
            logToUi("Slow Init exception: ${e.message}")
            return@withContext false
        }
    }

    suspend fun performUniversalInit(): Boolean = withContext(Dispatchers.IO) {
        logToUi("🔄 UNIVERSAL INIT: Memulai...")
        
        // Coba Fast Init dulu (paling umum untuk motor FI)
        if (performFastInit()) {
            return@withContext true
        }
        
        // Jika gagal, tunggu sebentar lalu coba Slow Init
        logToUi("⚠️ Fast Init gagal, mencoba Slow Init...")
        delay(1000)
        
        if (performSlowInit()) {
            return@withContext true
        }
        
        logToUi("❌ SEMUA INIT GAGAL")
        logToUi("💡 Pastikan: Kontak ON, Kabel K-Line benar, Aki sehat")
        return@withContext false
    }

    fun sendCommand(command: ByteArray) {
        try {
            serialPort.write(command)
        } catch (e: Exception) {
            logToUi("Send command failed: ${e.message}")
        }
    }

    fun pollEngineData() {
        try {
            while (rxQueue.isNotEmpty() && 
                   rxQueue.peek() != 0x02.toByte() && 
                   rxQueue.peek() != 0x72.toByte()) {
                rxQueue.poll()
            }

            if (rxQueue.size >= 2) {
                val iterator = rxQueue.iterator()
                if (!iterator.hasNext()) return
                iterator.next()
                if (!iterator.hasNext()) return
                
                val expectedLength = iterator.next().toInt() and 0xFF

                if (expectedLength in 4..50) {
                    if (rxQueue.size >= expectedLength) {
                        val buffer = ByteArray(expectedLength)
                        for (i in 0 until expectedLength) {
                            buffer[i] = rxQueue.poll()!!
                        }
                        parseHondaResponse(buffer)
                    }
                } else {
                    rxQueue.poll()
                }
            }
        } catch (e: Exception) {
            logToUi("Poll error: ${e.message}")
        }
    }

    private fun safeClearQueue() {
        while (rxQueue.isNotEmpty()) {
            rxQueue.poll()
        }
    }

    private suspend fun readAvailableBytes(maxBytes: Int, timeoutMs: Long): ByteArray {
        val result = mutableListOf<Byte>()
        val startTime = System.currentTimeMillis()
        
        while (result.size < maxBytes && 
               (System.currentTimeMillis() - startTime) < timeoutMs) {
            if (rxQueue.isNotEmpty()) {
                result.add(rxQueue.poll()!!)
            } else {
                delay(10)
            }
        }
        return result.toByteArray()
    }

    // Helper untuk mencari pola byte di dalam array data (mengabaikan posisi/echo)
    private fun findPattern(data: ByteArray, pattern: ByteArray): Boolean {
        if (pattern.isEmpty() || data.size < pattern.size) return false
        for (i in 0..(data.size - pattern.size)) {
            var match = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    match = false
                    break
                }
            }
            if (match) return true
        }
        return false
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data.getOrNull(2)?.toInt()?.and(0xFF) ?: 0
            
            if (responseType == 0x71 && 
                data.getOrNull(3)?.toInt()?.and(0xFF) == 0x10 && 
                data.size >= 21) {
                
                val rpmHigh = data.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
                val rpmLow = data.getOrNull(5)?.toInt()?.and(0xFF) ?: 0
                val calculatedRpm = (rpmHigh * 256) + rpmLow

                val tpsVoltRaw = data.getOrNull(6)?.toInt()?.and(0xFF) ?: 0
                val tpsVolt = (tpsVoltRaw / 255f) * 5.0f
                val tpsPercentRaw = data.getOrNull(7)?.toInt()?.and(0xFF) ?: 0
                val tpsDegrees = (tpsPercentRaw / 255f) * 100f

                val ectVoltRaw = data.getOrNull(8)?.toInt()?.and(0xFF) ?: 0
                val ectVolt = (ectVoltRaw / 255f) * 5.0f
                val ectDeg = data.getOrNull(9)?.toInt()?.and(0xFF) ?: 40

                val iatVoltRaw = data.getOrNull(10)?.toInt()?.and(0xFF) ?: 0
                val iatVolt = (iatVoltRaw / 255f) * 5.0f
                val iatDeg = data.getOrNull(11)?.toInt()?.and(0xFF) ?: 30

                val mapVoltRaw = data.getOrNull(12)?.toInt()?.and(0xFF) ?: 0
                val mapVolt = (mapVoltRaw / 255f) * 5.0f
                val mapKpa = data.getOrNull(13)?.toInt()?.and(0xFF) ?: 0

                val battRaw = data.getOrNull(16)?.toInt()?.and(0xFF) ?: 124
                val battery = battRaw / 10.0f
                
                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDegrees, tpsVolt = tpsVolt,
                    ect = ectDeg, ectVolt = ectVolt, iat = iatDeg, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, 
                    afr = 14.7f, o2Volt = 0.0f, engineLoad = tpsDegrees, 
                    iacv = 0, injectorMs = 0.0f
                )
                onDataReceived?.invoke(engineData)
            }
        } catch (e: Exception) {
            logToUi("Parsing error: ${e.message}")
        }
    }
}