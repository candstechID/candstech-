package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private var isReading = false

    var onDataReceived: ((rpm: Int, tpsDeg: Float, tpsVolt: Float, afr: Float, ect: Int, batt: Float) -> Unit)? = null

    val CMD_LIVE_DATA = byteArrayOf(0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0xFA.toByte())
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) {
                rxQueue.add(b)
            }
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
        isReading = true
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Memulai Fast Init K-Line (25ms LOW, 25ms HIGH)")
            serialPort.setBreak(true)
            delay(25)
            serialPort.setBreak(false)
            delay(25)
            
            rxQueue.clear()
            serialPort.write(CMD_LIVE_DATA)
            Log.d(TAG, "Fast Init Sukses, menunggu respon ECU...")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Fast Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun calculateChecksum(payload: ByteArray): Byte {
        var sum = 0
        for (byte in payload) {
            sum += byte.toInt() and 0xFF
        }
        return (sum and 0xFF).toByte()
    }

    fun sendCommand(command: ByteArray) {
        Log.d(TAG, "Mengirim Command: ${command.joinToString("") { "%02x ".format(it) }}")
        serialPort.write(command)
    }

    fun pollEngineData() {
        if (rxQueue.size >= 6) {
            val buffer = mutableListOf<Byte>()
            while (rxQueue.isNotEmpty()) {
                buffer.add(rxQueue.poll() ?: break)
            }
            parseHondaResponse(buffer.toByteArray())
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 6) return
        try {
            val byteA = data.getOrNull(2)?.toInt() and 0xFF ?: 0
            val byteB = data.getOrNull(3)?.toInt() and 0xFF ?: 0
            val calculatedRpm = ((byteA * 256) + byteB) / 4

            val tpsRaw = data.getOrNull(5)?.toInt() and 0xFF ?: 0
            val tpsVolt = (tpsRaw / 255f) * 5.0f
            val tpsDegrees = ((tpsVolt - 0.45f) / (4.5f - 0.45f)) * 80f

            val afr = 14.7f
            val ect = 85
            val battery = 12.4f

            onDataReceived?.invoke(calculatedRpm, tpsDegrees, tpsVolt, afr, ect, battery)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal parsing data ECU: ${e.message}")
        }
    }
}
