package com.cands.ecureader.data

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.felhr85.usbserial.UsbSerialDevice
import com.felhr85.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class HondaKLineManager(private val usbManager: UsbManager) {
    private var serialDevice: UsbSerialDevice? = null
    private var connection: UsbDeviceConnection? = null
    var isConnected: Boolean = false
        private set

    suspend fun connect(device: UsbDevice): Boolean = withContext(Dispatchers.IO) {
        try {
            connection = usbManager.openDevice(device)
            if (connection == null) return@withContext false

            serialDevice = UsbSerialDevice.createUsbSerialDevice(device, connection)
            if (serialDevice == null || !serialDevice!!.open()) {
                connection?.close()
                return@withContext false
            }

            // Configure K-Line parameters: 10400 Baud, 8 Data bits, 1 Stop bit, No Parity
            serialDevice!!.setBaudRate(10400)
            serialDevice!!.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialDevice!!.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialDevice!!.setParity(UsbSerialInterface.PARITY_ODD) // Or none depending on adapter, standard 8N1:
            serialDevice!!.setParity(UsbSerialInterface.PARITY_NONE)
            serialDevice!!.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)

            // Perform Honda Fast Init sequence
            performHondaFastInit()

            isConnected = true
            true
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Connection error", e)
            disconnect()
            false
        }
    }

    private suspend fun performHondaFastInit() = withContext(Dispatchers.IO) {
        try {
            // Honda K-Line Fast Init:
            // 1. Pull K-Line LOW for 25ms (Break state or RTS low)
            serialDevice?.setBreak(true)
            kotlinx.coroutines.delay(25)
            // 2. Pull K-Line HIGH for 25ms
            serialDevice?.setBreak(false)
            kotlinx.coroutines.delay(25)
            Log.d("HondaKLineManager", "Honda Fast Init completed successfully.")
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Fast init failed", e)
        }
    }

    suspend fun sendCommand(hexCommand: String): ByteArray? = withContext(Dispatchers.IO) {
        if (!isConnected || serialDevice == null) return@withContext null
        try {
            val bytes = hexStringToByteArray(hexCommand)
            serialDevice!!.syncWrite(bytes, 1000)
            
            // Read response buffer
            val buffer = ByteArray(64)
            val n = serialDevice!!.syncRead(buffer, 500)
            if (n > 0) {
                return@withContext buffer.copyOfRange(0, n)
            }
        } catch (e: Exception) {
            Log.e("HondaKLineManager", "Command error: $hexCommand", e)
        }
        return@withContext null
    }

    fun disconnect() {
        try {
            serialDevice?.close()
            connection?.close()
        } catch (_: Exception) {}
        serialDevice = null
        connection = null
        isConnected = false
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val clean = s.replace(" ", "")
        val len = clean.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(clean[i], 16) shl 4) + Character.digit(clean[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
