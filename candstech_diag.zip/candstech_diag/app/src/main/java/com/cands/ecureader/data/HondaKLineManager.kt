package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val TAG = "KLineManager"
    
    // Command Constants
    val CMD_LIVE_DATA = byteArrayOf(0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0xFA.toByte())
    val CMD_READ_DTC = byteArrayOf(0x02, 0x04, 0x10, 0xEA.toByte())
    val CMD_CLEAR_DTC = byteArrayOf(0x02, 0x04, 0x20, 0xDA.toByte())
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
    }

    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Memulai Fast Init K-Line (25ms LOW, 25ms HIGH)")
            serialPort.setBreak(true)
            delay(25)
            serialPort.setBreak(false)
            delay(25)
            
            serialPort.write(CMD_LIVE_DATA)
            Log.d(TAG, "Fast Init Sukses, mengirim Wake Up Request")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Fast Init Gagal: ${e.message}")
            return@withContext false
        }
    }

    fun calculateChecksum(payload: ByteArray): Byte {
        var sum = 0
        for (byte in payload) {
            sum += byte.toInt() and 0xFF
        }
        return (sum and 0xFF).toByte()
    }

    fun sendCommand(command: ByteArray) {
        // Asumsi command yang di-pass sudah termasuk checksum dari konstanta di atas
        // untuk simplifikasi, karena command Honda PGM-FI biasanya statis
        Log.d(TAG, "Mengirim Command: ${command.joinToString("") { "%02x ".format(it) }}")
        serialPort.write(command)
    }
}
