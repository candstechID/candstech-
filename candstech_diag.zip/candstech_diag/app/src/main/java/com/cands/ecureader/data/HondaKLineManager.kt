
package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Honda PGM-FI K-Line communication.
 *
 * Catatan:
 * - K-Line 10400 baud, 8N1.
 * - Wake-up LOW 70 ms, HIGH 120 ms.
 * - TX echo dari interface FTDI + optocoupler ditangani.
 * - Frame RX dikumpulkan berdasarkan LEN.
 * - Checksum divalidasi sebelum frame diteruskan ke parser.
 * - Pemetaan sensor tetap menggunakan HondaProtocolParser.
 */
data class EngineData(
    val rpm: Int,
    val tpsDeg: Float,
    val tpsVolt: Float,
    val ect: Int,
    val ectVolt: Float,
    val iat: Int,
    val iatVolt: Float,
    val mapKpa: Int,
    val mapVolt: Float,
    val battery: Float,
    val afr: Float,
    val o2Volt: Float,
    val engineLoad: Float,
    val iacv: Int,
    val injectorMs: Float,
    val speedKmh: Int
)

data class SensorItem(
    val category: String,
    val name: String,
    val value: String,
    val voltage: String = "--"
)

class HondaKLineManager(
    private val serialPort: UsbSerialDevice
) {

    private val tag = "HondaKLine"

    /*
     * Semua byte dari callback USB masuk ke rxQueue.
     * readDataFrame() menjadi satu-satunya pembaca antrean RX.
     */
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    /*
     * Buffer frame yang belum lengkap.
     * Byte yang datang terpisah tetap disimpan sampai frame lengkap.
     */
    private val rxBuffer = mutableListOf<Byte>()

    private val txLock = Any()

    @Volatile
    private var pendingTxEcho: ByteArray = byteArrayOf()

    @Volatile
    private var portOpened = false

    @Volatile
    private var sessionStarted = false

    @Volatile
    private var keepAliveRunning = false

    @Volatile
    private var activeLiveTable: Int? = null

    @Volatile
    private var engineTemperatureType: EngineTemperatureType =
        EngineTemperatureType.UNKNOWN

    @Volatile
    private var trafficDebugEnabled = false

    fun setEngineTemperatureType(type: EngineTemperatureType) {
        engineTemperatureType = type
    }

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onRawFrameReceived: ((ByteArray) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    fun setTrafficDebug(enabled: Boolean) {
        trafficDebugEnabled = enabled
    }

    private fun logTraffic(message: String) {
        if (trafficDebugEnabled) {
            onLog?.invoke(message)
        }
    }

    // START COMMUNICATION
    // TX: FE 04 72 8C
    // RX: 0E 04 72 7C

    private val cmdStartCommunication = byteArrayOf(
        0xFE.toByte(),
        0x04,
        0x72,
        0x8C.toByte()
    )

    // KEEP ALIVE
    // TX: 72 05 00 F0 99
    // RX: 02 04 00 FA

    private val cmdKeepAlive = byteArrayOf(
        0x72,
        0x05,
        0x00,
        0xF0.toByte(),
        0x99.toByte()
    )

    private val readCallback =
        UsbSerialInterface.UsbReadCallback { data ->

            if (data != null && data.isNotEmpty()) {

                /*
                 * Jangan parsing di callback USB.
                 * Callback hanya memasukkan byte ke antrean.
                 */
                for (byteValue in data) {
                    rxQueue.offer(byteValue)
                }

                logTraffic(
                    "USB RX CHUNK: ${hex(data)}"
                )
            }
        }

    // ---------------------------------------------------------
    // USB PORT
    // ---------------------------------------------------------

    fun setupPort() {
        try {
            onLog?.invoke(
                "Membuka USB serial 10400 baud..."
            )

            serialPort.open()

            serialPort.setBaudRate(10400)
            serialPort.setDataBits(
                UsbSerialInterface.DATA_BITS_8
            )
            serialPort.setStopBits(
                UsbSerialInterface.STOP_BITS_1
            )
            serialPort.setParity(
                UsbSerialInterface.PARITY_NONE
            )
            serialPort.setFlowControl(
                UsbSerialInterface.FLOW_CONTROL_OFF
            )

            serialPort.read(readCallback)

            portOpened = true

            onLog?.invoke(
                "Port terbuka. Format serial: 10400, 8N1."
            )

        } catch (e: Exception) {

            portOpened = false

            onLog?.invoke(
                "Gagal membuka port: ${e.message}"
            )

            Log.e(tag, "setupPort failed", e)
        }
    }

    fun closePort() {
        try {
            keepAliveRunning = false
            sessionStarted = false
            activeLiveTable = null
            portOpened = false

            clearRx()

            pendingTxEcho = byteArrayOf()

            serialPort.close()

            onLog?.invoke("Port ditutup.")

        } catch (e: Exception) {

            onLog?.invoke(
                "Kesalahan saat menutup port: ${e.message}"
            )
        }
    }

    // ---------------------------------------------------------
    // BYTE UTILITIES
    // ---------------------------------------------------------

    private fun hex(data: ByteArray): String =
        data.joinToString(" ") {
            "%02X".format(it.toInt() and 0xFF)
        }

    private fun logRx(data: ByteArray) {
        if (data.isNotEmpty()) {
            logTraffic("RX FRAME: ${hex(data)}")
            onRawFrameReceived?.invoke(data.copyOf())
        }
    }

    private fun u(data: ByteArray, index: Int): Int =
        data[index].toInt() and 0xFF

    private fun calculateChecksum(
        data: ByteArray,
        length: Int
    ): Byte {

        var sum = 0

        for (i in 0 until length.coerceAtMost(data.size)) {
            sum += data[i].toInt() and 0xFF
        }

        return (
            (0x100 - (sum and 0xFF)) and 0xFF
        ).toByte()
    }

    private fun buildQuery(
        query: Int,
        table: Int
    ): ByteArray {

        val frame = byteArrayOf(
            0x72,
            0x05,
            query.toByte(),
            table.toByte(),
            0x00
        )

        frame[4] = calculateChecksum(frame, 4)

        return frame
    }

    /**
     * Membersihkan antrean RX dan buffer frame.
     *
     * Dipanggil sebelum transaksi baru agar byte dari transaksi
     * sebelumnya tidak dianggap sebagai respons transaksi baru.
     */
    private fun clearRx() {
        rxQueue.clear()
        rxBuffer.clear()
    }

    /**
     * Mengirim frame dan menyimpan salinan TX untuk penanganan echo.
     */
    private fun writeFrame(frame: ByteArray) {
        synchronized(txLock) {

            pendingTxEcho = frame.copyOf()

            logTraffic(
                "TX: ${hex(frame)}"
            )

            serialPort.write(frame)
        }
    }

    // ---------------------------------------------------------
    // FIXED RESPONSE READER
    // ---------------------------------------------------------

    /**
     * Menunggu respons tetap seperti:
     *
     * START COMMUNICATION:
     * 0E 04 72 7C
     *
     * KEEP ALIVE:
     * 02 04 00 FA
     *
     * Mendukung RX yang masuk terpecah.
     */
    private suspend fun waitForExactResponse(
        expected: ByteArray,
        timeoutMs: Long = 1500
    ): ByteArray? {

        val received = mutableListOf<Byte>()
        val echoCandidate = mutableListOf<Byte>()

        val txEcho = pendingTxEcho
        pendingTxEcho = byteArrayOf()

        var matchingEcho = txEcho.isNotEmpty()

        val start = System.currentTimeMillis()

        while (
            System.currentTimeMillis() - start < timeoutMs
        ) {

            while (true) {

                val next = rxQueue.poll() ?: break

                if (matchingEcho) {

                    echoCandidate.add(next)

                    val prefixMatches =
                        echoCandidate.size <= txEcho.size &&
                        echoCandidate.indices.all {
                            echoCandidate[it] == txEcho[it]
                        }

                    if (prefixMatches) {

                        if (echoCandidate.size == txEcho.size) {

                            logTraffic(
                                "TX ECHO diabaikan: ${hex(txEcho)}"
                            )

                            echoCandidate.clear()
                            matchingEcho = false
                        }

                        continue

                    } else {

                        received.addAll(echoCandidate)

                        echoCandidate.clear()
                        matchingEcho = false
                    }

                } else {

                    received.add(next)
                }

                while (received.size > expected.size) {
                    received.removeAt(0)
                }

                if (
                    received.size == expected.size &&
                    received.indices.all {
                        received[it] == expected[it]
                    }
                ) {

                    val response = received.toByteArray()

                    logRx(response)

                    return response
                }
            }

            delay(5)
        }

        if (received.isNotEmpty()) {

            logTraffic(
                "RX tidak cocok: ${hex(received.toByteArray())}"
            )

        } else {

            logTraffic(
                "Timeout: tidak ada respons ECU."
            )
        }

        return null
    }

    // ---------------------------------------------------------
    // VARIABLE FRAME READER
    // ---------------------------------------------------------

    /**
     * Membaca frame respons ECU dengan format:
     *
     * 02 LEN QUERY TABLE DATA... CHECKSUM
     *
     * LEN adalah panjang TOTAL frame, termasuk:
     * - Header
     * - LEN
     * - Query
     * - Table
     * - Data
     * - Checksum
     *
     * Contoh respons unsupported:
     * 02 05 71 10 78
     *
     * Frame tersebut tetap merupakan frame valid.
     *
     * RX dari FTDI dapat masuk dalam beberapa callback.
     * Karena itu, byte parsial disimpan di rxBuffer.
     */
    private suspend fun readDataFrame(
        timeoutMs: Long = 1800
    ): ByteArray? {

        val start = System.currentTimeMillis()

        val echoCandidate = mutableListOf<Byte>()

        val txEcho = pendingTxEcho
        pendingTxEcho = byteArrayOf()

        var matchingEcho = txEcho.isNotEmpty()

        while (
            System.currentTimeMillis() - start < timeoutMs
        ) {

            // -------------------------------------------------
            // 1. Ambil seluruh byte yang sudah masuk ke RX queue.
            // -------------------------------------------------

            while (true) {

                val b = rxQueue.poll() ?: break

                if (matchingEcho) {

                    echoCandidate.add(b)

                    val prefixMatches =
                        echoCandidate.size <= txEcho.size &&
                        echoCandidate.indices.all {
                            echoCandidate[it] == txEcho[it]
                        }

                    if (prefixMatches) {

                        if (echoCandidate.size == txEcho.size) {

                            logTraffic(
                                "TX ECHO diabaikan: ${hex(txEcho)}"
                            )

                            echoCandidate.clear()
                            matchingEcho = false
                        }

                        continue

                    } else {

                        /*
                         * Byte ternyata bukan TX echo.
                         * Seluruh byte kandidat dipertahankan.
                         */
                        rxBuffer.addAll(echoCandidate)

                        echoCandidate.clear()
                        matchingEcho = false
                    }

                } else {

                    rxBuffer.add(b)
                }
            }

            // -------------------------------------------------
            // 2. Cari header 0x02.
            // -------------------------------------------------

            val headerIndex = rxBuffer.indexOfFirst {
                (it.toInt() and 0xFF) == 0x02
            }

            if (headerIndex < 0) {

                /*
                 * Tidak ada header.
                 * Simpan buffer kecil untuk mengantisipasi
                 * data yang masuk terpisah.
                 */
                if (rxBuffer.size > 64) {
                    rxBuffer.clear()
                }

                delay(5)
                continue
            }

            // Buang noise sebelum header.
            if (headerIndex > 0) {

                repeat(headerIndex) {
                    rxBuffer.removeAt(0)
                }
            }

            // -------------------------------------------------
            // 3. Baca LEN.
            // -------------------------------------------------

            if (rxBuffer.size >= 2) {

                val totalLength =
                    rxBuffer[1].toInt() and 0xFF

                /*
                 * Panjang frame Honda yang masuk akal:
                 * minimal 4 byte, maksimal 64 byte.
                 */
                if (totalLength !in 4..64) {

                    logTraffic(
                        "LEN tidak valid: $totalLength"
                    )

                    rxBuffer.removeAt(0)

                    continue
                }

                // -------------------------------------------------
                // 4. Tunggu sampai seluruh frame diterima.
                // -------------------------------------------------

                if (rxBuffer.size >= totalLength) {

                    val frame = ByteArray(totalLength) {
                        rxBuffer[it]
                    }

                    /*
                     * Hapus frame yang sudah diekstrak.
                     * Byte setelah frame tetap berada di buffer.
                     */
                    repeat(totalLength) {
                        rxBuffer.removeAt(0)
                    }

                    // -------------------------------------------------
                    // 5. Validasi frame dan checksum.
                    // -------------------------------------------------

                    if (!HondaProtocolParser.isValidFrame(frame)) {

                        logTraffic(
                            "Frame tidak valid (header/LEN/checksum): ${hex(frame)}"
                        )

                        continue
                    }

                    logRx(frame)

                    return frame
                }
            }

            delay(5)
        }

        if (rxBuffer.isNotEmpty()) {

            logTraffic(
                "Timeout menunggu frame lengkap. Buffer parsial: " +
                    hex(rxBuffer.toByteArray())
            )

        } else {

            logTraffic(
                "Timeout menunggu frame data ECU."
            )
        }

        return null
    }

    // ---------------------------------------------------------
    // FAST INIT
    // ---------------------------------------------------------

    /**
     * Wake-up:
     * LOW 70 ms
     * HIGH 120 ms
     *
     * Pastikan bentuk sinyal fisik sudah diverifikasi pada
     * interface USB-UART dan rangkaian K-Line.
     */
    private suspend fun performWakeUp(): Boolean {

        return try {

            clearRx()

            onLog?.invoke(
                "WAKE UP: TX LOW 70 ms"
            )

            serialPort.setBreak(true)

            delay(70)

            onLog?.invoke(
                "WAKE UP: TX HIGH 120 ms"
            )

            serialPort.setBreak(false)

            delay(120)

            true

        } catch (e: Exception) {

            onLog?.invoke(
                "Wake-up gagal: ${e.message}"
            )

            false
        }
    }

    /**
     * Urutan komunikasi:
     *
     * 1. Wake-up LOW 70 ms, HIGH 120 ms
     * 2. START COMMUNICATION
     * 3. KEEP ALIVE
     */
    suspend fun performFastInit(): Boolean =
        withContext(Dispatchers.IO) {

            try {

                if (!portOpened) {

                    onLog?.invoke(
                        "Port belum dibuka. Panggil setupPort() dahulu."
                    )

                    return@withContext false
                }

                sessionStarted = false
                activeLiveTable = null

                serialPort.setBaudRate(10400)

                serialPort.setDataBits(
                    UsbSerialInterface.DATA_BITS_8
                )

                serialPort.setStopBits(
                    UsbSerialInterface.STOP_BITS_1
                )

                serialPort.setParity(
                    UsbSerialInterface.PARITY_NONE
                )

                serialPort.setFlowControl(
                    UsbSerialInterface.FLOW_CONTROL_OFF
                )

                // STEP 1: WAKE UP

                if (!performWakeUp()) {
                    return@withContext false
                }

                // STEP 2: START COMMUNICATION

                clearRx()

                onLog?.invoke(
                    "Mengirim START COMMUNICATION..."
                )

                writeFrame(cmdStartCommunication)

                val startAck = waitForExactResponse(
                    byteArrayOf(
                        0x0E,
                        0x04,
                        0x72,
                        0x7C
                    ),
                    1500
                )

                if (startAck == null) {

                    onLog?.invoke(
                        "START COMMUNICATION GAGAL."
                    )

                    return@withContext false
                }

                onLog?.invoke(
                    "START COMMUNICATION berhasil."
                )

                // STEP 3: KEEP ALIVE

                clearRx()

                onLog?.invoke(
                    "Mengirim KEEP ALIVE..."
                )

                writeFrame(cmdKeepAlive)

                val keepAliveAck = waitForExactResponse(
                    byteArrayOf(
                        0x02,
                        0x04,
                        0x00,
                        0xFA.toByte()
                    ),
                    1500
                )

                if (keepAliveAck == null) {

                    onLog?.invoke(
                        "KEEP ALIVE gagal."
                    )

                    return@withContext false
                }

                sessionStarted = true

                onLog?.invoke(
                    "ECU SESSION AKTIF."
                )

                true

            } catch (e: Exception) {

                sessionStarted = false

                onLog?.invoke(
                    "Error inisialisasi: ${e.message}"
                )

                Log.e(
                    tag,
                    "performFastInit failed",
                    e
                )

                false
            }
        }

    // ---------------------------------------------------------
    // LIVE TABLE AUTO DETECT
    // ---------------------------------------------------------

    /**
     * Menguji seluruh kandidat tabel:
     *
     * 0x11
     * 0x17
     * 0x13
     * 0x10
     *
     * Tidak langsung memilih tabel pertama yang menghasilkan
     * satu nilai sensor.
     *
     * Tabel dengan jumlah field terpetakan terbanyak dipilih.
     *
     * Catatan:
     * Skor ini hanya membandingkan jumlah field yang dikenali.
     * Skor tidak membuktikan kebenaran pemetaan sensor.
     */
    suspend fun detectActiveTable(
        forceScan: Boolean = false
    ): Int? = withContext(Dispatchers.IO) {

        if (!sessionStarted) {

            onLog?.invoke(
                "Sesi ECU belum aktif; Auto Detect dibatalkan."
            )

            return@withContext null
        }

        if (!forceScan) {

            activeLiveTable?.let {
                return@withContext it
            }
        }

        activeLiveTable = null

        onLog?.invoke(
            "AUTO DETECT: memeriksa kandidat tabel live ECU..."
        )

        var bestTable: Int? = null
        var bestScore = 0

        val candidates = intArrayOf(
            0x11,
            0x17,
            0x13,
            0x10
        )

        for (table in candidates) {

            onLog?.invoke(
                "AUTO DETECT: meminta Table %02X..."
                    .format(table)
            )

            val response = requestLiveTable(table)

            val parsed = response?.let {
                HondaProtocolParser.parseLive(it)
            }

            if (parsed == null) {

                onLog?.invoke(
                    "AUTO DETECT: Table %02X tidak memiliki payload live yang dikenali."
                        .format(table)
                )

                delay(100)

                continue
            }

            val score = listOf(
                parsed.rpm,
                parsed.tpsDeg,
                parsed.tpsVolt,
                parsed.ect,
                parsed.ectVolt,
                parsed.iat,
                parsed.iatVolt,
                parsed.mapKpa,
                parsed.mapVolt,
                parsed.battery,
                parsed.injectorMs,
                parsed.ignitionDeg,
                parsed.speedKmh
            ).count {
                it != null
            }

            onLog?.invoke(
                "AUTO DETECT: Table %02X menghasilkan %d field sensor."
                    .format(table, score)
            )

            if (score > bestScore) {

                bestScore = score
                bestTable = table
            }

            delay(100)
        }

        activeLiveTable = bestTable

        if (bestTable != null) {

            onLog?.invoke(
                "AUTO DETECT: Table %02X dipilih dengan %d field sensor."
                    .format(bestTable, bestScore)
            )

        } else {

            onLog?.invoke(
                "AUTO DETECT gagal: tidak ada tabel live yang dikenali ECU ini."
            )
        }

        bestTable
    }

    // ---------------------------------------------------------
    // ECM IDENTIFICATION
    // ---------------------------------------------------------

    suspend fun probeEcmId(): ByteArray? =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {
                return@withContext null
            }

            onLog?.invoke(
                "ECM ID: mencoba Query 71 Table 00."
            )

            requestLiveTable(0x00)
        }

    // ---------------------------------------------------------
    // LIVE TABLE REQUEST
    // ---------------------------------------------------------

    /**
     * Mengirim satu permintaan Query 71.
     *
     * Respons harus memiliki:
     * - Header 0x02
     * - LEN valid
     * - Query 0x71
     * - Table sesuai permintaan
     * - Checksum valid
     */
    suspend fun requestLiveTable(
        table: Int
    ): ByteArray? = withContext(Dispatchers.IO) {

        if (!sessionStarted) {

            onLog?.invoke(
                "Sesi ECU belum aktif. Jalankan performFastInit()."
            )

            return@withContext null
        }

        clearRx()

        val request = buildQuery(
            0x71,
            table
        )

        onLog?.invoke(
            "Meminta data ECU Table %02X..."
                .format(table)
        )

        writeFrame(request)

        val frame = readDataFrame(1800)

        if (frame == null) {

            onLog?.invoke(
                "Table %02X: tidak ada frame lengkap sebelum timeout."
                    .format(table)
            )

            return@withContext null
        }

        if (
            frame.size < 4 ||
            u(frame, 2) != 0x71 ||
            u(frame, 3) != table
        ) {

            onLog?.invoke(
                "Respons tidak sesuai permintaan Table %02X: %s"
                    .format(table, hex(frame))
            )

            return@withContext null
        }

        parseHondaResponse(frame)

        frame
    }

    /**
     * Meminta data live dari tabel aktif.
     *
     * Jika belum ada tabel aktif, Auto Detect akan dijalankan.
     */
    suspend fun requestLiveData(): Boolean =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {

                onLog?.invoke(
                    "Sesi ECU belum aktif."
                )

                return@withContext false
            }

            val table = detectActiveTable(
                forceScan = activeLiveTable == null
            ) ?: return@withContext false

            val response = requestLiveTable(table)

            response?.let {
                HondaProtocolParser.parseLive(it)?.hasLiveValues()
            } == true
        }

    // ---------------------------------------------------------
    // STORED DTC
    // ---------------------------------------------------------

    /**
     * Stored DTC:
     * Query 73, Table 01 / 02 / 03.
     */
    suspend fun readDtcTables(): List<ByteArray> =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {

                onLog?.invoke(
                    "Sesi ECU belum aktif."
                )

                return@withContext emptyList()
            }

            val results = mutableListOf<ByteArray>()

            for (table in 0x01..0x03) {

                clearRx()

                val request = buildQuery(
                    0x73,
                    table
                )

                writeFrame(request)

                val response = readDataFrame(1500)

                if (response != null) {

                    results.add(response)

                    parseHondaResponse(response)
                }

                delay(40)
            }

            results
        }

    // ---------------------------------------------------------
    // CURRENT DTC
    // ---------------------------------------------------------

    /**
     * Current DTC:
     * Query 74, Table 01 / 02 / 03.
     */
    suspend fun readCurrentDtcTables(): List<ByteArray> =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {

                onLog?.invoke(
                    "Sesi ECU belum aktif."
                )

                return@withContext emptyList()
            }

            val results = mutableListOf<ByteArray>()

            for (table in 0x01..0x03) {

                clearRx()

                val request = buildQuery(
                    0x74,
                    table
                )

                writeFrame(request)

                val response = readDataFrame(1500)

                if (response != null) {

                    results.add(response)

                    parseHondaResponse(response)
                }

                delay(40)
            }

            results
        }

    // ---------------------------------------------------------
    // CLEAR DTC
    // ---------------------------------------------------------

    /**
     * Clear DTC Table 01.
     *
     * Hanya dipanggil ketika pengguna memang menghendaki
     * penghapusan kode kerusakan.
     */
    suspend fun clearDtcTable01(): ByteArray? =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {
                return@withContext null
            }

            clearRx()

            val request = buildQuery(
                0x60,
                0x01
            )

            writeFrame(request)

            waitForExactResponse(
                byteArrayOf(
                    0x02,
                    0x05,
                    0x60,
                    0x01,
                    0x98.toByte()
                ),
                1500
            )
        }

    // ---------------------------------------------------------
    // RESET TP
    // ---------------------------------------------------------

    /**
     * RESET TP / ECM initialization:
     * Query 60 Table 03.
     *
     * Pastikan mesin OFF dan throttle tertutup penuh.
     */
    suspend fun resetTp(): ByteArray? =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {
                return@withContext null
            }

            clearRx()

            val request = buildQuery(
                0x60,
                0x03
            )

            writeFrame(request)

            waitForExactResponse(
                byteArrayOf(
                    0x02,
                    0x05,
                    0x60,
                    0x03,
                    0x96.toByte()
                ),
                1500
            )
        }

    // ---------------------------------------------------------
    // KEEP ALIVE
    // ---------------------------------------------------------

    /**
     * Mengirim satu Keep Alive.
     *
     * Pemanggilan periodik tetap dikendalikan oleh pemanggil.
     */
    suspend fun sendKeepAlive(): Boolean =
        withContext(Dispatchers.IO) {

            if (!sessionStarted) {
                return@withContext false
            }

            clearRx()

            writeFrame(cmdKeepAlive)

            val response = waitForExactResponse(
                byteArrayOf(
                    0x02,
                    0x04,
                    0x00,
                    0xFA.toByte()
                ),
                1000
            )

            response != null
        }

    // ---------------------------------------------------------
    // MANUAL COMMAND
    // ---------------------------------------------------------

    fun sendCommand(command: ByteArray) {

        if (!portOpened) {

            onLog?.invoke(
                "Port belum terbuka."
            )

            return
        }

        writeFrame(command)
    }

    // ---------------------------------------------------------
    // CHECKSUM VALIDATION
    // ---------------------------------------------------------

    private fun isValidResponseChecksum(
        frame: ByteArray
    ): Boolean {

        if (frame.size < 4) {
            return false
        }

        val expected = calculateChecksum(
            frame,
            frame.size - 1
        )

        return expected == frame.last()
    }

    // ---------------------------------------------------------
    // RESPONSE PARSER DISPATCH
    // ---------------------------------------------------------

    private fun parseHondaResponse(
        data: ByteArray
    ) {

        if (!HondaProtocolParser.isValidFrame(data)) {

            logTraffic(
                "Frame respons tidak valid (header/LEN/checksum): ${hex(data)}"
            )

            return
        }

        try {

            val responseType = u(data, 2)
            val tableId = u(data, 3)

            // -------------------------------------------------
            // DTC RESPONSE
            // -------------------------------------------------

            if (
                responseType == 0x73 ||
                responseType == 0x74
            ) {

                val parsed =
                    HondaProtocolParser.parseDtc(data)

                val codes = parsed.map {
                    "${it.code} — ${it.description}"
                }

                onDtcReceived?.invoke(codes)

                onLog?.invoke(
                    "DTC response Query %02X Table %02X: %s"
                        .format(
                            responseType,
                            tableId,
                            if (codes.isEmpty()) {
                                "tidak ada kode pada frame ini"
                            } else {
                                parsed.joinToString(", ") {
                                    it.code
                                }
                            }
                        )
                )

                return
            }

            // -------------------------------------------------
            // UNKNOWN QUERY
            // -------------------------------------------------

            if (responseType != 0x71) {

                onLog?.invoke(
                    "Query respons tidak dikenal: %02X"
                        .format(responseType)
                )

                return
            }

            // -------------------------------------------------
            // LIVE DATA
            // -------------------------------------------------

            val parsed =
                HondaProtocolParser.parseLive(data)

            if (parsed == null) {

                /*
                 * Contoh:
                 * 02 05 71 10 78
                 *
                 * Frame valid, tetapi tabel tidak memiliki
                 * payload live yang dapat dipetakan.
                 */
                onSensorDetailReceived?.invoke(
                    listOf(
                        SensorItem(
                            "TABEL %02X".format(tableId),
                            "Raw response",
                            hex(data)
                        )
                    )
                )

                logTraffic(
                    "Table %02X valid tetapi tidak memiliki payload live yang dikenali."
                        .format(tableId)
                )

                return
            }

            val unavailable = Float.NaN

            onDataReceived?.invoke(
                EngineData(
                    rpm = parsed.rpm ?: -1,

                    tpsDeg = parsed.tpsDeg
                        ?: unavailable,

                    tpsVolt = parsed.tpsVolt
                        ?: unavailable,

                    ect = parsed.ect
                        ?: -999,

                    ectVolt = parsed.ectVolt
                        ?: unavailable,

                    iat = parsed.iat
                        ?: -999,

                    iatVolt = parsed.iatVolt
                        ?: unavailable,

                    mapKpa = parsed.mapKpa
                        ?: -1,

                    mapVolt = parsed.mapVolt
                        ?: unavailable,

                    battery = parsed.battery
                        ?: unavailable,

                    // AFR tidak dihitung dari narrowband O2/STFT.
                    afr = unavailable,

                    o2Volt = parsed.o2Volt
                        ?: unavailable,

                    // Tidak mengarang nilai engine load.
                    engineLoad = unavailable,

                    iacv = -1,

                    injectorMs = parsed.injectorMs
                        ?: unavailable,

                    speedKmh = parsed.speedKmh
                        ?: -1
                )
            )

            // -------------------------------------------------
            // SENSOR DETAIL
            // -------------------------------------------------

            val sensors = mutableListOf<SensorItem>()

            fun add(
                name: String,
                value: Any?,
                voltage: Float? = null
            ) {

                if (value == null) {
                    return
                }

                sensors += SensorItem(
                    category = "TABEL %02X".format(tableId),

                    name = name,

                    value = value.toString(),

                    voltage = voltage
                        ?.takeIf { it.isFinite() }
                        ?.let {
                            "%.2f V".format(it)
                        }
                        ?: "--"
                )
            }

            add(
                "RPM",
                parsed.rpm
            )

            add(
                "TPS",
                parsed.tpsDeg?.let {
                    "%.1f°".format(it)
                },
                parsed.tpsVolt
            )

            when (engineTemperatureType) {

                EngineTemperatureType.ECT -> {

                    add(
                        "ECT – Suhu Coolant",
                        parsed.ect?.let {
                            "$it °C"
                        },
                        parsed.ectVolt
                    )
                }

                EngineTemperatureType.EOT -> {

                    add(
                        "EOT – Suhu Oli",
                        parsed.ect?.let {
                            "$it °C"
                        },
                        parsed.ectVolt
                    )
                }

                EngineTemperatureType.UNKNOWN -> {
                    // Jangan memberi label ECT/EOT tanpa verifikasi.
                }
            }

            if (
                tableId == 0x10 ||
                tableId == 0x11 ||
                tableId == 0x13 ||
                tableId == 0x17
            ) {

                add(
                    "IAT",
                    parsed.iat?.let {
                        "$it °C"
                    } ?: "N/A",
                    parsed.iatVolt
                )
            }

            add(
                "MAP",
                parsed.mapKpa?.let {
                    "$it kPa"
                },
                parsed.mapVolt
            )

            add(
                "Battery",
                parsed.battery?.let {
                    "%.1f V".format(it)
                }
            )

            add(
                "Injector",
                parsed.injectorMs?.let {
                    "%.2f ms".format(it)
                }
            )

            add(
                "Ignition",
                parsed.ignitionDeg?.let {
                    "%.1f°".format(it)
                }
            )

            add(
                "Speed",
                parsed.speedKmh?.let {
                    "$it km/h"
                }
            )

            add(
                "O2",
                parsed.o2Volt?.let {
                    "%.3f V".format(it)
                }
            )

            add(
                "STFT",
                parsed.stft
            )

            add(
                "O2 Heater",
                parsed.o2HeaterVolt?.let {
                    "%.3f V".format(it)
                }
            )

            add(
                "Fast Idle",
                parsed.fastIdle
            )

            add(
                "Status",
                parsed.statusText
            )

            add(
                "Fuel Pump",
                parsed.fuelPumpOn
            )

            add(
                "Cooling Fan",
                parsed.coolingFanOn
            )

            if (sensors.isEmpty()) {

                sensors += SensorItem(
                    "TABEL %02X".format(tableId),
                    "Raw response",
                    hex(data)
                )
            }

            onSensorDetailReceived?.invoke(sensors)

        } catch (e: Exception) {

            Log.e(
                tag,
                "Error parsing response",
                e
            )

            logTraffic(
                "Error parsing: ${e.message}"
            )
        }
    }

    // ---------------------------------------------------------
    // LIVE DATA CHECK
    // ---------------------------------------------------------

    private fun HondaParsedData.hasLiveValues(): Boolean {

        return rpm != null ||
            tpsDeg != null ||
            tpsVolt != null ||
            ect != null ||
            iat != null ||
            mapKpa != null ||
            battery != null ||
            injectorMs != null ||
            speedKmh != null ||
            o2Volt != null ||
            statusText != null
    }
}
