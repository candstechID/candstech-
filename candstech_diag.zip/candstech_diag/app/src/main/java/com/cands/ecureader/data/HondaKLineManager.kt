package com.cands.ecureader.data

import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float,
    val o2Volt: Float, val engineLoad: Float, val iacv: Int,
    val injectorMs: Float, val speedKmh: Int
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {

    private val rxQueue = ConcurrentLinkedQueue<Byte>()
    private val rxBuffer = mutableListOf<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // ============================================================
    // PROTOKOL RESMI SESUAI SMK GAJAH MADA
    // ============================================================

    // Box 4: Start Communication (bukan Wakeup biasa)
    // REQ: FE 04 72 8C  |  RES: 0E 04 72 7C
    private val CMD_START_COMM = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C)

    // Box 5: Keep Alive (harus dikirim periodik agar ECU tidak timeout)
    // REQ: 72 05 00 F0 99  |  RES: 02 04 00 FA
    val CMD_KEEP_ALIVE = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())

    // Box 6: Query 71 Tabel 10 (Live Data)
    // REQ: 72 05 71 10 08  |  RES: 02 19 71 10 D9...D28 CS (25 byte)
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)

    // Box 2: Read DTC Query 73 Tabel 01 (DTC Memori)
    // REQ: 72 05 73 01 15  |  RES: 02 0C 73 01 D9...D15 CS
    val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)

    // Box 3: Read DTC Query 74 Tabel 01 (DTC Current/Saat Ini)
    // REQ: 72 05 74 01 14  |  RES: 02 0C 74 01 D9...D15 CS
    val CMD_READ_CURRENT_DTC = byteArrayOf(0x72, 0x05, 0x74, 0x01, 0x14)

    // Box 4: Clear DTC Query 60 Memori 01
    // REQ: 72 05 60 01 28  |  RES: 02 05 60 01 98
    val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)

    // Reset TP tidak ada di protokol resmi, gunakan command alternatif
    // (biasanya 72 05 60 01 28 dengan parameter berbeda, atau tidak didukung)
    val CMD_RESET_TP = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) rxQueue.add(b)
        }
    }

    fun setupPort() {
        onLog?.invoke("⚙️ Membuka Port (10400 Baud, 8N1)...")
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
        onLog?.invoke("✅ Port berhasil dibuka.")
    }

    fun closePort() {
        onLog?.invoke("🔌 Port ditutup.")
        try { serialPort.close() } catch (_: Exception) {}
    }

    // ============================================================
    // FAST INIT SESUAI PROTOKOL RESMI
    // ============================================================
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            onLog?.invoke("🔄 Memulai Fast Init (Break Signal)...")

            // Step 1: Break Signal (Box 1 & 4)
            // Tx = Low 70ms, Tx = High 120ms
            serialPort.setBreak(true)
            delay(70)
            serialPort.setBreak(false)
            delay(120)
            onLog?.invoke("⚡ Break signal dikirim (70ms Low, 120ms High).")

            // Step 2: Start Communication (Box 4)
            // REQ: FE 04 72 8C
            rxQueue.clear()
            onLog?.invoke("📡 Mengirim Start Communication: FE 04 72 8C")
            serialPort.write(CMD_START_COMM)
            delay(200)

            // Step 3: Validasi respons (harus 0E 04 72 7C)
            var initOk = false
            val responseBuffer = mutableListOf<Byte>()
            repeat(20) {
                while (rxQueue.isNotEmpty()) {
                    responseBuffer.add(rxQueue.poll())
                }
                delay(30)
            }

            onLog?.invoke("📥 Respons diterima: ${responseBuffer.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }}")

            // Cari pola 0E 04 72 7C dalam respons
            for (i in 0 until responseBuffer.size - 3) {
                if (responseBuffer[i] == 0x0E.toByte() &&
                    responseBuffer[i+1] == 0x04 &&
                    responseBuffer[i+2] == 0x72 &&
                    responseBuffer[i+3] == 0x7C) {
                    initOk = true
                    break
                }
            }

            if (initOk) {
                onLog?.invoke("✅ START COMMUNICATION SUKSES! ECU Terhubung.")
            } else {
                onLog?.invoke("❌ START COMMUNICATION GAGAL! Respons tidak valid.")
            }

            return@withContext initOk

        } catch (e: Exception) {
            onLog?.invoke("❌ Error Init: ${e.message}")
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        val hexCmd = command.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }
        onLog?.invoke("📤 Kirim: [$hexCmd]")
        serialPort.write(command)
    }

    // ============================================================
    // POLLING & PARSING DATA
    // ============================================================
    fun pollEngineData() {
        // Pindahkan semua data dari queue ke buffer
        while (rxQueue.isNotEmpty()) {
            rxBuffer.add(rxQueue.poll())
        }
        if (rxBuffer.isEmpty()) return

        // Cari header response 0x02
        var startIndex = -1
        for (i in rxBuffer.indices) {
            if (rxBuffer[i] == 0x02.toByte()) {
                startIndex = i
                break
            }
        }

        if (startIndex == -1) {
            rxBuffer.clear()
            return
        }

        // Hapus data sebelum header
        if (startIndex > 0) {
            repeat(startIndex) { rxBuffer.removeAt(0) }
        }

        // Butuh minimal 2 byte untuk baca panjang frame
        if (rxBuffer.size < 2) return

        val expectedLength = rxBuffer[1].toInt() and 0xFF

        // Validasi panjang masuk akal (5-60 byte)
        if (expectedLength !in 5..60) {
            rxBuffer.removeAt(0)
            return
        }

        // Tunggu sampai data lengkap
        if (rxBuffer.size < expectedLength) return

        // Extract frame lengkap
        val buffer = ByteArray(expectedLength)
        for (i in 0 until expectedLength) {
            buffer[i] = rxBuffer.removeAt(0)
        }

        // Validasi Checksum: CS = 100h - (SUM(DATA) AND FFh)
        var sum = 0
        for (i in 0 until expectedLength - 1) {
            sum += buffer[i].toInt() and 0xFF
        }
        val calcCs = (0x100 - (sum and 0xFF)).toByte()

        if (calcCs == buffer[expectedLength - 1]) {
            parseHondaResponse(buffer)
        } else {
            onLog?.invoke("⚠️ Checksum salah! Calc: ${String.format("%02X", calcCs.toInt() and 0xFF)}, Rx: ${String.format("%02X", buffer[expectedLength-1].toInt() and 0xFF)}")
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return

        try {
            val headerResponse = data[0].toInt() and 0xFF  // 0x02
            val lengthByte = data[1].toInt() and 0xFF       // Panjang frame
            val responseType = data[2].toInt() and 0xFF     // 0x71, 0x73, 0x74, dll
            val tableId = data[3].toInt() and 0xFF          // 0x10, 0x01, dll

            // ============================================================
            // 1. PARSING LIVE DATA (Query 71 Tabel 10)
            // RES: 02 19 71 10 D9 D10 D11 D12 D13 D14 D15 D16 D17 D18 D19 D20 D21 D22 D23 D24 D25 D26 D27 D28 CS
            // Total: 25 byte (0x19 = 25)
            // ============================================================
            if (responseType == 0x71 && tableId == 0x10 && data.size >= 25) {
                // D9, D10 = RPM (D9*256)+D10
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF
                val calculatedRpm = (rpmH shl 8) or rpmL

                // D11 = TPS Volt (D11 * 5 / 256)
                val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                // D12 = TPS Degrees (D12 * 0.5)
                val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f

                // D13 = ECT Volt (D13 * 5 / 256)
                val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                // D14 = ECT Temp (D14 - 40)
                val ect = (data[9].toInt() and 0xFF) - 40

                // D15 = IAT Volt (D15 * 5 / 256)
                val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                // D16 = IAT Temp (D16 - 40)
                val iat = (data[11].toInt() and 0xFF) - 40

                // D17 = MAP Volt (D17 * 5 / 256)
                val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                // D18 = MAP kPa (D18)
                val mapKpa = data[13].toInt() and 0xFF

                // D21 = Battery (D21 * 0.1)
                val battery = (data[16].toInt() and 0xFF) * 0.1f

                // D26 = Speed (D26)
                val speed = data[21].toInt() and 0xFF

                val engineData = EngineData(
                    rpm = calculatedRpm,
                    tpsDeg = tpsDeg,
                    tpsVolt = tpsVolt,
                    ect = ect,
                    ectVolt = ectVolt,
                    iat = iat,
                    iatVolt = iatVolt,
                    mapKpa = mapKpa,
                    mapVolt = mapVolt,
                    battery = battery,
                    speedKmh = speed,
                    afr = 14.7f,
                    o2Volt = 0.45f,
                    engineLoad = (tpsVolt / 5f) * 100f,
                    iacv = 30,
                    injectorMs = 2.5f
                )
                onDataReceived?.invoke(engineData)
            }

            // ============================================================
            // 2. PARSING DTC (Query 73 atau 74)
            // RES: 02 0C 73 01 D9 D10 D11 D12 D13 D14 D15 CS
            // Format DTC: 3 byte desimal (contoh: 007-2)
            // ============================================================
            else if (responseType == 0x73 || responseType == 0x74) {
                val dtcList = mutableListOf<String>()

                // Loop dari byte ke-4 (D9) sampai sebelum checksum, loncat 2 byte
                for (i in 4 until (data.size - 1) step 2) {
                    if (i + 1 < data.size - 1) {
                        val code1 = data[i].toInt() and 0xFF
                        val code2 = data[i+1].toInt() and 0xFF

                        // Hanya tambahkan jika bukan 00-00 (tidak ada DTC)
                        if (code1 != 0 || code2 != 0) {
                            // Format desimal sesuai protokol: 007-2
                            dtcList.add(String.format("%03d-%01d", code1, code2))
                        }
                    }
                }

                onLog?.invoke("🔍 DTC ditemukan: ${dtcList.size} kode")
                onDtcReceived?.invoke(dtcList)
            }

        } catch (e: Exception) {
            onLog?.invoke("❌ Error Parsing: ${e.message}")
        }
    }
}