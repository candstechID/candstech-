
package com.cands.ecureader.ui

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.viewmodel.EcuViewModel
import com.felhr.usbserial.UsbSerialDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity(), LocationListener {

    private val viewModel: EcuViewModel by viewModels()

    private lateinit var locationManager: LocationManager
    private lateinit var usbManager: UsbManager

    private val usbPermissionAction =
        "com.cands.ecureader.USB_PERMISSION"

    private var receiverRegistered = false

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != usbPermissionAction) return

            val device: UsbDevice? =
                if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(
                        UsbManager.EXTRA_DEVICE,
                        UsbDevice::class.java
                    )
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                }

            val granted = intent.getBooleanExtra(
                UsbManager.EXTRA_PERMISSION_GRANTED,
                false
            )

            if (granted && device != null) {
                openFtdiDevice(device)
            } else {
                viewModel.addLog("Izin USB FTDI ditolak.")

                Toast.makeText(
                    this@MainActivity,
                    "Izin USB tidak diberikan.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        locationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager

        usbManager =
            getSystemService(Context.USB_SERVICE) as UsbManager

        registerUsbReceiver()
        requestGpsPermission()

        setContent {
            EcuReaderScreen(
                viewModel = viewModel,
                context = this,
                onConnect = { connectFtdi() },
                onDisconnect = { disconnectFtdi() }
            )
        }
    }

    // =========================================================
    // USB PERMISSION
    // =========================================================

    private fun registerUsbReceiver() {
        val filter = IntentFilter(usbPermissionAction)

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(
                usbPermissionReceiver,
                filter,
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbPermissionReceiver, filter)
        }

        receiverRegistered = true
    }

    // =========================================================
    // CONNECT FTDI
    // =========================================================

    private fun connectFtdi() {
        try {
            val device = usbManager.deviceList.values.firstOrNull {
                it.vendorId == 0x0403 &&
                    (it.productId == 0x6001 ||
                     it.productId == 0x6015)
            }

            if (device == null) {
                viewModel.addLog(
                    "FTDI tidak ditemukan. VID/PID tidak cocok."
                )

                Toast.makeText(
                    this,
                    "FTDI FT232 tidak ditemukan.",
                    Toast.LENGTH_LONG
                ).show()

                return
            }

            if (!usbManager.hasPermission(device)) {
                viewModel.addLog("Meminta izin USB FTDI.")

                val permissionIntent = PendingIntent.getBroadcast(
                    this,
                    1001,
                    Intent(usbPermissionAction).setPackage(packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
                )

                usbManager.requestPermission(
                    device,
                    permissionIntent
                )

                return
            }

            openFtdiDevice(device)

        } catch (e: Exception) {
            viewModel.addLog("USB error: ${e.message}")

            Toast.makeText(
                this,
                "Kesalahan USB: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openFtdiDevice(device: UsbDevice) {
        if (viewModel.isConnected) {
            viewModel.addLog("ECU sudah terhubung.")
            return
        }

        lifecycleScope.launch {
            var manager: HondaKLineManager? = null
            var listenerAttached = false

            try {
                viewModel.addLog(
                    "Membuka FTDI VID=${device.vendorId}, PID=${device.productId}"
                )

                val handshakeSuccess = withContext(Dispatchers.IO) {
                    val connection = usbManager.openDevice(device)
                        ?: throw IllegalStateException(
                            "USB openDevice gagal."
                        )

                    val serialDevice =
                        UsbSerialDevice.createUsbSerialDevice(
                            device,
                            connection
                        )

                    if (serialDevice == null) {
                        connection.close()

                        throw IllegalStateException(
                            "Driver USB Serial tidak tersedia."
                        )
                    }

                    val newManager =
                        HondaKLineManager(serialDevice)

                    manager = newManager

                    newManager.setupPort()

                    withContext(Dispatchers.Main) {
                        viewModel.initKLineListener(newManager)
                    }

                    listenerAttached = true

                    newManager.performFastInit()
                }

                if (handshakeSuccess) {
                    viewModel.setConnectionState(true)
                    viewModel.startPolling()

                    Toast.makeText(
                        this@MainActivity,
                        "Komunikasi ECU berhasil.",
                        Toast.LENGTH_SHORT
                    ).show()

                    viewModel.addLog(
                        "Handshake berhasil. Polling dimulai."
                    )

                } else {
                    if (listenerAttached) {
                        viewModel.disconnect()
                    } else {
                        manager?.closePort()
                    }

                    Toast.makeText(
                        this@MainActivity,
                        "Handshake ECU gagal. Periksa kontak dan jalur K-Line.",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                if (listenerAttached) {
                    viewModel.disconnect()
                } else {
                    manager?.closePort()
                }

                viewModel.addLog(
                    "Gagal membuka komunikasi ECU: ${e.message}"
                )

                Toast.makeText(
                    this@MainActivity,
                    "Koneksi gagal: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun disconnectFtdi() {
        viewModel.disconnect()

        Toast.makeText(
            this,
            "Koneksi ECU diputus.",
            Toast.LENGTH_SHORT
        ).show()
    }

    // =========================================================
    // GPS SPEEDOMETER
    // =========================================================

    private fun requestGpsPermission() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            startGps()
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                2001
            )
        }
    }

    private fun startGps() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) return

        try {
            if (
                locationManager.isProviderEnabled(
                    LocationManager.GPS_PROVIDER
                )
            ) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    500L,
                    0f,
                    this
                )
            } else if (
                locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER
                )
            ) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    1000L,
                    0f,
                    this
                )
            } else {
                viewModel.addLog(
                    "GPS dan Network Location tidak aktif."
                )
            }

        } catch (e: SecurityException) {
            viewModel.addLog("Izin GPS belum tersedia.")
        } catch (e: Exception) {
            viewModel.addLog("GPS error: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 2001) {
            if (grantResults.any {
                    it == PackageManager.PERMISSION_GRANTED
                }) {
                startGps()
            } else {
                viewModel.addLog(
                    "Izin lokasi ditolak. GPS Speedometer tidak aktif."
                )
            }
        }
    }

    override fun onLocationChanged(location: Location) {
        if (!location.hasSpeed()) return

        if (location.hasAccuracy() && location.accuracy > 50f) {
            return
        }

        viewModel.updateGpsSpeed(location.speed)
    }

    override fun onResume() {
        super.onResume()

        if (::locationManager.isInitialized) {
            startGps()
        }
    }

    override fun onPause() {
        if (::locationManager.isInitialized) {
            try {
                locationManager.removeUpdates(this)
            } catch (_: Exception) {
            }
        }

        super.onPause()
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(usbPermissionReceiver)
            } catch (_: Exception) {
            }

            receiverRegistered = false
        }

        super.onDestroy()
    }
}

// =============================================================
// MAIN ECU READER SCREEN
// =============================================================

@Composable
fun EcuReaderScreen(
    viewModel: EcuViewModel,
    context: Context,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    val darkBg = Color(0xFF0F0F0F)
    val cardBg = Color(0xFF1E1E1E)
    val hondaRed = Color(0xFFE10600)
    val diagBlue = Color(0xFF1976D2)

    val scope = rememberCoroutineScope()
    var showBikeDialog by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(darkBg)
            .padding(8.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        // HEADER DAN STATUS

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(36.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        "ECU Reader Pro",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "Full Diagnostic & Live Data",
                        color = hondaRed,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusBadge(
                    label = if (viewModel.isConnected) {
                        "CONNECTED"
                    } else {
                        "DISCONNECTED"
                    },
                    isOk = viewModel.isConnected
                )

                StatusBadge(
                    label = if (viewModel.isKontakOn) {
                        "KONTAK ON"
                    } else {
                        "KONTAK OFF"
                    },
                    isOk = viewModel.isKontakOn
                )
            }
        }

        // SPEED ECU DAN GPS

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SpeedCard(
                Modifier.weight(1f),
                "SPEED ECU",
                viewModel.speedEcu,
                viewModel.topSpeedEcu,
                { viewModel.resetTopEcu() },
                cardBg,
                hondaRed
            )

            SpeedCard(
                Modifier.weight(1f),
                "SPEED GPS",
                viewModel.speedGps,
                viewModel.topSpeedGps,
                { viewModel.resetTopGps() },
                cardBg,
                hondaRed
            )
        }

        // RPM

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val rpmText =
                        if (viewModel.isConnected && viewModel.isKontakOn) {
                            "${viewModel.rpm}"
                        } else {
                            "--"
                        }

                    Text(
                        rpmText,
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "RPM",
                        color = hondaRed,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val progress =
                    if (viewModel.isConnected && viewModel.isKontakOn) {
                        (viewModel.rpm / 12000f).coerceIn(0f, 1f)
                    } else {
                        0f
                    }

                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp),
                    color = hondaRed,
                    trackColor = Color.DarkGray
                )
            }
        }

        // DIAGNOSTIK DAN RESET

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            )
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    "FITUR DIAGNOSTIK & RESET",
                    color = diagBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { viewModel.scanDtc() },
                        enabled = viewModel.isConnected &&
                            !viewModel.isScanningDtc,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2A2A)
                        ),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text(
                            "SCAN DTC",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }

                    Button(
                        onClick = { viewModel.clearDtc() },
                        enabled = viewModel.isConnected &&
                            !viewModel.isScanningDtc,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2A2A)
                        ),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text(
                            "CLEAR DTC",
                            fontSize = 10.sp,
                            color = hondaRed
                        )
                    }

                    Button(
                        onClick = { viewModel.resetTp() },
                        enabled = viewModel.isConnected &&
                            !viewModel.isScanningDtc,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2A2A)
                        ),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text(
                            "RESET TP",
                            fontSize = 10.sp,
                            color = Color.Yellow
                        )
                    }
                }

                if (viewModel.dtcMessage.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        viewModel.dtcMessage,
                        color = Color(0xFF4CAF50),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (viewModel.dtcList.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))

                    viewModel.dtcList.forEach { dtc ->
                        Text(
                            "• KODE KERUSAKAN: $dtc",
                            color = hondaRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // SENSOR DETAIL BUTTON

        Button(
            onClick = {
                viewModel.requestFullSensorData()
            },
            enabled = viewModel.isConnected &&
                !viewModel.isScanningDtc &&
                !viewModel.isScanningSensor,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2196F3)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "📊 LIHAT DATA SENSOR LENGKAP",
                fontSize = 12.sp,
                color = Color.White
            )
        }

        // SENSOR UTAMA

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InfoCard(
                Modifier.weight(1f),
                "Bukaan Gas",
                if (viewModel.isConnected && viewModel.isKontakOn) {
                    "${String.format("%.1f", viewModel.tpsDegrees)}°"
                } else "--",
                if (viewModel.isConnected && viewModel.isKontakOn) {
                    "${String.format("%.2f", viewModel.tpsVolt)}V"
                } else "--",
                Color.White,
                cardBg
            )

            InfoCard(
                Modifier.weight(1f),
                "AFR",
                if (viewModel.isConnected && viewModel.isKontakOn) {
                    "${String.format("%.1f", viewModel.afr)}:1"
                } else "--",
                if (!viewModel.isConnected || !viewModel.isKontakOn) {
                    "Standby"
                } else {
                    "Ideal"
                },
                Color.White,
                cardBg
            )

            InfoCard(
                Modifier.weight(1f),
                "Suhu Mesin",
                if (viewModel.isConnected && viewModel.isKontakOn) {
                    "${viewModel.ect}°C"
                } else "--",
                if (viewModel.isConnected) "Normal" else "Standby",
                Color.White,
                cardBg
            )
        }

        // SENSOR GRID

        val gridItems = listOf(
            "Baterai" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${String.format("%.1f", viewModel.batteryVolt)} V"
            } else "--",

            "Beban Mesin" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${String.format("%.1f", viewModel.engineLoad)} %"
            } else "--",

            "Tekanan MAP" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${viewModel.mapKpa} kPa"
            } else "--",

            "Suhu Udara IAT" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${viewModel.iat} °C"
            } else "--",

            "IACV" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${viewModel.iacv} %"
            } else "--",

            "Injektor" to if (
                viewModel.isConnected && viewModel.isKontakOn
            ) {
                "${String.format("%.2f", viewModel.injectorMs)} ms"
            } else "--"
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (i in gridItems.indices step 2) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    GridItemCard(
                        Modifier.weight(1f),
                        gridItems[i].first,
                        gridItems[i].second,
                        cardBg
                    )

                    if (i + 1 < gridItems.size) {
                        GridItemCard(
                            Modifier.weight(1f),
                            gridItems[i + 1].first,
                            gridItems[i + 1].second,
                            cardBg
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // CONNECT / DISCONNECT

        Button(
            onClick = {
                if (viewModel.isConnected) {
                    onDisconnect()
                } else {
                    onConnect()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (viewModel.isConnected) {
                    Color.DarkGray
                } else {
                    hondaRed
                }
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (viewModel.isConnected) {
                    "DISCONNECT K-LINE"
                } else {
                    "CONNECT K-LINE (EXACT PROTOCOL)"
                },
                color = Color.White
            )
        }

        // DEBUG CONSOLE

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF121212)
            )
        ) {
            Column(
                modifier = Modifier.padding(8.dp)
            ) {
                Text(
                    "🛠️ DEBUG CONSOLE",
                    color = Color(0xFF00E676),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (viewModel.uiLogs.isEmpty()) {
                        "Menunggu koneksi..."
                    } else {
                        viewModel.uiLogs
                    },
                    color = Color(0xFFB0BEC5),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .height(150.dp)
                        .verticalScroll(rememberScrollState())
                )
            }
        }

        // BIKE PROFILE

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    showBikeDialog = true
                },
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            )
        ) {
            Row(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "STATUS MOTOR / ECU TERHUBUNG",
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        if (viewModel.isConnected) {
                            viewModel.selectedBike.name
                        } else {
                            "Belum Terhubung"
                        },
                        color = if (viewModel.isConnected) {
                            Color.White
                        } else {
                            Color.LightGray
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        if (viewModel.isConnected) {
                            "ECU: ${viewModel.selectedBike.ecuType}"
                        } else {
                            "Mode: ${viewModel.selectedBike.name}"
                        },
                        color = if (viewModel.isConnected) {
                            hondaRed
                        } else {
                            Color.Gray
                        },
                        fontSize = 11.sp
                    )
                }

                Surface(
                    color = if (viewModel.isConnected) {
                        hondaRed
                    } else {
                        Color.DarkGray
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "PILIH / UBAH",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            horizontal = 8.dp,
                            vertical = 6.dp
                        )
                    )
                }
            }
        }
    }

    // DIALOG PILIH MOTOR

    if (showBikeDialog) {
        AlertDialog(
            onDismissRequest = {
                showBikeDialog = false
            },
            title = {
                Text(
                    "Pilih Profil Motor",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            containerColor = Color(0xFF1E1E1E),
            text = {
                Column(
                    modifier = Modifier
                        .height(350.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (bike in HondaBikeProfiles.list) {
                        Surface(
                            color = if (
                                viewModel.selectedBike.id == bike.id
                            ) {
                                hondaRed
                            } else {
                                Color(0xFF2A2A2A)
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectBike(bike)
                                    showBikeDialog = false
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Text(
                                    bike.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showBikeDialog = false
                    }
                ) {
                    Text("TUTUP", color = hondaRed)
                }
            }
        )
    }

    // DIALOG DATA SENSOR

    if (viewModel.showSensorDialog) {
        AlertDialog(
            onDismissRequest = {
                viewModel.showSensorDialog = false
            },
            containerColor = Color(0xFF1E1E1E),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "📊 DATA SENSOR",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    TextButton(
                        onClick = {
                            viewModel.showSensorDialog = false
                        }
                    ) {
                        Text("TUTUP", color = hondaRed)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .height(400.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (viewModel.sensorDetailList.isEmpty()) {
                        Text(
                            "Sedang membaca data dari ECU...",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .background(
                                    Color(0xFF2A2A2A),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(8.dp)
                        ) {
                            Text(
                                "NAMA SENSOR",
                                color = Color(0xFF2196F3),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(2f)
                            )

                            Text(
                                "NILAI",
                                color = Color(0xFF2196F3),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                "VOLTASE",
                                color = Color(0xFF2196F3),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        var lastCategory = ""

                        viewModel.sensorDetailList.forEach { item ->
                            if (item.category != lastCategory) {
                                Spacer(
                                    modifier = Modifier.height(8.dp)
                                )

                                Text(
                                    "═══ ${item.category} ═══",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                lastCategory = item.category
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    item.name,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(2f)
                                )

                                Text(
                                    item.value,
                                    color = Color(0xFFFFEB3B),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )

                                Text(
                                    item.voltage,
                                    color = Color(0xFF00E676),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(0.5.dp)
                                    .background(Color(0xFF333333))
                            )
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

// =============================================================
// REUSABLE UI COMPONENTS
// =============================================================

@Composable
fun StatusBadge(
    label: String,
    isOk: Boolean
) {
    Surface(
        color = if (isOk) {
            Color(0xFF1B5E20)
        } else {
            Color(0xFFB71C1C)
        },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(
                        if (isOk) {
                            Color(0xFF4CAF50)
                        } else {
                            Color(0xFFFF5252)
                        },
                        CircleShape
                    )
            )

            Spacer(modifier = Modifier.width(4.dp))

            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SpeedCard(
    modifier: Modifier,
    title: String,
    speed: Int,
    topSpeed: Int,
    onResetTop: () -> Unit,
    cardBg: Color,
    hondaRed: Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = cardBg
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                title,
                color = Color.Gray,
                fontSize = 12.sp
            )

            Text(
                "$speed",
                color = Color.White,
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onResetTop,
                colors = ButtonDefaults.buttonColors(
                    containerColor = hondaRed
                ),
                modifier = Modifier.height(24.dp),
                contentPadding = PaddingValues(4.dp)
            ) {
                Text(
                    "RESET TOP",
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun InfoCard(
    modifier: Modifier,
    title: String,
    mainVal: String,
    subVal: String,
    color: Color,
    cardBg: Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = cardBg
        )
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                title,
                color = Color.Gray,
                fontSize = 12.sp
            )

            Text(
                mainVal,
                color = color,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                subVal,
                color = color,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun GridItemCard(
    modifier: Modifier,
    title: String,
    value: String,
    cardBg: Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = cardBg
        )
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                title,
                color = Color.Gray,
                fontSize = 12.sp
            )

            Text(
                value,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
