package com.cands.ecureader.ui

import android.hardware.usb.UsbManager
import android.os.Bundle
import android.content.Context
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.viewmodel.EcuViewModel
import com.felhr.usbserial.UsbSerialDevice
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: EcuViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EcuReaderScreen(viewModel, this)
        }
    }
}

@Composable
fun EcuReaderScreen(viewModel: EcuViewModel, context: Context) {
    val darkBg = Color(0xFF0F0F0F)
    val cardBg = Color(0xFF1E1E1E)
    val hondaRed = Color(0xFFE10600)
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(darkBg)
            .padding(8.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // HEADER & STATUS BADGES
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("ECU Reader Pro", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("FTDI K-Line Edition", color = hondaRed, fontSize = 11.sp)
                }
            }

            // STATUS BADGES (Connected & Kontak On/Off)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusBadge(
                    label = if (viewModel.isConnected) "CONNECTED" else "DISCONNECTED",
                    isOk = viewModel.isConnected
                )
                StatusBadge(
                    label = if (viewModel.isKontakOn) "KONTAK ON" else "KONTAK OFF",
                    isOk = viewModel.isKontakOn
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SpeedCard(
                modifier = Modifier.weight(1f),
                title = "SPEED ECU", speed = viewModel.speedEcu, topSpeed = viewModel.topSpeedEcu,
                onResetTop = { viewModel.resetTopEcu() }, cardBg = cardBg, hondaRed = hondaRed
            )
            SpeedCard(
                modifier = Modifier.weight(1f),
                title = "SPEED GPS", speed = viewModel.speedGps, topSpeed = viewModel.topSpeedGps,
                onResetTop = { viewModel.resetTopGps() }, cardBg = cardBg, hondaRed = hondaRed
            )
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cardBg)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${viewModel.rpm} x1000", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("RPM", color = hondaRed, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                val progress = (viewModel.rpm / 12000f).coerceIn(0f, 1f)
                val barColor = if(viewModel.rpm < 4000) Color.Green else if(viewModel.rpm < 8000) Color.Yellow else Color.Red
                LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(12.dp), color = barColor, trackColor = Color.DarkGray)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InfoCard(Modifier.weight(1f), "Bukaan Gas", "${String.format("%.1f", viewModel.tpsDegrees)}°", "${String.format("%.2f", viewModel.tpsVolt)}V", Color.White, cardBg)
            val afrColor = if (viewModel.afr in 14.0..15.0) Color.Green else Color.Red
            val afrStatus = if (viewModel.afr < 14.0) "Rich" else if (viewModel.afr > 15.0) "Lean" else "Ideal"
            InfoCard(Modifier.weight(1f), "AFR", "${String.format("%.1f", viewModel.afr)}:1", afrStatus, afrColor, cardBg)
            val ectColor = if (viewModel.ect < 105) Color.Green else Color.Red
            val ectStatus = if (viewModel.ect < 105) "Normal" else "Overheat"
            InfoCard(Modifier.weight(1f), "Suhu Mesin", "${viewModel.ect}°C", ectStatus, ectColor, cardBg)
        }

        val gridItems = listOf(
            "Baterai" to "${viewModel.batteryVolt} V", "Beban Mesin" to "${viewModel.engineLoad} %",
            "Tekanan MAP" to "${viewModel.mapKpa} kPa", "Suhu Udara IAT" to "${viewModel.iat} °C",
            "IACV" to "${viewModel.iacv} %", "Injektor" to "${viewModel.injectorMs} ms"
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in gridItems.indices step 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GridItemCard(Modifier.weight(1f), gridItems[i].first, gridItems[i].second, cardBg)
                    if (i + 1 < gridItems.size) {
                        GridItemCard(Modifier.weight(1f), gridItems[i+1].first, gridItems[i+1].second, cardBg)
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CommandButton("SCAN DTC", hondaRed) { viewModel.scanDtc() }
            CommandButton("HAPUS DTC", Color(0xFFEF4444)) { viewModel.clearDtc() }
            CommandButton("RESET TP", Color(0xFFEAB308)) { viewModel.resetTp() }
            CommandButton("LOGGER CSV", Color(0xFF22C55E)) { viewModel.exportCsvLogger() }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { 
                scope.launch {
                    try {
                        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                        val deviceList = usbManager.deviceList
                        val device = deviceList.values.firstOrNull()
                        if (device != null) {
                            val connection = usbManager.openDevice(device)
                            val serialDevice = UsbSerialDevice.createUsbSerialDevice(device, connection)
                            if (serialDevice != null) {
                                val manager = HondaKLineManager(serialDevice)
                                manager.setupPort()
                                viewModel.initKLineListener(manager)
                                val success = manager.performFastInit()
                                if (success) {
                                    viewModel.startPolling()
                                    Toast.makeText(context, "K-Line Terhubung & Live!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Fast Init Gagal", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "Device USB tidak disupport", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Tidak ada perangkat USB tercolok", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = hondaRed),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("CONNECT K-LINE (10400 8N1)")
        }
    }
}

@Composable
fun StatusBadge(label: String, isOk: Boolean) {
    val bgColor = if (isOk) Color(0xFF1B5E20) else Color(0xFFB71C1C)
    val dotColor = if (isOk) Color(0xFF4CAF50) else Color(0xFFFF5252)

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(dotColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SpeedCard(modifier: Modifier, title: String, speed: Int, topSpeed: Int, onResetTop: () -> Unit, cardBg: Color, hondaRed: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text("$speed", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Text("km/h", color = Color.LightGray, fontSize = 14.sp)
            Divider(color = hondaRed, thickness = 2.dp, modifier = Modifier.padding(vertical = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("TOP: $topSpeed", color = Color.Yellow, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Button(onClick = onResetTop, modifier = Modifier.height(24.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), colors = ButtonDefaults.buttonColors(containerColor = hondaRed)) {
                    Text("RST", fontSize = 10.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun InfoCard(modifier: Modifier, title: String, mainVal: String, subVal: String, color: Color, cardBg: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(mainVal, color = color, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(subVal, color = color, fontSize = 12.sp)
        }
    }
}

@Composable
fun GridItemCard(modifier: Modifier, title: String, value: String, cardBg: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CommandButton(text: String, color: Color, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = color), shape = RoundedCornerShape(8.dp)) {
        Text(text, color = if (color == Color(0xFFEAB308)) Color.Black else Color.White, fontWeight = FontWeight.Bold)
    }
}
