
package com.cands.ecureader.ui

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.viewmodel.EcuViewModel
import com.felhr.usbserial.UsbSerialDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity(), LocationListener {

    private val viewModel: EcuViewModel by viewModels()

    private lateinit var locationManager: LocationManager
    private lateinit var usbManager: UsbManager

    private val usbPermissionAction =
        "com.cands.ecureader.USB_PERMISSION"

    private var receiverRegistered = false

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != usbPermissionAction) return

            val device: UsbDevice? =
                if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(
                        UsbManager.EXTRA_DEVICE,
                        UsbDevice::class.java
                    )
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                }

            val granted = intent.getBooleanExtra(
                UsbManager.EXTRA_PERMISSION_GRANTED,
                false
            )

            if (granted && device != null) {
                openFtdiDevice(device)
            } else {
                viewModel.addLog("Izin USB FTDI ditolak.")

                Toast.makeText(
                    this@MainActivity,
                    "Izin USB tidak diberikan.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        locationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager

        usbManager =
            getSystemService(Context.USB_SERVICE) as UsbManager

        registerUsbReceiver()
        requestGpsPermission()

        setContent {
            EcuReaderScreen(
                viewModel = viewModel,
                context = this,
                onConnect = { connectFtdi() },
                onDisconnect = { disconnectFtdi() }
            )
        }
    }

    // =========================================================
    // USB PERMISSION
    // =========================================================

    private fun registerUsbReceiver() {
        val filter = IntentFilter(usbPermissionAction)

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(
                usbPermissionReceiver,
                filter,
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbPermissionReceiver, filter)
        }

        receiverRegistered = true
    }

    // =========================================================
    // CONNECT FTDI
    // =========================================================

    private fun connectFtdi() {
        try {
            val device = usbManager.deviceList.values.firstOrNull {
                it.vendorId == 0x0403 &&
                    (it.productId == 0x6001 ||
                     it.productId == 0x6015)
            }

            if (device == null) {
                viewModel.addLog(
                    "FTDI tidak ditemukan. VID/PID tidak cocok."
                )

                Toast.makeText(
                    this,
                    "FTDI FT232 tidak ditemukan.",
                    Toast.LENGTH_LONG
                ).show()

                return
            }

            if (!usbManager.hasPermission(device)) {
                viewModel.addLog("Meminta izin USB FTDI.")

                val permissionIntent = PendingIntent.getBroadcast(
                    this,
                    1001,
                    Intent(usbPermissionAction).setPackage(packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
                )

                usbManager.requestPermission(
                    device,
                    permissionIntent
                )

                return
            }

            openFtdiDevice(device)

        } catch (e: Exception) {
            viewModel.addLog("USB error: ${e.message}")

            Toast.makeText(
                this,
                "Kesalahan USB: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openFtdiDevice(device: UsbDevice) {
        if (viewModel.isConnected) {
            viewModel.addLog("ECU sudah terhubung.")
            return
        }

        lifecycleScope.launch {
            var manager: HondaKLineManager? = null
            var listenerAttached = false

            try {
                viewModel.addLog(
                    "Membuka FTDI VID=${device.vendorId}, PID=${device.productId}"
                )

                val handshakeSuccess = withContext(Dispatchers.IO) {
                    val connection = usbManager.openDevice(device)
                        ?: throw IllegalStateException(
                            "USB openDevice gagal."
                        )

                    val serialDevice =
                        UsbSerialDevice.createUsbSerialDevice(
                            device,
                            connection
                        )

                    if (serialDevice == null) {
                        connection.close()

                        throw IllegalStateException(
                            "Driver USB Serial tidak tersedia."
                        )
                    }

                    val newManager =
                        HondaKLineManager(serialDevice)

                    manager = newManager

                    newManager.setupPort()

                    withContext(Dispatchers.Main) {
                        viewModel.initKLineListener(newManager)
                    }

                    listenerAttached = true

                    newManager.performFastInit()
                }

                if (handshakeSuccess) {
                    viewModel.setConnectionState(true)
                    viewModel.startPolling()

                    Toast.makeText(
                        this@MainActivity,
                        "Komunikasi ECU berhasil.",
                        Toast.LENGTH_SHORT
                    ).show()

                    viewModel.addLog(
                        "Handshake berhasil. Polling dimulai."
                    )

                } else {
                    if (listenerAttached) {
                        viewModel.disconnect()
                    } else {
                        manager?.closePort()
                    }

                    Toast.makeText(
                        this@MainActivity,
                        "Handshake ECU gagal. Periksa kontak dan jalur K-Line.",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                if (listenerAttached) {
                    viewModel.disconnect()
                } else {
                    manager?.closePort()
                }

                viewModel.addLog(
                    "Gagal membuka komunikasi ECU: ${e.message}"
                )

                Toast.makeText(
                    this@MainActivity,
                    "Koneksi gagal: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun disconnectFtdi() {
        viewModel.disconnect()

        Toast.makeText(
            this,
            "Koneksi ECU diputus.",
            Toast.LENGTH_SHORT
        ).show()
    }

    // =========================================================
    // GPS SPEEDOMETER
    // =========================================================

    private fun requestGpsPermission() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            startGps()
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                2001
            )
        }
    }

    private fun startGps() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) return

        try {
            if (
                locationManager.isProviderEnabled(
                    LocationManager.GPS_PROVIDER
                )
            ) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    500L,
                    0f,
                    this
                )
            } else if (
                locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER
                )
            ) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    1000L,
                    0f,
                    this
                )
            } else {
                viewModel.addLog(
                    "GPS dan Network Location tidak aktif."
                )
            }

        } catch (e: SecurityException) {
            viewModel.addLog("Izin GPS belum tersedia.")
        } catch (e: Exception) {
            viewModel.addLog("GPS error: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 2001) {
            if (grantResults.any {
                    it == PackageManager.PERMISSION_GRANTED
                }) {
                startGps()
            } else {
                viewModel.addLog(
                    "Izin lokasi ditolak. GPS Speedometer tidak aktif."
                )
            }
        }
    }

    override fun onLocationChanged(location: Location) {
        if (!location.hasSpeed()) return

        if (location.hasAccuracy() && location.accuracy > 50f) {
            return
        }

        viewModel.updateGpsSpeed(location.speed)
    }

    override fun onResume() {
        super.onResume()

        if (::locationManager.isInitialized) {
            startGps()
        }
    }

    override fun onPause() {
        if (::locationManager.isInitialized) {
            try {
                locationManager.removeUpdates(this)
            } catch (_: Exception) {
            }
        }

        super.onPause()
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(usbPermissionReceiver)
            } catch (_: Exception) {
            }

            receiverRegistered = false
        }

        super.onDestroy()
    }
}

// =============================================================
// MAIN ECU READER SCREEN
// =============================================================

@Composable
fun EcuReaderScreen(
    viewModel: EcuViewModel,
    context: Context,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    val darkBg = Color(0xFF0F0F0F)
    val cardBg = Color(0xFF1E1E1E)
    val hondaRed = Color(0xFFE10600)
    val diagBlue = Color(0xFF1976D2)

    val scope = rememberCoroutineScope()
    var showBikeDialog by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(darkBg)
            .padding(8.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        // HEADER DAN STATUS

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(36.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        "ECU Reader Pro",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "Full Diagnostic & Live Data",
                        color = hondaRed,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusBadge(
                    label = if (viewModel.isConnected) {
                        "CONNECTED"
                    } else {
                        "DISCONNECTED"
                    },
                    isOk = viewModel.isConnected
                )

                StatusBadge(
                    label = if (viewModel.isKontakOn) {
                        "KONTAK ON"
                    } else {
                        "KONTAK OFF"
                    },
                    isOk = viewModel.isKontakOn
                )
            }
        }

        // SPEED ECU DAN GPS

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SpeedCard(
                Modifier.weight(1f),
                "SPEED ECU",
                viewModel.speedEcu,
                viewModel.topSpeedEcu,
                { viewModel.resetTopEcu() },
                cardBg,
                hondaRed
            )

            SpeedCard(
                Modifier.weight(1f),
                "SPEED GPS",
                viewModel.speedGps,
                viewModel.topSpeedGps,
                { viewModel.resetTopGps() },
                cardBg,
                hondaRed
            )
        }

        // RPM

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val rpmText =
                        if (viewModel.isConnected && viewModel.isKontakOn) {
                            "${viewModel.rpm}"
                        } else {
                            "--"
                        }

                    Text(
                        rpmText,
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "RPM",
                        color = hondaRed,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val progress =
                    if (viewModel.isConnected && viewModel.isKontakOn) {
                        (viewModel.rpm / 12000f).coerceIn(0f, 1f)
                    } else {
                        0f
                    }

                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp),
                    color = hondaRed,
                    trackColor = Color.DarkGray
                )
            }
        }

        // DIAGNOSTIK DAN RESET

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            )
        ) {
            Column(
                modifier = Modif