package com.cands.ecureader.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = Color(0xFF121212)
            ) {
                EcuDashboardScreen()
            }
        }
    }
}

@Composable
fun EcuDashboardScreen() {
    var isConnected by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf("Auto Detect") }
    
    // Real data values (0 or -- when not connected, preventing fake animation loops)
    val rpm = if (isConnected) "4,2 x1000" else "0"
    val tps = if (isConnected) "38°" else "0°"
    val temp = if (isConnected) "92°C" else "--°C"
    val voltage = if (isConnected) "13.2 V" else "0.0 V"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header & Connection Status Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("ECU Reader Pro", color = Color.White, fontSize = 20.sp)
                Text("FTDI K-Line Edition", color = Color.Red, fontSize = 11.sp)
            }
            Button(
                onClick = { isConnected = !isConnected },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) Color.Green else Color.Red
                )
            ) {
                Text(if (isConnected) "Connected" else "Connect", color = Color.White)
            }
        }

        // Mode Selection Card (Auto / Manual)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Mode Koneksi / Tipe Motor:", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { selectedMode = "Auto Detect" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMode == "Auto Detect") Color.Red else Color.DarkGray
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Auto")
                    }
                    Button(
                        onClick = { selectedMode = "Manual Honda" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMode == "Manual Honda") Color.Red else Color.DarkGray
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Manual")
                    }
                }
            }
        }

        // Engine RPM Panel
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(rpm, color = Color.White, fontSize = 32.sp)
            }
        }

        // Secondary Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("BUKAAN GAS", tps, Modifier.weight(1f))
            MetricCard("SUHU MESIN", temp, Modifier.weight(1f))
            MetricCard("BATERAI", voltage, Modifier.weight(1f))
        }

        // Diagnostic Action Buttons
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = { /* TODO: Execute DTC Scan */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SCAN DTC (KODE KERUSAKAN)")
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 18.sp)
        }
    }
}
