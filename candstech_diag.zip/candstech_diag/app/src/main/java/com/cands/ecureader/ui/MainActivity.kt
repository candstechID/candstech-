package com.cands.ecureader.ui

import android.Manifest
import android.content.Context
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.viewmodel.EcuState
import com.cands.ecureader.viewmodel.EcuViewModel
import kotlinx.coroutines.launch

private val DarkBg = Color(0xFF0F0F0F)
private val CardBg = Color(0xFF1E1E1E)
private val HondaRed = Color(0xFFE10600)
private val GreenColor = Color(0xFF00C853)
private val YellowColor = Color(0xFFFFD600)

class MainActivity : ComponentActivity() {
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = DarkBg,
                    surface = CardBg,
                    primary = HondaRed,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
                    EcuAppController()
                }
            }
        }
    }
}

@Composable
fun EcuAppController(viewModel: EcuViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()
    var showDiagMenu by remember { mutableStateOf(false) }

    Crossfade(targetState = showDiagMenu, label = "ScreenTransition") { isDiagMode ->
        if (isDiagMode) {
            DiagnosticServiceScreen(state = state, onBack = { showDiagMenu = false })
        } else {
            EcuMainScreen(
                viewModel = viewModel, 
                state = state,
                onOpenDiagnostics = { showDiagMenu = true }
            )
        }
    }
}

@Composable
fun EcuMainScreen(
    viewModel: EcuViewModel, 
    state: EcuState,
    onOpenDiagnostics: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo",
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Column(modifier = Modifier.weight(1f)) {
                Text("ECU Reader Pro", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("FTDI K-Line Edition", color = HondaRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // 2. TOP SECTION - SPEED (ECU & GPS)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Speed ECU Card
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("SPEED ECU", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${state.speedEcu}", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
                    Text("km/h", color = HondaRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = Color.DarkGray, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOP: ${state.topSpeed}", color = Color.LightGray, fontSize = 11.sp)
                        Button(
                            onClick = { viewModel.resetTopSpeed() },
                            colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("RST", fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }

            // Speed GPS Card
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("SPEED GPS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${state.speedGps}", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
                    Text("km/h", color = GreenColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = Color.DarkGray, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOP: ${state.topSpeed}", color = Color.LightGray, fontSize = 11.sp)
                        Button(
                            onClick = { viewModel.resetTopSpeed() },
                            colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("RST", fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }
        }

        // 3. MIDDLE SECTION - RPM
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val rpmFormatted = String.format("%.1f", state.rpm / 1000f)
                    Text("$rpmFormatted x1000", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("${state.rpm} RPM", color = HondaRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                val rpmProgress = (state.rpm / 12000f).coerceIn(0f, 1f)
                val barColor = when {
                    state.rpm < 4000 -> GreenColor
                    state.rpm < 8000 -> YellowColor
                    else -> HondaRed
                }
                LinearProgressIndicator(
                    progress = { rpmProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp)),
                    color = barColor,
                    trackColor = Color.DarkGray
                )
            }
        }

        // 4. MIDDLE 3 KOLOM
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(10.dp)) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BUKAAN GAS", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${state.tpsDeg.toInt()}°", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("TPS (0°-80°)", color = HondaRed, fontSize = 9.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${String.format("%.2f", state.tpsVolt)} V", color = Color.LightGray, fontSize = 11.sp)
                }
            }
            Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(10.dp)) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AFR RATIO", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    val afrColor = if (state.afr in 14.0..15.5) GreenColor else HondaRed
                    Text("${state.afr}:1", color = afrColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Air Fuel Ratio", color = Color.LightGray, fontSize = 9.sp)
                }
            }
            Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(10.dp)) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SUHU MESIN", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${state.ectC}°C", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    val statusText = if (state.ectC > 105) "Overheat" else "Normal"
                    val statusColor = if (state.ectC > 105) HondaRed else GreenColor
                    Text(statusText, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 5. BOTTOM GRID 2x3
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GridItem("BATERAI", "${state.batteryV} V", Modifier.weight(1f))
                GridItem("BEBAN MESIN", "${state.engineLoadPct} %", Modifier.weight(1f))
                GridItem("TEKANAN MAP", "${state.mapKpa} kPa", Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GridItem("SUHU UDARA IAT", "${state.iatC}°C", Modifier.weight(1f))
                GridItem("IACV", "${state.iacvPct} %", Modifier.weight(1f))
                GridItem("INJEKTOR", "${state.injectorMs} ms", Modifier.weight(1f))
            }
        }

        if (state.dtcList.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1515)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DTC TROUBLE CODES DETECTED:", color = HondaRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    state.dtcList.forEach { dtc ->
                        Text("• $dtc", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        Text(state.logStatus, color = Color.Gray, fontSize = 10.sp)

        // 6. ACTION BUTTONS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onOpenDiagnostics,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0091EA))
            ) {
                Text("MENU DIAGNOSA", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { viewModel.scanDtc() },
                colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
            ) {
                Text("SCAN DTC", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { viewModel.clearDtc() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) {
                Text("HAPUS DTC", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { viewModel.resetTp() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) {
                Text("RESET TP", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { viewModel.startCsvLogger() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) {
                Text("LOGGER CSV", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun DiagnosticServiceScreen(state: EcuState, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(top = 16.dp, start = 12.dp, end = 12.dp)
    ) {
        // Header Diag Menu
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = CardBg),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("< KEMBALI", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("DATA DIAGNOSA SERVICE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("FULL ECU PARAMETER", color = HondaRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Diagnostic Data List
        LazyColumn(
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { DiagRow("Kecepatan ECU", "${state.speedEcu} km/h") }
            item { DiagRow("Putaran Mesin (RPM)", "${state.rpm} RPM") }
            item { DiagRow("Target Idle RPM", "${state.targetIdle} RPM") }
            item { DiagRow("Bukaan Gas (TPS)", "${state.tpsDeg.toInt()}° / ${String.format("%.2f", state.tpsVolt)} V") }
            item { DiagRow("Suhu Mesin (ECT)", "${state.ectC} °C") }
            item { DiagRow("Suhu Udara (IAT)", "${state.iatC} °C") }
            item { DiagRow("Tekanan Udara (MAP)", "${state.mapKpa} kPa") }
            item { DiagRow("Waktu Pengapian (Ignition)", "${String.format("%.1f", state.ignAdvanceDeg)}°") }
            item { DiagRow("Durasi Injektor", "${String.format("%.2f", state.injectorMs)} ms") }
            item { DiagRow("Tegangan O2 Sensor", "${String.format("%.2f", state.o2Volt)} V") }
            item { DiagRow("Air Fuel Ratio (AFR)", "${state.afr} : 1") }
            item { DiagRow("Tegangan Baterai", "${String.format("%.1f", state.batteryV)} V") }
            item { DiagRow("Beban Mesin (Load)", "${state.engineLoadPct} %") }
            item { DiagRow("Valve IACV", "${state.iacvPct} %") }
            
            // Status Switches
            item { Spacer(modifier = Modifier.height(8.dp)) }
            item { Text("STATUS SWITCH & SENSOR", color = HondaRed, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)) }
            
            item { DiagStatusRow("Fuel Pump (Pompa Bensin)", state.fuelPumpOn) }
            item { DiagStatusRow("Status MIL (Malfunction)", state.milOn, isErrorType = true) }
            item { DiagStatusRow("Standar Samping (Side Stand)", state.sideStandDown, activeText = "TURUN", inactiveText = "NAIK") }
            item { DiagStatusRow("Starter Switch", state.starterOn) }
        }
    }
}

@Composable
fun DiagRow(label: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.LightGray, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun DiagStatusRow(
    label: String, 
    isActive: Boolean, 
    isErrorType: Boolean = false,
    activeText: String = "ON",
    inactiveText: String = "OFF"
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.LightGray, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            
            val statusColor = if (isActive) {
                if (isErrorType) HondaRed else GreenColor
            } else {
                Color.Gray
            }
            val statusText = if (isActive) activeText else inactiveText
            
            Surface(
                color = statusColor.copy(alpha = 0.2f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun GridItem(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}
