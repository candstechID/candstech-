package com.cands.ecureader.ui

import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cands.ecureader.data.HondaKLineManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = Color(0xFF121212)
            ) {
                EcuDashboardScreen()
            }
        }
    }
}

@Composable
fun EcuDashboardScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val usbManager = remember { context.getSystemService(ComponentActivity.USB_SERVICE) as UsbManager }
    val kLineManager = remember { HondaKLineManager(usbManager) }

    var isConnected by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf("Auto") }
    
    // Live ECU metrics state
    var rpmVal by remember { mutableStateOf("0") }
    var tpsVal by remember { mutableStateOf("0°") }
    var tempVal by remember { mutableStateOf("--°C") }
    var batteryVal by remember { mutableStateOf("0.0 V") }
    var speedEcuVal by remember { mutableStateOf("0") }
    var afrVal by remember { mutableStateOf("--") }
    var engineLoadVal by remember { mutableStateOf("0 %") }
    var mapPressureVal by remember { mutableStateOf("0 kPa") }
    var iatVal by remember { mutableStateOf("--°C") }
    var iacvVal by remember { mutableStateOf("0 %") }
    var injectorVal by remember { mutableStateOf("0.0 ms") }

    // Background polling coroutine when connected to ECU
    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (isConnected) {
                // Fetch real data frames from KLineManager
                val liveData = kLineManager.requestLiveData()
                rpmVal = liveData["rpm"] ?: "0"
                tpsVal = liveData["tps"] ?: "0°"
                tempVal = liveData["temp"] ?: "--°C"
                batteryVal = liveData["voltage"] ?: "13.2 V"
                delay(200) // Poll every 200ms
            }
        } else {
            rpmVal = "0"
            tpsVal = "0°"
            tempVal = "--°C"
            batteryVal = "0.0 V"
            speedEcuVal = "0"
            afrVal = "--"
            engineLoadVal = "0 %"
            mapPressureVal = "0 kPa"
            iatVal = "--°C"
            iacvVal = "0 %"
            injectorVal = "0.0 ms"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header & Connection Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("ECU Reader Pro", color = Color.White, fontSize = 20.sp)
                Text("FTDI K-Line Edition ($selectedMode)", color = Color.Red, fontSize = 11.sp)
            }
            Button(
                onClick = {
                    if (!isConnected) {
                        // Find connected FTDI USB device
                        val deviceList = usbManager.deviceList
                        val ftdiDevice = deviceList.values.firstOrNull()
                        if (ftdiDevice != null) {
                            scope.launch {
                                val success = kLineManager.connect(ftdiDevice)
                                isConnected = success
                            }
                        } else {
                            // If no physical USB device is plugged in during testing, toggle connection for debugging
                            isConnected = true
                        }
                    } else {
                        kLineManager.disconnect()
                        isConnected = false
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) Color.Green else Color.Red
                )
            ) {
                Text(if (isConnected) "Connected" else "Connect", color = Color.White)
            }
        }

        // Mode Selection (Auto / Manual)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Mode Koneksi / Tipe Motor:", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { selectedMode = "Auto" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMode == "Auto") Color.Red else Color.DarkGray
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Auto")
                    }
                    Button(
                        onClick = { selectedMode = "Manual" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMode == "Manual") Color.Red else Color.DarkGray
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Manual")
                    }
                }
            }
        }

        // Speed ECU & Speed GPS Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCardWithRst("SPEED ECU", speedEcuVal, "km/h", "TOP: 0", Modifier.weight(1f))
            MetricCardWithRst("SPEED GPS", "0", "km/h", "TOP: 0", Modifier.weight(1f))
        }

        // Engine RPM Panel
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(rpmVal, color = Color.White, fontSize = 32.sp)
            }
        }

        // TPS, AFR, Engine Temp
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("BUKAAN GAS", tpsVal, Modifier.weight(1f))
            MetricCard("AFR RATIO", afrVal, Modifier.weight(1f))
            MetricCard("SUHU MESIN", tempVal, Modifier.weight(1f))
        }

        // Battery, Engine Load, Map Pressure
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("BATERAI", batteryVal, Modifier.weight(1f))
            MetricCard("BEBAN MESIN", engineLoadVal, Modifier.weight(1f))
            MetricCard("TEKANAN MAP", mapPressureVal, Modifier.weight(1f))
        }

        // IAT, IACV, Injector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("SUHU UDARA IAT", iatVal, Modifier.weight(1f))
            MetricCard("IACV", iacvVal, Modifier.weight(1f))
            MetricCard("INJEKTOR", injectorVal, Modifier.weight(1f))
        }

        // Diagnostic Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { /* Menu Diagnosa */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                modifier = Modifier.weight(1.2f)
            ) {
                Text("MENU DIAG", fontSize = 10.sp)
            }
            Button(
                onClick = {
                    scope.launch {
                        if (isConnected) {
                            kLineManager.sendCommand("72 07 00 13 00 00 F1") // DTC Read command frame
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier.weight(1.2f)
            ) {
                Text("SCAN DTC", fontSize = 10.sp)
            }
            Button(
                onClick = { /* Hapus DTC */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1.2f)
            ) {
                Text("HAPUS", fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 16.sp)
        }
    }
}

@Composable
fun MetricCardWithRst(title: String, value: String, unit: String, topText: String, modifier: Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = Color.White, fontSize = 28.sp)
            Text(unit, color = Color.Red, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(topText, color = Color.Gray, fontSize = 10.sp)
                Button(
                    onClick = { /* Reset Top */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text("RST", fontSize = 10.sp)
                }
            }
        }
    }
}
