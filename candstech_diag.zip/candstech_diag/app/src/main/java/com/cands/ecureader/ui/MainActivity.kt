package com.cands.ecureader.ui

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.viewmodel.EcuViewModel
import com.felhr.usbserial.UsbSerialDevice
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity(), LocationListener {
    
    private val viewModel: EcuViewModel by viewModels()
    private lateinit var locationManager: LocationManager
    
    private val ACTION_USB_PERMISSION = "com.cands.ecureader.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_USB_PERMISSION) {
                synchronized(this) {
                    val device: UsbDevice? = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            Toast.makeText(context, "Izin USB diberikan. Klik Connect lagi.", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(context, "Izin USB ditolak.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1f, this)
        } catch (e: SecurityException) {
            // Handle permission denied
        }

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }

        setContent { EcuReaderScreen(viewModel, this) }
    }

    override fun onLocationChanged(location: Location) {
        if (location.hasSpeed()) {
            viewModel.updateGpsSpeed(location.speed)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            locationManager.removeUpdates(this)
            unregisterReceiver(usbReceiver)
        } catch (e: Exception) {
            // Ignore
        }
    }
}

@Composable
fun EcuReaderScreen(viewModel: EcuViewModel, context: Context) {
    val darkBg = Color(0xFF0F0F0F)
    val cardBg = Color(0xFF1E1E1E)
    val hondaRed = Color(0xFFE10600)
    val scope = rememberCoroutineScope()
    var showBikeDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(darkBg)
            .padding(8.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painter = painterResource(id = R.drawable.logo), contentDescription = "Logo", modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("ECU Reader Pro", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Exact Protocol Edition", color = hondaRed, fontSize = 11.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusBadge(label = if (viewModel.isConnected) "CONNECTED" else "DISCONNECTED", isOk = viewModel.isConnected)
                StatusBadge(label = if (viewModel.isKontakOn) "KONTAK ON" else "KONTAK OFF", isOk = viewModel.isKontakOn)
            }
        }

        // Speed Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SpeedCard(Modifier.weight(1f), "SPEED ECU", viewModel.speedEcu, viewModel.topSpeedEcu, { viewModel.resetTopEcu() }, cardBg, hondaRed)
            SpeedCard(Modifier.weight(1f), "SPEED GPS", viewModel.speedGps, viewModel.topSpeedGps, { viewModel.resetTopGps() }, cardBg, hondaRed)
        }

        // RPM Card - FIXED LinearProgressIndicator
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cardBg)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    val rpmText = if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.rpm}" else "--"
                    Text(rpmText, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("RPM", color = hondaRed, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                val progress = if (viewModel.isConnected && viewModel.isKontakOn) (viewModel.rpm / 12000f).coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(
                    progress = progress,  // ✅ FIXED: Tanpa kurung kurawal
                    modifier = Modifier.fillMaxWidth().height(12.dp), 
                    color = hondaRed, 
                    trackColor = Color.DarkGray
                )
            }
        }

        // Info Cards Row 1
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InfoCard(Modifier.weight(1f), "Bukaan Gas", if (viewModel.isConnected && viewModel.isKontakOn) "${String.format("%.1f", viewModel.tpsDegrees)}°" else "--", if (viewModel.isConnected && viewModel.isKontakOn) "${String.format("%.2f", viewModel.tpsVolt)}V" else "--", Color.White, cardBg)
            InfoCard(Modifier.weight(1f), "AFR", if (viewModel.isConnected && viewModel.isKontakOn) "${String.format("%.1f", viewModel.afr)}:1" else "--", if (!viewModel.isConnected || !viewModel.isKontakOn) "Standby" else "Ideal", Color.White, cardBg)
            InfoCard(Modifier.weight(1f), "Suhu Mesin", if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.ect}°C" else "--", if (viewModel.isConnected) "Normal" else "Standby", Color.White, cardBg)
        }

        // Grid Items
        val gridItems = listOf(
            "Baterai" to if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.batteryVolt} V" else "--",
            "Beban Mesin" to if (viewModel.isConnected && viewModel.isKontakOn) "${String.format("%.1f", viewModel.engineLoad)} %" else "--",
            "Tekanan MAP" to if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.mapKpa} kPa" else "--",
            "Suhu Udara IAT" to if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.iat} °C" else "--",
            "IACV" to if (viewModel.isConnected && viewModel.isKontakOn) "${viewModel.iacv} %" else "--",
            "Injektor" to if (viewModel.isConnected && viewModel.isKontakOn) "${String.format("%.2f", viewModel.injectorMs)} ms" else "--"
        )
        
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in gridItems.indices step 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GridItemCard(Modifier.weight(1f), gridItems[i].first, gridItems[i].second, cardBg)
                    if (i + 1 < gridItems.size) GridItemCard(Modifier.weight(1f), gridItems[i+1].first, gridItems[i+1].second, cardBg)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // DEBUG LOG CARD
        Card(modifier = Modifier.fillMaxWidth().height(150.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))) {
            Column(modifier = Modifier.padding(8.dp)) {
                Text("DEBUG LOG (LIVE)", color = hondaRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Box(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        if (viewModel.debugLogs.isEmpty()) {
                            Text("Belum ada aktivitas...", color = Color.Gray, fontSize = 10.sp)
                        } else {
                            viewModel.debugLogs.takeLast(30).forEach { log ->
                                Text(log, color = Color(0xFF00FF00), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Connect Button
        Button(
            onClick = { 
                scope.launch {
                    try {
                        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
                        val deviceList = usbManager.deviceList
                        val device = deviceList.values.firstOrNull()
                        
                        if (device == null) {
                            Toast.makeText(context, "❌ FTDI USB tidak terdeteksi", Toast.LENGTH_LONG).show()
                            viewModel.addLog("ERROR: USB device tidak ditemukan")
                            return@launch
                        }

                        if (!usbManager.hasPermission(device)) {
                            val permissionIntent = PendingIntent.getBroadcast(
                                context, 
                                0, 
                                Intent("com.cands.ecureader.USB_PERMISSION"), 
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                            )
                            usbManager.requestPermission(device, permissionIntent)
                            Toast.makeText(context, "⏳ Meminta izin USB...", Toast.LENGTH_LONG).show()
                            viewModel.addLog("Meminta izin USB...")
                            return@launch
                        }

                        val connection = usbManager.openDevice(device)
                        val serialDevice = UsbSerialDevice.createUsbSerialDevice(device, connection)
                        
                        if (serialDevice != null) {
                            val manager = HondaKLineManager(serialDevice)
                            manager.setupPort()
                            viewModel.initKLineListener(manager)
                            
                            Toast.makeText(context, "⏳ Mencoba Universal Init...", Toast.LENGTH_SHORT).show()
                            viewModel.addLog("Memulai Universal Init (Slow -> Fast)...")
                            
                            val success = manager.performUniversalInit()
                            
                            if (success) {
                                viewModel.startPolling()
                                Toast.makeText(context, "✅ K-Line Terhubung!", Toast.LENGTH_LONG).show()
                                viewModel.addLog("✅ POLLING DIMULAI")
                            } else {
                                Toast.makeText(context, "❌ Init Gagal", Toast.LENGTH_LONG).show()
                                viewModel.addLog(" Inisialisasi GAGAL")
                            }
                        } else {
                            Toast.makeText(context, "❌ Gagal buat Serial Device", Toast.LENGTH_LONG).show()
                            viewModel.addLog("ERROR: Serial Device null")
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "❌ Error: ${e.message}", Toast.LENGTH_LONG).show()
                        viewModel.addLog("EXCEPTION: ${e.message}")
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = hondaRed), 
            modifier = Modifier.fillMaxWidth()
        ) { 
            Text("CONNECT K-LINE (UNIVERSAL)") 
        }

        // Bike Selection Card
        Card(modifier = Modifier.fillMaxWidth().clickable { showBikeDialog = true }, colors = CardDefaults.cardColors(containerColor = cardBg)) {
            Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("STATUS MOTOR / ECU TERHUBUNG", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(if (viewModel.isConnected) viewModel.selectedBike.name else "Belum Terhubung", color = if (viewModel.isConnected) Color.White else Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(if (viewModel.isConnected) "ECU: ${viewModel.selectedBike.ecuType}" else "Mode: ${viewModel.selectedBike.name}", color = if (viewModel.isConnected) hondaRed else Color.Gray, fontSize = 11.sp)
                }
                Surface(color = if (viewModel.isConnected) hondaRed else Color.DarkGray, shape = RoundedCornerShape(8.dp)) {
                    Text("PILIH / UBAH", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
            }
        }
    }

    // Bike Selection Dialog
    if (showBikeDialog) {
        AlertDialog(
            onDismissRequest = { showBikeDialog = false }, 
            title = { Text("Pilih Profil Motor", color = Color.White, fontWeight = FontWeight.Bold) }, 
            containerColor = Color(0xFF1E1E1E),
            text = {
                Column(modifier = Modifier.height(350.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (bike in com.cands.ecureader.data.HondaBikeProfiles.list) {
                        Surface(
                            color = if (viewModel.selectedBike.id == bike.id) hondaRed else Color(0xFF2A2A2A), 
                            shape = RoundedCornerShape(8.dp), 
                            modifier = Modifier.fillMaxWidth().clickable { 
                                viewModel.selectBike(bike)
                                showBikeDialog = false 
                            }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(bike.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }, 
            confirmButton = { TextButton(onClick = { showBikeDialog = false }) { Text("TUTUP", color = hondaRed) } }
        )
    }
}

@Composable
fun StatusBadge(label: String, isOk: Boolean) {
    Surface(color = if (isOk) Color(0xFF1B5E20) else Color(0xFFB71C1C), shape = RoundedCornerShape(12.dp), modifier = Modifier.height(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            Box(modifier = Modifier.size(6.dp).background(if (isOk) Color(0xFF4CAF50) else Color(0xFFFF5252), CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SpeedCard(modifier: Modifier, title: String, speed: Int, topSpeed: Int, onResetTop: () -> Unit, cardBg: Color, hondaRed: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text("$speed", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Button(onClick = onResetTop, colors = ButtonDefaults.buttonColors(containerColor = hondaRed), modifier = Modifier.height(24.dp), contentPadding = PaddingValues(4.dp)) {
                Text("RESET TOP", fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun InfoCard(modifier: Modifier, title: String, mainVal: String, subVal: String, color: Color, cardBg: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(mainVal, color = color, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(subVal, color = color, fontSize = 12.sp)
        }
    }
}

@Composable
fun GridItemCard(modifier: Modifier, title: String, value: String, cardBg: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = cardBg)) {
        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}