package com.cands.ecureader.ui

import android.content.Context
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cands.ecureader.data.HondaKLineManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = Color(0xFF121212)
            ) {
                EcuDashboardScreen()
            }
        }
    }
}

@Composable
fun EcuDashboardScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val usbManager = remember { context.getSystemService(Context.USB_SERVICE) as UsbManager }
    val kLineManager = remember { HondaKLineManager(usbManager) }

    var isConnected by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf("Auto") }
    var selectedMotor by remember { mutableStateOf("Menunggu Koneksi...") }
    var showMotorDialog by remember { mutableStateOf(false) }
    
    val motorList = listOf(
        "Honda BeAT / Scoopy eSP (K44/K93)",
        "Honda Vario 125/150 LED (K35/K59)",
        "Honda PCX 150 / ADV 150 (K97)",
        "Honda CB150R / CBR150R",
        "Honda CRF 150L / Verza"
    )

    var rpmVal by remember { mutableStateOf("0") }
    var tpsVal by remember { mutableStateOf("0°") }
    var tempVal by remember { mutableStateOf("--°C") }
    var batteryVal by remember { mutableStateOf("0.0 V") }
    var speedEcuVal by remember { mutableStateOf("0") }
    var topSpeedEcu by remember { mutableStateOf("0") }
    var topSpeedGps by remember { mutableStateOf("0") }
    var afrVal by remember { mutableStateOf("--") }
    var engineLoadVal by remember { mutableStateOf("0 %") }
    var mapPressureVal by remember { mutableStateOf("0 kPa") }
    var iatVal by remember { mutableStateOf("--°C") }
    var iacvVal by remember { mutableStateOf("0 %") }
    var injectorVal by remember { mutableStateOf("0.0 ms") }

    // Coroutine untuk memperbarui data sensor terus menerus saat terhubung
    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (isConnected) {
                val liveData = kLineManager.requestLiveData()
                rpmVal = liveData["rpm"]?.toString() ?: "0"
                tpsVal = liveData["tps"]?.toString() ?: "0°"
                tempVal = liveData["temp"]?.toString() ?: "--°C"
                batteryVal = liveData["voltage"]?.toString() ?: "13.2 V"
                mapPressureVal = liveData["map"]?.toString() ?: "30 kPa"
                iatVal = liveData["iat"]?.toString() ?: "29°C"
                iacvVal = liveData["iacv"]?.toString() ?: "15 %"
                injectorVal = liveData["injector"]?.toString() ?: "2.5 ms"
                delay(200) // Polling data setiap 200 milidetik
            }
        } else {
            // Reset UI jika diskonek
            rpmVal = "0"
            tpsVal = "0°"
            tempVal = "--°C"
            batteryVal = "0.0 V"
            speedEcuVal = "0"
            afrVal = "--"
            engineLoadVal = "0 %"
            mapPressureVal = "0 kPa"
            iatVal = "--°C"
            iacvVal = "0 %"
            injectorVal = "0.0 ms"
        }
    }

    if (showMotorDialog) {
        AlertDialog(
            onDismissRequest = { showMotorDialog = false },
            title = { Text("Pilih Tipe Motor Honda", color = Color.White) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    motorList.forEach { motor ->
                        Text(
                            text = motor,
                            color = if (selectedMotor == motor) Color.Red else Color.LightGray,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedMotor = motor
                                    showMotorDialog = false
                                    Toast.makeText(context, "Motor diset ke: $motor", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 10.dp),
                            fontSize = 14.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showMotorDialog = false }) { Text("Tutup") }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header & Tombol Connect
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("ECU Reader Pro", color = Color.White, fontSize = 20.sp)
                Text("FTDI K-Line Edition ($selectedMode)", color = Color.Red, fontSize = 11.sp)
            }
            Button(
                onClick = {
                    if (!isConnected) {
                        val deviceList = usbManager.deviceList
                        val ftdiDevice = deviceList.values.firstOrNull()
                        if (ftdiDevice != null) {
                            Toast.makeText(context, "Mencoba jabat tangan ECU...", Toast.LENGTH_SHORT).show()
                            scope.launch {
                                // Eksekusi koneksi (termasuk filter echo dan deteksi auto)
                                val success = kLineManager.connect(ftdiDevice, selectedMode, selectedMotor)
                                isConnected = success
                                
                                if (success) {
                                    // Perbarui teks motor di layar berdasarkan deteksi KLineManager
                                    selectedMotor = kLineManager.connectedMotorName
                                    Toast.makeText(context, "SUKSES Terhubung: $selectedMotor", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "GAGAL: ECU Tidak Merespon / Kontak Off", Toast.LENGTH_LONG).show()
                                }
                            }
                        } else {
                            Toast.makeText(context, "Kabel FTDI tidak ditemukan!", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        kLineManager.disconnect()
                        isConnected = false
                        Toast.makeText(context, "Koneksi diputus", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) Color.Green else Color.Red
                )
            ) {
                Text(if (isConnected) "Connected" else "Connect", color = Color.White)
            }
        }

        // Card Mode Koneksi
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Mode Koneksi:", color = Color.Gray, fontSize = 12.sp)
                    Text("Motor: $selectedMotor", color = Color.Red, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { 
                            selectedMode = "Auto"
                            selectedMotor = "Menunggu Koneksi..."
                            Toast.makeText(context, "Mode Auto", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedMode == "Auto") Color.Red else Color.DarkGray),
                        modifier = Modifier.weight(1f)
                    ) { Text("Auto") }
                    
                    Button(
                        onClick = { 
                            selectedMode = "Manual"
                            showMotorDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedMode == "Manual") Color.Red else Color.DarkGray),
                        modifier = Modifier.weight(1f)
                    ) { Text("Manual (Pilih)") }
                }
            }
        }

        // Row Speed
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCardWithRst("SPEED ECU", speedEcuVal, "km/h", "TOP: $topSpeedEcu", Modifier.weight(1f)) { topSpeedEcu = "0" }
            MetricCardWithRst("SPEED GPS", "0", "km/h", "TOP: $topSpeedGps", Modifier.weight(1f)) { topSpeedGps = "0" }
        }

        // Card RPM
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(rpmVal, color = Color.White, fontSize = 32.sp)
            }
        }

        // 3 Baris Kartu Sensor
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("BUKAAN GAS", tpsVal, Modifier.weight(1f))
            MetricCard("AFR RATIO", afrVal, Modifier.weight(1f))
            MetricCard("SUHU MESIN", tempVal, Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("BATERAI", batteryVal, Modifier.weight(1f))
            MetricCard("BEBAN MESIN", engineLoadVal, Modifier.weight(1f))
            MetricCard("TEKANAN MAP", mapPressureVal, Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("SUHU UDARA IAT", iatVal, Modifier.weight(1f))
            MetricCard("IACV", iacvVal, Modifier.weight(1f))
            MetricCard("INJEKTOR", injectorVal, Modifier.weight(1f))
        }

        // Tombol Diagnostik Bawah
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { Toast.makeText(context, "Membuka Menu Diagnostik...", Toast.LENGTH_SHORT).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("DIAG", fontSize = 10.sp) }

            Button(
                onClick = {
                    scope.launch {
                        if (isConnected) {
                            val res = kLineManager.sendCommand("82 11 F1 18 00") // Format Read DTC KWP2000
                            Toast.makeText(context, "Scan DTC Selesai. Byte diterima: ${res?.size ?: 0}", Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(context, "Belum terhubung ke ECU!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("SCAN", fontSize = 10.sp) }

            Button(
                onClick = {
                    scope.launch {
                        if (isConnected) {
                            val res = kLineManager.sendCommand("82 11 F1 21 08") // Format Reset TP
                            Toast.makeText(context, "Reset TP Berhasil Dikirim!", Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(context, "Belum terhubung ke ECU!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF6C00)),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("RST TP", fontSize = 10.sp) }

            Button(
                onClick = {
                    scope.launch {
                        if (isConnected) {
                            val res = kLineManager.sendCommand("82 11 F1 14 00") // Format Clear DTC (Service 14)
                            Toast.makeText(context, "Hapus Sejarah DTC Berhasil Dikirim!", Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(context, "Belum terhubung ke ECU!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("HAPUS", fontSize = 10.sp) }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 16.sp)
        }
    }
}

@Composable
fun MetricCardWithRst(title: String, value: String, unit: String, topText: String, modifier: Modifier, onReset: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = Color.White, fontSize = 28.sp)
            Text(unit, color = Color.Red, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(topText, color = Color.Gray, fontSize = 10.sp)
                Button(
                    onClick = onReset,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) { Text("RST", fontSize = 10.sp) }
            }
        }
    }
}
