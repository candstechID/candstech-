# ECU Reader Pro V3 - perubahan dan batas validasi

## Perubahan
- UI dashboard utama, logo, susunan kartu, dan tombol dipertahankan.
- Deteksi USB sekarang memilih VID FTDI `0x0403`, bukan perangkat USB pertama.
- Jika izin USB belum ada, aplikasi meminta izin melalui `UsbManager.requestPermission`; setelah dialog izin disetujui, tekan Connect lagi.
- Connect sekarang berarti `USB READY` (port FTDI terbuka), bukan ECU sudah handshake.
- Serial diset 10400 baud, 8 data bit, no parity, 1 stop bit, flow control off.
- Tidak lagi memaksa RTS/DTR dan tidak memakai BREAK sebagai asumsi inisialisasi ECU.
- Ditambahkan panel DIAG dengan probe identifikasi kandidat `82 11 F1 1A 90 2E`, TX/RX mentah, status, dan pencatatan transaksi ke CSV internal saat CSV logging disiapkan.
- Nilai sensor yang belum benar-benar dibaca ditampilkan `--`; stream simulasi dihapus.
- Scan DTC, reset TPS, dan hapus DTC tidak mengirim perintah spekulatif. Tombol memberi penjelasan bahwa prosedur K59A-A11 belum tervalidasi.
- CSV dibuat di direktori internal aplikasi (`filesDir/ECU_Communication_Log.csv`).
- ViewModel tidak lagi menghasilkan DTC, reset TPS, atau data sensor palsu.

## Batas yang belum dapat diklaim
- Tidak ada capture TX/RX Analis Pro V5, sehingga urutan wake-up / 5-baud / fast-init K59A-A11 belum diketahui.
- Probe `82 11 F1 1A 90 2E` berasal dari contoh yang dikirim pengguna dan belum dibuktikan cocok dengan ECU 30400-K59A-A11.
- Belum ada tabel PID/Local Identifier dan scaling sensor K59A-A11 yang tervalidasi. Karena itu live data, speed ECU, AFR, MAP, TPS, ECT, IAT, injektor dan lainnya tetap `--`.
- Auto detection ECU belum melakukan identifikasi otomatis; mode Auto hanya label mode sampai protokol ECU dibuktikan.
- GPS speed belum diaktifkan di dashboard karena permission runtime dan integrasi lokasi UI belum diselesaikan.
- Scan DTC, RST TP, dan hapus DTC sengaja dikunci untuk menghindari pengiriman service/identifier yang salah.

## Pengujian
Sumber diperbarui dan ZIP diperiksa integritasnya. APK belum dibuild atau diuji pada perangkat karena lingkungan kerja ini tidak menyediakan Android SDK/Gradle wrapper. Build dan uji koneksi fisik tetap diperlukan.
