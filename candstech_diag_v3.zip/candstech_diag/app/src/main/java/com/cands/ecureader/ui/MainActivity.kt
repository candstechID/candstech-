package com.cands.ecureader.ui

import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cands.ecureader.R
import com.cands.ecureader.data.HondaKLineManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                color = Color(0xFF121212)
            ) {
                EcuDashboardScreen()
            }
        }
    }
}

@Composable
fun EcuDashboardScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val usbManager = remember { context.getSystemService(Context.USB_SERVICE) as UsbManager }
    val kLineManager = remember { HondaKLineManager(usbManager) }

    var isConnected by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf("Auto") }
    var selectedMotor by remember { mutableStateOf("Menunggu Koneksi...") }
    var showMotorDialog by remember { mutableStateOf(false) }
    var showDiagDialog by remember { mutableStateOf(false) }
    var diagStatus by remember { mutableStateOf("Belum ada pengujian") }
    var csvLogging by remember { mutableStateOf(false) }
    var csvPath by remember { mutableStateOf("Belum dibuat") }
    
    val motorList = listOf(
        "Honda BeAT / Scoopy eSP (K44/K93)",
        "Honda Vario 125/150 LED (K35/K59)",
        "Honda PCX 150 / ADV 150 (K97)",
        "Honda CB150R / CBR150R",
        "Honda CRF 150L / Verza"
    )

    var rpmVal by remember { mutableStateOf("--") }
    var tpsVal by remember { mutableStateOf("--") }
    var tempVal by remember { mutableStateOf("--") }
    var batteryVal by remember { mutableStateOf("--") }
    var speedEcuVal by remember { mutableStateOf("--") }
    var topSpeedEcu by remember { mutableStateOf("0") }
    var topSpeedGps by remember { mutableStateOf("0") }
    var afrVal by remember { mutableStateOf("--") }
    var engineLoadVal by remember { mutableStateOf("--") }
    var mapPressureVal by remember { mutableStateOf("--") }
    var iatVal by remember { mutableStateOf("--") }
    var iacvVal by remember { mutableStateOf("--") }
    var injectorVal by remember { mutableStateOf("--") }

    LaunchedEffect(isConnected) {
        if (!isConnected) {
            rpmVal = "--"
            tpsVal = "--"
            tempVal = "--"
            batteryVal = "--"
            speedEcuVal = "--"
            afrVal = "--"
            engineLoadVal = "--"
            mapPressureVal = "--"
            iatVal = "--"
            iacvVal = "--"
            injectorVal = "--"
        }
    }

    if (showDiagDialog) {
        AlertDialog(
            onDismissRequest = { showDiagDialog = false },
            title = { Text("Diagnostik K-Line", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Status: $diagStatus", color = Color.LightGray)
                    Text("TX: ${kLineManager.lastTxHex}", color = Color.Cyan, fontSize = 11.sp)
                    Text("RX: ${kLineManager.lastRxHex}", color = Color.Cyan, fontSize = 11.sp)
                    Text("CSV: $csvPath", color = Color.Gray, fontSize = 10.sp)
                    Button(onClick = {
                        scope.launch {
                            val rx = kLineManager.requestEcuIdentification()
                            diagStatus = kLineManager.lastStatus + "\nTX=${kLineManager.lastTxHex}\nRX=${kLineManager.lastRxHex}"
                            if (csvLogging) {
                                val file = File(context.filesDir, "ECU_Communication_Log.csv")
                                if (!file.exists()) file.writeText("timestamp,tx,rx,status\n")
                                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
                                file.appendText("\"$stamp\",\"${kLineManager.lastTxHex}\",\"${kLineManager.lastRxHex}\",\"${kLineManager.lastStatus}\"\n")
                                csvPath = file.absolutePath
                            }
                            Toast.makeText(context, if (rx == null) "Probe dikirim; belum ada respons ECU" else "RX ${rx.size} byte diterima", Toast.LENGTH_LONG).show()
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("BACA ECU ID (PROBE)") }
                    Button(onClick = {
                        val file = File(context.filesDir, "ECU_Communication_Log.csv")
                        if (!file.exists()) file.writeText("timestamp,tx,rx,status\n")
                        csvPath = file.absolutePath
                        val nextLoggingState = !csvLogging
                        csvLogging = nextLoggingState
                        diagStatus = if (nextLoggingState) "CSV logging aktif untuk transaksi TX/RX berikutnya" else "CSV logging nonaktif"
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (csvLogging) "STOP CSV LOG" else "SIAPKAN CSV LOG") }
                    Text("RST TP dan HAPUS DTC dikunci sampai prosedur K59A-A11 terverifikasi. Tidak ada perintah tulis yang dikirim.", color = Color.Yellow, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showDiagDialog = false }) { Text("TUTUP") } },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    if (showMotorDialog) {
        AlertDialog(
            onDismissRequest = { showMotorDialog = false },
            title = { Text("Pilih Tipe Motor Honda", color = Color.White) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    motorList.forEach { motor ->
                        Text(
                            text = motor,
                            color = if (selectedMotor == motor) Color.Red else Color.LightGray,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedMotor = motor
                                    showMotorDialog = false
                                    Toast.makeText(context, "Motor diset ke: $motor", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 10.dp),
                            fontSize = 14.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showMotorDialog = false }) { Text("Tutup") }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Panggil logo dengan aman (pastikan file logo.png ada di res/drawable)
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(36.dp)
                )

                Column {
                    Text("ECU Reader Pro", color = Color.White, fontSize = 18.sp)
                    Text("FTDI K-Line Edition ($selectedMode)", color = Color.Red, fontSize = 11.sp)
                }
            }

            Button(
                onClick = {
                    if (!isConnected) {
                        val deviceList = usbManager.deviceList
                        val ftdiDevice = deviceList.values.firstOrNull { it.vendorId == HondaKLineManager.FTDI_VENDOR_ID }
                        if (ftdiDevice != null) {
                            if (!usbManager.hasPermission(ftdiDevice)) {
                                val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                                val permissionIntent = PendingIntent.getBroadcast(
                                    context, 0,
                                    Intent("${context.packageName}.USB_PERMISSION").setPackage(context.packageName),
                                    pendingFlags
                                )
                                usbManager.requestPermission(ftdiDevice, permissionIntent)
                                Toast.makeText(context, "Izinkan akses USB, lalu tekan Connect lagi", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            Toast.makeText(context, "Membuka port FTDI...", Toast.LENGTH_SHORT).show()
                            scope.launch {
                                val success = kLineManager.connect(ftdiDevice, selectedMode, selectedMotor)
                                isConnected = success
                                
                                if (success) {
                                    selectedMotor = kLineManager.connectedMotorName
                                    Toast.makeText(context, "USB READY. ECU belum teridentifikasi.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, kLineManager.lastStatus, Toast.LENGTH_LONG).show()
                                }
                            }
                        } else {
                            Toast.makeText(context, "Kabel FTDI tidak ditemukan!", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        kLineManager.disconnect()
                        isConnected = false
                        Toast.makeText(context, "Koneksi diputus", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) Color.Green else Color.Red
                )
            ) {
                Text(if (isConnected) "USB READY" else "Connect", color = Color.White)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Mode Koneksi:", color = Color.Gray, fontSize = 12.sp)
                    Text("Motor: $selectedMotor", color = Color.Red, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { 
                            selectedMode = "Auto"
                            selectedMotor = "Menunggu Koneksi..."
                            Toast.makeText(context, "Mode Auto", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedMode == "Auto") Color.Red else Color.DarkGray),
                        modifier = Modifier.weight(1f)
                    ) { Text("Auto") }
                    
                    Button(
                        onClick = { 
                            selectedMode = "Manual"
                            showMotorDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedMode == "Manual") Color.Red else Color.DarkGray),
                        modifier = Modifier.weight(1f)
                    ) { Text("Manual (Pilih)") }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCardWithRst("SPEED ECU", speedEcuVal, "km/h", "TOP: $topSpeedEcu", Modifier.weight(1f)) { topSpeedEcu = "0" }
            MetricCardWithRst("SPEED GPS", "--", "km/h", "TOP: $topSpeedGps", Modifier.weight(1f)) { topSpeedGps = "0" }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(rpmVal, color = Color.White, fontSize = 32.sp)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("BUKAAN GAS", tpsVal, Modifier.weight(1f))
            MetricCard("AFR RATIO", afrVal, Modifier.weight(1f))
            MetricCard("SUHU MESIN", tempVal, Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("BATERAI", batteryVal, Modifier.weight(1f))
            MetricCard("BEBAN MESIN", engineLoadVal, Modifier.weight(1f))
            MetricCard("TEKANAN MAP", mapPressureVal, Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("SUHU UDARA IAT", iatVal, Modifier.weight(1f))
            MetricCard("IACV", iacvVal, Modifier.weight(1f))
            MetricCard("INJEKTOR", injectorVal, Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { showDiagDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("DIAG", fontSize = 10.sp) }

            Button(
                onClick = { Toast.makeText(context, "Pembacaan DTC belum diaktifkan: service Honda K59A-A11 belum tervalidasi", Toast.LENGTH_LONG).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("SCAN", fontSize = 10.sp) }

            Button(
                onClick = { Toast.makeText(context, "RST TP dikunci sampai prosedur resmi K59A-A11 terverifikasi", Toast.LENGTH_LONG).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF6C00)),
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("RST TP", fontSize = 10.sp) }

            Button(
                onClick = { Toast.makeText(context, "HAPUS DTC dikunci untuk mencegah perintah yang salah ke ECU", Toast.LENGTH_LONG).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp)
            ) { Text("HAPUS", fontSize = 10.sp) }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 16.sp)
        }
    }
}

@Composable
fun MetricCardWithRst(title: String, value: String, unit: String, topText: String, modifier: Modifier, onReset: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = Color.White, fontSize = 28.sp)
            Text(unit, color = Color.Red, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(topText, color = Color.Gray, fontSize = 10.sp)
                Button(
                    onClick = onReset,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) { Text("RST", fontSize = 10.sp) }
            }
        }
    }
}
