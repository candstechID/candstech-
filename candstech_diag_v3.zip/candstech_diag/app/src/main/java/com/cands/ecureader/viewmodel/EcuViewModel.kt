package com.cands.ecureader.viewmodel

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.app.Application
import android.content.Context
import android.location.Location
import android.os.Looper
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val Context.dataStore by preferencesDataStore(name = "ecu_prefs")

data class EcuState(
    val speedEcu: Int = 0,
    val speedGps: Int = 0,
    val topSpeed: Int = 0,
    val rpm: Int = 0,
    val tpsDeg: Float = 0f,
    val tpsVolt: Float = 0.5f,
    val afr: Float = 14.7f,
    val ectC: Int = 85,
    val batteryV: Float = 12.8f,
    val engineLoadPct: Int = 22,
    val mapKpa: Int = 32,
    val iatC: Int = 30,
    val iacvPct: Int = 28,
    val injectorMs: Float = 2.4f,
    val dtcList: List<String> = emptyList(),
    val isScanning: Boolean = false,
    val logStatus: String = "Idle",
    
    // EXTENDED DIAGNOSTIC DATA FOR SERVICE
    val ignAdvanceDeg: Float = 12.5f,
    val o2Volt: Float = 0.45f,
    val targetIdle: Int = 1500,
    val fuelPumpOn: Boolean = true,
    val starterOn: Boolean = false,
    val milOn: Boolean = false,
    val sideStandDown: Boolean = false
)

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    private val _state = MutableStateFlow(EcuState())
    val state: StateFlow<EcuState> = _state.asStateFlow()

    private val topSpeedKey = floatPreferencesKey("top_speed")
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    init {
        loadTopSpeed()
        initGps(application)
    }

    private fun loadTopSpeed() {
        viewModelScope.launch {
            getApplication<Application>().dataStore.data
                .map { prefs -> prefs[topSpeedKey] ?: 0f }
                .collect { ts ->
                    _state.value = _state.value.copy(topSpeed = ts.toInt())
                }
        }
    }

    fun resetTopSpeed() {
        viewModelScope.launch {
            getApplication<Application>().dataStore.edit { prefs ->
                prefs[topSpeedKey] = 0f
            }
            _state.value = _state.value.copy(topSpeed = 0)
        }
    }

    @SuppressLint("MissingPermission")
    private fun initGps(context: Context) {
        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) return // Activity must request runtime location permission first.
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    val speedKmh = (loc.speed * 3.6f).roundToInt().coerceAtLeast(0)
                    val currentTop = _state.value.topSpeed
                    if (speedKmh > currentTop) {
                        viewModelScope.launch {
                            getApplication<Application>().dataStore.edit { prefs ->
                                prefs[topSpeedKey] = speedKmh.toFloat()
                            }
                        }
                    }
                    _state.value = _state.value.copy(
                        speedGps = speedKmh,
                        topSpeed = maxOf(currentTop, speedKmh)
                    )
                }
            }
        }
        try {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
        } catch (_: Exception) {}
    }


    fun scanDtc() {
        _state.value = _state.value.copy(
            isScanning = false,
            dtcList = emptyList(),
            logStatus = "DTC belum dibaca: protokol Honda K59A-A11 belum tervalidasi"
        )
    }

    fun clearDtc() {
        _state.value = _state.value.copy(logStatus = "HAPUS DTC dikunci: prosedur ECU belum tervalidasi")
    }

    fun resetTp() {
        _state.value = _state.value.copy(logStatus = "RST TP dikunci: prosedur ECU belum tervalidasi")
    }

    fun startCsvLogger() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = java.io.File(getApplication<Application>().filesDir, "ECU_Log.csv")
                if (!file.exists()) file.writeText("timestamp,rpm,tps,ect,battery\n")
                _state.value = _state.value.copy(logStatus = "CSV siap: ${file.absolutePath}")
            } catch (e: Exception) {
                _state.value = _state.value.copy(logStatus = "CSV gagal: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (_: Exception) {}
    }
}
