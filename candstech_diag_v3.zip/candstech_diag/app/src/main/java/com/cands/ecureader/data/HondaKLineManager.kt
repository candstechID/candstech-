package com.cands.ecureader.data

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * USB/serial transport for an FTDI K-Line adapter.
 * Opening the serial port is deliberately NOT reported as an ECU connection.
 * ECU protocol initialization for K59A-A11 is still unverified and must be
 * established from a known-good Analis Pro V5 trace before write commands are enabled.
 */
class HondaKLineManager(private val usbManager: UsbManager) {
    private var serialDevice: UsbSerialDevice? = null
    private var connection: UsbDeviceConnection? = null
    var isConnected: Boolean = false
        private set
    var connectedMotorName: String = "USB READY - ECU belum terverifikasi"
        private set
    var lastTxHex: String = "-"
        private set
    var lastRxHex: String = "-"
        private set
    var lastStatus: String = "Belum terhubung"
        private set

    suspend fun connect(device: UsbDevice, mode: String, motorType: String): Boolean = withContext(Dispatchers.IO) {
        disconnect()
        try {
            if (device.vendorId != FTDI_VENDOR_ID) {
                lastStatus = "Perangkat bukan FTDI (VID 0x${device.vendorId.toString(16)})"
                return@withContext false
            }
            if (!usbManager.hasPermission(device)) {
                lastStatus = "Izin USB belum diberikan"
                return@withContext false
            }
            connection = usbManager.openDevice(device)
            val usbConnection = connection
            if (usbConnection == null) {
                lastStatus = "USB openDevice gagal"
                return@withContext false
            }
            val serial = UsbSerialDevice.createUsbSerialDevice(device, usbConnection)
            if (serial == null || !serial.open()) {
                lastStatus = "Driver serial tidak dapat membuka FTDI"
                usbConnection.close()
                connection = null
                return@withContext false
            }
            serialDevice = serial
            serial.setBaudRate(10400)
            serial.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serial.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serial.setParity(UsbSerialInterface.PARITY_NONE)
            serial.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            // Do not force RTS/DTR: adapter circuits differ and those lines may
            // control external transistors on some DIY interfaces.
            delay(80)
            val stale = ByteArray(256)
            serial.syncRead(stale, 30)
            isConnected = true // transport only; no ECU handshake has happened yet
            connectedMotorName = if (mode == "Manual") motorType else "Auto - menunggu identifikasi ECU"
            lastStatus = "USB READY; port serial terbuka pada 10400 8N1. ECU belum teridentifikasi."
            true
        } catch (e: Exception) {
            Log.e(TAG, "USB serial connect failed", e)
            lastStatus = "USB error: ${e.message ?: e.javaClass.simpleName}"
            disconnect()
            false
        }
    }

    /** Send a complete KWP frame supplied by caller and return only actual RX bytes. */
    suspend fun sendRawFrame(frame: ByteArray, timeoutMs: Int = 700): ByteArray? = withContext(Dispatchers.IO) {
        val device = serialDevice ?: run { lastStatus = "USB belum terbuka"; return@withContext null }
        try {
            lastTxHex = frame.toHex()
            val stale = ByteArray(256)
            device.syncRead(stale, 20)
            device.syncWrite(frame, 500)
            delay(30)
            val buffer = ByteArray(512)
            val n = device.syncRead(buffer, timeoutMs)
            val response = if (n > 0) buffer.copyOfRange(0, n) else ByteArray(0)
            lastRxHex = if (response.isEmpty()) "(tidak ada respons)" else response.toHex()
            lastStatus = if (response.isEmpty()) "TX terkirim; tidak ada byte RX" else "Menerima ${response.size} byte; belum divalidasi sebagai respons ECU"
            response.takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            lastStatus = "Kesalahan TX/RX: ${e.message ?: e.javaClass.simpleName}"
            Log.e(TAG, "TX/RX failed", e)
            null
        }
    }

    /** Candidate 3-byte-header request shown in the supplied reference image. */
    suspend fun requestEcuIdentification(): ByteArray? = withContext(Dispatchers.IO) {
        // 82 11 F1 1A 90 + additive checksum 2E.
        // This is only a candidate probe. It is NOT a substitute for the ECU-specific
        // KWP fast/5-baud initialization sequence, which is not yet verified.
        sendRawFrame(byteArrayOf(0x82.toByte(), 0x11, 0xF1.toByte(), 0x1A, 0x90.toByte(), 0x2E))
    }

    suspend fun requestLiveData(): Map<String, String> = withContext(Dispatchers.IO) {
        // Never fabricate sensor values. No K59A-A11 PID map has been validated yet.
        mapOf(
            "rpm" to "--", "tps" to "--", "temp" to "--", "voltage" to "--",
            "map" to "--", "iat" to "--", "iacv" to "--", "injector" to "--",
            "speed" to "--", "afr" to "--", "load" to "--"
        )
    }

    fun disconnect() {
        try { serialDevice?.close() } catch (_: Exception) {}
        try { connection?.close() } catch (_: Exception) {}
        serialDevice = null
        connection = null
        isConnected = false
        connectedMotorName = "Tidak terhubung"
        lastStatus = "USB terputus"
    }

    private fun ByteArray.toHex(): String = joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    companion object {
        const val FTDI_VENDOR_ID = 0x0403
        private const val TAG = "HondaKLineManager"
    }
}
