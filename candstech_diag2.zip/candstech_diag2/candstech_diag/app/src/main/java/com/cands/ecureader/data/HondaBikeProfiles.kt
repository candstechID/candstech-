package com.cands.ecureader.data

enum class EngineTemperatureType(val displayName: String) {
    ECT("ECT – Coolant"),
    EOT("EOT – Oli"),
    UNKNOWN("Suhu Mesin (sensor belum diketahui)")
}

data class BikeModel(
    val id: String,
    val name: String,
    val category: String,
    val engineCc: Int,
    val ecuType: String,
    val rpmDivider: Float = 4.0f,
    val modelCode: String = " ",
    val yearRange: String = " ",
    val variants: List<String> = emptyList(),
    val codeParts: List<String> = emptyList(),
    val ecmIds: List<String> = emptyList(),
    val supportedTables: List<Int> = emptyList(),
    val candidateTables: List<Int> = emptyList(),
    val sensorProfileId: String = "honda_common_kline",
    val referenceStatus: String = "PART_NUMBER_REFERENCE_ONLY",
    val temperatureType: EngineTemperatureType = EngineTemperatureType.UNKNOWN
) {
    fun matchesCodePart(input: String): Boolean {
        val normalized = input.filter { it.isLetterOrDigit() }.uppercase()
        return normalized.isNotEmpty() && codeParts.any { part ->
            part.filter { it.isLetterOrDigit() }.uppercase() == normalized
        }
    }
}

object HondaBikeProfiles {

    val liveTableScanOrder: List<Int> = listOf(
        0x10, 0x11, 0x13, 0x17, 0x20, 0x21, 0xD1
    )

    val sensorProfiles: List<SensorProfile> = listOf(
        SensorProfile(
            id = "honda_common_kline",
            description = "Layout dasar Honda K-Line; validasi tetap diperlukan per ECU",
            parameters = listOf(
                SensorParameter(
                    "engine_temperature_voltage",
                    "Engine Temperature Sensor Voltage",
                    listOf(0x10, 0x11, 0x13),
                    8,
                    "V",
                    "raw * 5.0 / 256.0",
                    true
                ),
                SensorParameter(
                    "engine_temperature",
                    "Engine Temperature",
                    listOf(0x10, 0x11, 0x13),
                    9,
                    "°C",
                    "raw - 40",
                    true
                ),
                SensorParameter(
                    "iat_voltage",
                    "IAT Voltage",
                    listOf(0x10, 0x11, 0x13),
                    10,
                    "V",
                    "raw * 5.0 / 256.0",
                    true
                ),
                SensorParameter(
                    "iat_temperature",
                    "IAT Temperature",
                    listOf(0x10, 0x11, 0x13),
                    11,
                    "°C",
                    "raw - 40; raw 0x00/0xFF = N/A",
                    true
                )
            ),
            note = "Offset byte di atas adalah layout umum tabel 0x10/0x11/0x13. " +
                "Jenis indikator EOT atau ECT dipilih dari profil motor. " +
                "Jangan menerapkan offset ini ke tabel lain tanpa validasi respons ECU."
        )
    )

    val list: List<BikeModel> = listOf(
        BikeModel(
            "auto",
            "Auto Detect (Otomatis)",
            "System",
            0,
            "Keihin KWP2000 (70ms)",
            4.0f,
            referenceStatus = "SYSTEM_PROFILE"
        ),
        BikeModel(
            "beat_fi_k25a",
            "Honda BeAT FI K25A",
            "Matic",
            110,
            "PGM-FI / ECU 38770-K25-901",
            4.0f,
            modelCode = "K25A",
            yearRange = "2012–2014",
            variants = listOf("BeAT FI", "BeAT FI CBS"),
            codeParts = listOf("38770K25901"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "scoopy_fi_k16g",
            "Honda Scoopy FI K16G",
            "Matic",
            110,
            "PGM-FI / ECU 38770-K25-901",
            4.0f,
            modelCode = "K16G",
            yearRange = "2013–2015",
            variants = listOf("Scoopy FI"),
            codeParts = listOf("38770K25901"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "scoopy_esp_k16r",
            "Honda Scoopy eSP K16R",
            "Matic",
            110,
            "PGM-FI / ECU 38770-K25-901",
            4.0f,
            modelCode = "K16R",
            yearRange = "2015–2017",
            variants = listOf("Scoopy eSP"),
            codeParts = listOf("38770K25901"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "beat_k81_non_iss",
            "Honda BeAT Sporty / Street K81 Non-ISS",
            "Matic",
            110,
            "PGM-FI / Keihin K81",
            4.0f,
            modelCode = "K81",
            yearRange = "2016–2019",
            variants = listOf("CW", "CBS", "Street", "Non-ISS"),
            codeParts = listOf("30400K81N02", "30400K81N52"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "beat_k81_iss",
            "Honda BeAT Sporty / Street K81 CBS-ISS",
            "Matic",
            110,
            "PGM-FI / Keihin K81",
            4.0f,
            modelCode = "K81",
            yearRange = "2016–2019",
            variants = listOf("CBS-ISS", "ISS"),
            codeParts = listOf("30400K81N12", "30400K81N62"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "beat_deluxe",
            "Honda BeAT Deluxe / Genio (profil lama)",
            "Matic",
            110,
            "PGM-FI Honda (identitas ECU perlu dipastikan)",
            4.0f,
            modelCode = "K0J / K1A (perlu pemilihan varian)",
            referenceStatus = "LEGACY_AMBIGUOUS_PROFILE",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "genio_k0j_cbs",
            "Honda Genio K0J CBS",
            "Matic",
            110,
            "PGM-FI / Keihin K0J",
            4.0f,
            modelCode = "K0J",
            yearRange = "2019–2022",
            variants = listOf("CBS"),
            codeParts = listOf("30400K0JN01", "30400K0JN61"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "genio_k0j_iss",
            "Honda Genio K0J CBS-ISS",
            "Matic",
            110,
            "PGM-FI / Keihin K0J",
            4.0f,
            modelCode = "K0J",
            yearRange = "2019–2022",
            variants = listOf("CBS-ISS"),
            codeParts = listOf("30400K0JN11", "30400K0JN71"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.EOT
        ),
        BikeModel(
            "vario_125_esp",
            "Honda Vario 125 eSP (2015+)",
            "Matic",
            125,
            "Keihin K35 / K60",
            4.0f,
            modelCode = "K35 / K60",
            referenceStatus = "MODEL_REFERENCE_ONLY",
            temperatureType = EngineTemperatureType.ECT
        ),
        BikeModel(
            "vario_150",
            "Honda Vario 150 eSP (LED / Keyless)",
            "Matic",
            150,
            "Keihin K59 / K59J",
            4.0f,
            modelCode = "K59",
            referenceStatus = "MODEL_REFERENCE_ONLY",
            temperatureType = EngineTemperatureType.ECT
        ),
        BikeModel(
            "pcx_160",
            "Honda PCX 160 K1Z",
            "Matic",
            160,
            "PGM-FI / Keihin K1Z",
            4.0f,
            modelCode = "K1Z",
            yearRange = "2021–2024 (referensi katalog)",
            variants = listOf("CBS"),
            codeParts = listOf("30400K1ZN21"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.ECT
        ),
        BikeModel(
            "vario_160",
            "Honda Vario 160 K2S",
            "Matic",
            160,
            "PGM-FI / Keihin K2S",
            4.0f,
            modelCode = "K2S",
            yearRange = "2022+",
            codeParts = listOf("30400K2SN02"),
            referenceStatus = "PART_NUMBER_VERIFIED",
            temperatureType = EngineTemperatureType.ECT
        ),
        BikeModel(
            "cb150r",
            "Honda CB150R Streetfire",
            "Sport",
            150,
            "Keihin K15 / K56",
            4.0f,
            modelCode = "K15 / K56",
            referenceStatus = "MODEL_REFERENCE_ONLY",
            temperatureType = EngineTemperatureType.ECT
        ),
        BikeModel(
            "cbr_150r",
            "Honda CBR 150R",
            "Sport",
            150,
            "Keihin K75G / K45",
            4.0f,
            modelCode = "K45 / K75G",
            referenceStatus = "MODEL_REFERENCE_ONLY",
            temperatureType = EngineTemperatureType.ECT
        )
    )

    fun findByCodePart(codePart: String): List<BikeModel> =
        list.filter { it.id != "auto" && it.matchesCodePart(codePart) }

    fun findById(id: String): BikeModel? =
        list.firstOrNull { it.id == id }

    fun findUniqueByCodePart(codePart: String): BikeModel? =
        findByCodePart(codePart).singleOrNull()
}

data class SensorProfile(
    val id: String,
    val description: String,
    val parameters: List<SensorParameter>,
    val note: String = ""
)

data class SensorParameter(
    val id: String,
    val name: String,
    val tableIds: List<Int>,
    val byteOffset: Int,
    val unit: String,
    val formula: String,
    val verifiedInProjectReference: Boolean = false
)