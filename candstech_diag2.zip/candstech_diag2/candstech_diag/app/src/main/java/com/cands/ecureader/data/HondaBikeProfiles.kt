package com.cands.ecureader.data

// Data class motor - diperluas dengan field ECU
data class BikeModel(
    val id: String,
    val name: String,
    val category: String,
    val engineCc: Int,
    val ecuType: String,
    val rpmDivider: Float = 4.0f,
    val partCode: String = "",
    val ecmId: String = "",
    val vendor: String = "Unknown",
    val romSizeKb: Int = 0
)

object HondaBikeProfiles {
    
    val list = listOf(
        // ============================================================
        // MOTOR POPULER INDONESIA - KEIHIN
        // ============================================================
        BikeModel("scoopy_i_2021", "Scoopy-i (2021-2024)", "Matic", 110, "Keihin K2F", 4.0f, "38770-K2F-N01", "0104080F01", "Keihin", 256),
        BikeModel("scoopy_i_2021_sh", "Scoopy-i (2021-2024) Shindengen", "Matic", 110, "Shindengen K2F", 4.0f, "30400-K2F-N11", "0104130F01", "Shindengen", 256),
        BikeModel("cb150r_streetfire", "CB150R Streetfire", "Sport", 150, "Keihin K15", 4.0f, "38770-K15-903", "01011B0F02", "Keihin", 64),
        BikeModel("cb150r_streetfire_128", "CB150R Streetfire (128KB)", "Sport", 150, "Keihin K15", 4.0f, "38770-K15-921", "0101DA0F01", "Keihin", 128),
        BikeModel("cb150r_streetfire_3", "CB150R Streetfire v3", "Sport", 150, "Keihin K15", 4.0f, "38770-K15-888", "0103130F11", "Keihin", 128),
        BikeModel("cb150r_neo", "CB150R Neo Sports Cafe", "Sport", 150, "Keihin K98", 4.0f, "38770-K98-E02", "0102A10101", "Keihin", 128),
        BikeModel("cbr150r_led", "CBR150R LED (2016-2024)", "Sport", 150, "Keihin K45", 4.0f, "38770-K45-N01", "0101B10F01", "Keihin", 128),
        BikeModel("cbr150r_led_v2", "CBR150R LED v2", "Sport", 150, "Keihin K45", 4.0f, "38770-K45-N42", "0102040F01", "Keihin", 128),
        BikeModel("cbr150r_indo", "CBR150R Indonesia", "Sport", 150, "Keihin K94", 4.0f, "38770-K94-T02", "0102A00D01", "Keihin", 128),
        BikeModel("cbr150r_led_v3", "CBR150R LED v3", "Sport", 150, "Keihin K45", 4.0f, "38770-K45-NA1", "0103250F01", "Keihin", 128),
        BikeModel("sonic150r", "Sonic 150R / Winner 150 / Supra GTR 150", "Sport", 150, "Keihin K56", 4.0f, "38770-K56-N11", "0101CA0F01", "Keihin", 128),
        BikeModel("sonic150r_v2", "Sonic 150R v2", "Sport", 150, "Keihin K56", 4.0f, "38770-K56-NJ1", "0103920F01", "Keihin", 128),
        BikeModel("sonic150r_v3", "Sonic 150R v3", "Sport", 150, "Keihin K56", 4.0f, "38770-K56-M01", "0101CD1801", "Keihin", 128),
        BikeModel("msx125", "MSX 125 / Grom 125 (2013-2020)", "Mini", 125, "Keihin K26", 4.0f, "38770-K26-911", "0101350501", "Keihin", 64),
        BikeModel("msx125_128", "MSX 125 / Grom 125 (128KB)", "Mini", 125, "Keihin K26", 4.0f, "38770-K26-B13", "0102130501", "Keihin", 128),
        BikeModel("wave125i", "Wave 125i (2012-2017)", "Bebek", 125, "Keihin KYZ", 4.0f, "38770-KYZ-T03", "0100FB0E02", "Keihin", 64),
        BikeModel("wave125i_led", "Wave 125i LED (2018-2022)", "Bebek", 125, "Keihin K73", 4.0f, "38770-K73-V42", "0103141101", "Keihin", 128),
        BikeModel("wave110i", "Wave 110i (2019-2020)", "Bebek", 110, "Keihin K03", 4.0f, "38770-K03-N32", "0101870F02", "Keihin", 128),
        BikeModel("wave110i_2020", "Wave 110i / Wave 125i (2020-2022)", "Bebek", 110, "Keihin K58", 4.0f, "38770-K58-N41", "0102E40F01", "Keihin", 128),
        BikeModel("wave110i_old", "Wave 110i (2009-2018)", "Bebek", 110, "Keihin KWW", 4.0f, "38770-KWW-641", "0100CE0D01", "Keihin", 64),
        BikeModel("monkey125", "Monkey 125 (2018-2020)", "Mini", 125, "Keihin K0F", 4.0f, "38770-K0F-A01", "0102CA0501", "Keihin", 128),
        BikeModel("super_cub_110", "Super Cub 110 Pro", "Bebek", 110, "Keihin K0G", 4.0f, "38770-K0G-962", "01030E0501", "Keihin", 128),
        BikeModel("dream_cub_110", "Dream Super Cub 110 (2013-2017)", "Bebek", 110, "Keihin KZV", 4.0f, "38770-KZV-A61", "0101BA0D01", "Keihin", 128),
        BikeModel("spacy_i", "Spacy-i / Zoomer-X (2012-2014)", "Matic", 110, "Keihin KZL", 4.0f, "38770-KZL-E12", "0101021101", "Keihin", 64),
        BikeModel("crf250l", "CRF250L / CRF250M / CRF250 Rally", "Trail", 250, "Keihin KZZ", 4.0f, "38770-KZZ-902", "01011A0D01", "Keihin", 1024),
        BikeModel("crf300l", "CRF300L / CRF300 Rally (2021-2024)", "Trail", 300, "Keihin K1T", 4.0f, "38770-K1T-T01", "0104070D01", "Keihin", 128),
        BikeModel("cbr300r", "CBR300R / CB300F (2014-2020)", "Sport", 300, "Keihin K33", 4.0f, "38770-K33-N03", "0101790F02", "Keihin", 1024),
        BikeModel("cb300r", "CB300R Neo Sports Cafe (2018-2024)", "Sport", 300, "Keihin K0A", 4.0f, "38770-K0A-R11", "0102A22101", "Keihin", 128),
        BikeModel("cbr650f", "CBR650F / CB650F (2014-2018)", "Sport", 650, "Keihin MJE", 4.0f, "38770-MJE-D41", "01019C0101", "Keihin", 256),
        BikeModel("cbr650r", "CBR650R (2019-2024)", "Sport", 650, "Keihin MKN", 4.0f, "38770-MKN-D51", "0103050101", "Keihin", 512),
        BikeModel("cbr500r", "CBR500R / CB500F / CB500X (2016-2018)", "Sport", 500, "Keihin MJW", 4.0f, "38770-MJW-D51", "0101F20101", "Keihin", 256),
        BikeModel("cbr1000rr", "CBR1000RR Fireblade (2004-2007)", "Sport", 1000, "Keihin MEL", 4.0f, "38770-MEL-613", "01000F0202", "Keihin", 256),
        BikeModel("cbr1000rr_2008", "CBR1000RR Fireblade (2008-2011)", "Sport", 1000, "Keihin MFL", 4.0f, "38770-MFL-644", "01005E0103", "Keihin", 256),
        BikeModel("cbr1000rr_2012", "CBR1000RR Fireblade (2012-2016)", "Sport", 1000, "Keihin MGP", 4.0f, "38770-MGP-L01", "0100F30501", "Keihin", 256),
        BikeModel("cbr1000rr_2017", "CBR1000RR SP / Fireblade (2017-2019)", "Sport", 1000, "Keihin MKF", 4.0f, "38770-MKF-A22", "0102480401", "Keihin", 512),
        BikeModel("rebel300", "Rebel 300 (2017-2024)", "Cruiser", 300, "Keihin K87", 4.0f, "38770-K87-T52", "01025A0D01", "Keihin", 1024),
        BikeModel("forza300", "Forza 300 (2013-2017)", "Maxi", 300, "Keihin K04", 4.0f, "38770-K04-901", "01016A0101", "Keihin", 512),
        BikeModel("forza350", "Forza 350 / ADV 350 (2020-2022)", "Maxi", 350, "Keihin K1B", 4.0f, "38770-K1B-T01", "0103E80D01", "Keihin", 512),
        BikeModel("xadv750", "X-ADV 750 / Forza 750 / NC750X", "Maxi", 750, "Keihin MKH", 4.0f, "38770-MKH-D01", "08024C0101", "Keihin", 512),
        BikeModel("africa_twin", "Africa Twin CRF1000L / CRF1100L", "Adventure", 1000, "Keihin MKK", 4.0f, "38770-MKK-D02", "0102A40101", "Keihin", 512),

        // ============================================================
        // MOTOR POPULER INDONESIA - SHINDENGEN
        // ============================================================
        BikeModel("pcx160", "PCX 160 e:HEV / ABS (2021-2024)", "Matic", 160, "Shindengen K1ZF", 4.0f, "30400-K1ZF-T01", "0103D00D01", "Shindengen", 512),
        BikeModel("pcx160_abs", "PCX 160 ABS (2021-2024)", "Matic", 160, "Shindengen K1ZF", 4.0f, "30400-K1ZF-T11", "0103CF0D01", "Shindengen", 512),
        BikeModel("pcx160_noabs", "PCX 160 NO ABS (2021-2024)", "Matic", 160, "Shindengen K1ZP", 4.0f, "30400-K1ZP-T51", "0105050D01", "Shindengen", 512),
        BikeModel("pcx160_abs_v2", "PCX 160 ABS v2 (2021-2024)", "Matic", 160, "Shindengen K1ZP", 4.0f, "30400-K1ZP-T71", "0105040D01", "Shindengen", 512),
        BikeModel("lead125", "Lead 125 4V (2022-2024)", "Matic", 125, "Shindengen K2TA", 4.0f, "30400-K2TA-T02", "0104780D01", "Shindengen", 512),
        BikeModel("adv150", "ADV 150 / ADV 160 (2019-2024)", "Adventure", 150, "Shindengen K0WF", 4.0f, "30400-K0WF-T01", "01037C0D01", "Shindengen", 384),
        BikeModel("adv160", "ADV 160 (2019-2024)", "Adventure", 160, "Shindengen K0WM", 4.0f, "30400-K0WM-TA1", "01048E0D01", "Shindengen", 512),
        BikeModel("click150", "Click 150i (2018-2022)", "Matic", 150, "Shindengen K59K", 4.0f, "30400-K59K-T11", "0103070D01", "Shindengen", 384),
        BikeModel("click125_2023", "Click 125i (2023-2024)", "Matic", 125, "Shindengen K2VH", 4.0f, "30400-K2VH-T11", "0104DC0D01", "Shindengen", 384),
        BikeModel("click125_led", "Click 125i LED (2018-2022)", "Matic", 125, "Shindengen K60F", 4.0f, "30400-K60F-T01", "0101D00D01", "Shindengen", 256),
        BikeModel("click125_led_v2", "Click 125i LED v2 (2018-2022)", "Matic", 125, "Shindengen K60S", 4.0f, "30400-K60S-T71", "01030A0D01", "Shindengen", 384),
        BikeModel("giorno125", "Giorno+ 125 (2023-2024)", "Matic", 125, "Shindengen K3MF", 4.0f, "30400-K3MF-T01", "01052A0D01", "Shindengen", 512),
        BikeModel("pcx150", "PCX 150 (2014-2017)", "Matic", 150, "Shindengen K36F", 4.0f, "30400-K36F-T01", "0101990D01", "Shindengen", 256),
        BikeModel("pcx150_2016", "PCX 150 (2016-2017)", "Matic", 150, "Shindengen K36S", 4.0f, "30400-K36S-T31", "0102180D01", "Shindengen", 384),
        BikeModel("pcx150_smartkey", "PCX 150 Smart Key (2018-2020)", "Matic", 150, "Shindengen K97F", 4.0f, "30400-K97F-T", "010102990D01", "Shindengen", 384),
        BikeModel("zoomer_x", "Zoomer-X (2015-2020)", "Matic", 110, "Shindengen K20J", 4.0f, "30400-K20J-T21", "0101FF0D01", "Shindengen", 256)
    )

    // ============================================================
    // FUNGSI LOOKUP / SEARCH
    // ============================================================
    
    fun lookupByEcmId(ecmId: String): BikeModel? {
        if (ecmId.isEmpty()) return null
        val clean = ecmId.replace("-", "").uppercase()
        return list.firstOrNull { bike ->
            bike.ecmId.replace("-", "").uppercase().contains(clean) ||
            clean.contains(bike.ecmId.replace("-", "").uppercase())
        }
    }

    fun lookupByPartCode(partCode: String): BikeModel? {
        if (partCode.isEmpty()) return null
        val clean = partCode.replace("-", "").uppercase()
        return list.firstOrNull { bike ->
            bike.partCode.replace("-", "").uppercase().contains(clean) ||
            clean.contains(bike.partCode.replace("-", "").uppercase())
        }
    }

    fun search(query: String): List<BikeModel> {
        if (query.isEmpty()) return list
        val q = query.lowercase()
        return list.filter { bike ->
            bike.name.lowercase().contains(q) ||
            bike.partCode.lowercase().contains(q) ||
            bike.ecmId.lowercase().contains(q) ||
            bike.ecuType.lowercase().contains(q)
        }
    }

    // Auto detect dari ECM ID yang dibaca dari ECU
    fun autoDetect(ecmId: String): BikeModel? {
        return lookupByEcmId(ecmId)
    }
}