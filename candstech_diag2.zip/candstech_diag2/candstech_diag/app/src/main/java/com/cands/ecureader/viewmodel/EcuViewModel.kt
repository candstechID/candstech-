package com.cands.ecureader.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {
    var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null

    var isConnected by mutableStateOf(false)
    var isKontakOn by mutableStateOf(false)
    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)
    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    var ectVolt by mutableFloatStateOf(0.0f)
    var iat by mutableIntStateOf(0)
    var iatVolt by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var mapVolt by mutableFloatStateOf(0.0f)
    var batteryVolt by mutableFloatStateOf(0.0f)
    var afr by mutableFloatStateOf(0.0f)
    var o2Volt by mutableFloatStateOf(0.0f)
    var engineLoad by mutableFloatStateOf(0.0f)
    var iacv by mutableIntStateOf(0)
    var injectorMs by mutableFloatStateOf(0.0f)
    var gearStatus by mutableStateOf("Unknown")
    var engineRunning by mutableStateOf(false)

    var isScanningDtc by mutableStateOf(false)
    var dtcList by mutableStateOf<List<String>>(emptyList())
    var dtcMessage by mutableStateOf("")

    var sensorDetailList by mutableStateOf<List<SensorItem>>(emptyList())
    var showSensorDialog by mutableStateOf(false)

    var uiLogs by mutableStateOf("")
        private set

    fun addLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val currentList = uiLogs.split("\n").filter { it.isNotEmpty() }.toMutableList()
        currentList.add("[$time] $msg")
        uiLogs = currentList.takeLast(50).joinToString("\n")
    }

    private var lastDataTimestamp = System.currentTimeMillis()

    fun selectBike(bike: BikeModel) { selectedBike = bike }
    fun resetTopEcu() { topSpeedEcu = 0 }
    fun resetTopGps() { topSpeedGps = 0 }

    fun requestFullSensorData() {
        val manager = kLineManager ?: return
        if (!isConnected) return
        showSensorDialog = true
        sensorDetailList = emptyList()
        isScanningDtc = true
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_STATUS)
            delay(500)
            manager.pollEngineData()
            isScanningDtc = false
        }
    }

    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        isConnected = true
        isKontakOn = true
        lastDataTimestamp = System.currentTimeMillis()
        addLog("Listener ECU diinisialisasi.")
        manager.onLog = { msg -> addLog(msg) }

        manager.onDataReceived = { data ->
            viewModelScope.launch(Dispatchers.Main) {
                isKontakOn = true
                lastDataTimestamp = System.currentTimeMillis()
                rpm = data.rpm
                tpsDegrees = data.tpsDeg
                tpsVolt = data.tpsVolt
                ect = data.ect
                ectVolt = data.ectVolt
                iat = data.iat
                iatVolt = data.iatVolt
                mapKpa = data.mapKpa
                mapVolt = data.mapVolt
                batteryVolt = data.battery
                afr = data.afr
                o2Volt = data.o2Volt
                engineLoad = data.engineLoad
                iacv = data.iacv
                injectorMs = data.injectorMs
                speedEcu = data.speedKmh
                if (speedEcu > topSpeedEcu) topSpeedEcu = speedEcu
            }
        }

        manager.onSensorDetailReceived = { items ->
            viewModelScope.launch(Dispatchers.Main) {
                sensorDetailList = sensorDetailList + items
            }
        }

        manager.onDtcReceived = { dtcs ->
            viewModelScope.launch(Dispatchers.Main) {
                dtcList = dtcs
                dtcMessage = if (dtcs.isEmpty()) "Tidak Ada DTC Tersimpan" else "${dtcs.size} Kode DTC Terdeteksi!"
            }
        }
    }

    fun scanDtc() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Memindai DTC..."
        addLog("Scan DTC...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_READ_DTC)
            delay(1000)
            manager.pollEngineData()
            isScanningDtc = false
        }
    }

    fun clearDtc() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Menghapus DTC..."
        addLog("Clear DTC...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_CLEAR_DTC)
            delay(500)
            withContext(Dispatchers.Main) {
                dtcList = emptyList()
                dtcMessage = "DTC Berhasil Dihapus!"
            }
            delay(1000)
            isScanningDtc = false
        }
    }

    fun resetTp() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Melakukan Reset TP..."
        addLog("Reset TP...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_RESET_TP)
            delay(500)
            withContext(Dispatchers.Main) {
                dtcMessage = "Reset TP Berhasil Dikirim!"
            }
            delay(1000)
            isScanningDtc = false
        }
    }

    fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch(Dispatchers.IO) {
            var keepAliveCounter = 0
            while (isActive) {
                if (isConnected && System.currentTimeMillis() - lastDataTimestamp > 2500) {
                    isKontakOn = false
                }
                if (isConnected && !isScanningDtc) {
                    val manager = kLineManager
                    if (manager != null) {
                        manager.sendCommand(manager.CMD_LIVE_DATA)
                        delay(80)
                        manager.pollEngineData()
                        keepAliveCounter++
                        if (keepAliveCounter >= 10) {
                            manager.sendCommand(manager.CMD_INIT_KWP)
                            keepAliveCounter = 0
                        }
                    } else {
                        break
                    }
                }
                delay(150)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        isConnected = false
        isKontakOn = false
    }

    fun updateGpsSpeed(speed: Float) {
        val kmh = (speed * 3.6f).toInt()
        speedGps = kmh
        if (kmh > topSpeedGps) topSpeedGps = kmh
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
        kLineManager?.closePort()
        kLineManager = null
    }
}