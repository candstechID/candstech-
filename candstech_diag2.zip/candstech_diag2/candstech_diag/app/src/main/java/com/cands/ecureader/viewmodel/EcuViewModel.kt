package com.cands.ecureader.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cands.ecureader.data.BikeModel
import com.cands.ecureader.data.HondaBikeProfiles
import com.cands.ecureader.data.HondaKLineManager
import com.cands.ecureader.data.SensorItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EcuViewModel(application: Application) : AndroidViewModel(application) {

    var kLineManager: HondaKLineManager? = null
    private var pollJob: Job? = null

    var isConnected by mutableStateOf(false)
    var isKontakOn by mutableStateOf(false)
    var selectedBike by mutableStateOf<BikeModel>(HondaBikeProfiles.list[0])

    // Speed
    var speedEcu by mutableIntStateOf(0)
    var speedGps by mutableIntStateOf(0)
    var topSpeedEcu by mutableIntStateOf(0)
    var topSpeedGps by mutableIntStateOf(0)

    // Sensor Data
    var rpm by mutableIntStateOf(0)
    var tpsDegrees by mutableFloatStateOf(0.0f)
    var tpsVolt by mutableFloatStateOf(0.0f)
    var ect by mutableIntStateOf(0)
    var ectVolt by mutableFloatStateOf(0.0f)
    var iat by mutableIntStateOf(0)
    var iatVolt by mutableFloatStateOf(0.0f)
    var mapKpa by mutableIntStateOf(0)
    var mapVolt by mutableFloatStateOf(0.0f)
    var batteryVolt by mutableFloatStateOf(0.0f)
    var afr by mutableFloatStateOf(0.0f)
    var o2Volt by mutableFloatStateOf(0.0f)
    var engineLoad by mutableFloatStateOf(0.0f)
    var iacv by mutableIntStateOf(0)
    var injectorMs by mutableFloatStateOf(0.0f)
    var ignitionTiming by mutableFloatStateOf(0.0f)
    var eot by mutableIntStateOf(0)
    var gear by mutableIntStateOf(-1)
    var isNeutral by mutableStateOf(false)

    // Diagnostik
    var isScanningDtc by mutableStateOf(false)
    var dtcList by mutableStateOf<List<String>>(emptyList())
    var dtcMessage by mutableStateOf("")

    // Sensor Detail Dialog
    var sensorDetailList by mutableStateOf<List<SensorItem>>(emptyList())
    var showSensorDialog by mutableStateOf(false)

    // Auto Detect
    var detectedBike by mutableStateOf<BikeModel?>(null)
        private set

    // Debug Log
    var uiLogs by mutableStateOf("")
        private set

    fun addLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val currentList = uiLogs.split("\n").filter { it.isNotEmpty() }.toMutableList()
        currentList.add("[$time] $msg")
        uiLogs = currentList.takeLast(50).joinToString("\n")
    }

    private var lastDataTimestamp = System.currentTimeMillis()

    fun selectBike(bike: BikeModel) {
        selectedBike = bike
    }

    fun resetTopEcu() {
        topSpeedEcu = 0
    }

    fun resetTopGps() {
        topSpeedGps = 0
    }

    // ============================================================
    // AUTO DETECT ECM ID
    // ============================================================
    fun onEcmIdDetected(ecmId: String) {
        addLog("ECM ID diterima: $ecmId")
        val bike = HondaBikeProfiles.autoDetect(ecmId)
        if (bike != null) {
            detectedBike = bike
            selectedBike = bike
            addLog("✅ Auto Detect: ${bike.name} (${bike.vendor})")
        } else {
            addLog("⚠️ ECM ID tidak ada di database")
        }
    }

    fun requestEcmId() {
        val manager = kLineManager ?: return
        if (!isConnected) return
        addLog("Meminta ECM ID...")
        manager.requestEcmId()
    }

    // ============================================================
    // REQUEST FULL SENSOR DATA (untuk dialog)
    // ============================================================
    fun requestFullSensorData() {
        val manager = kLineManager ?: return
        if (!isConnected) return
        showSensorDialog = true
        sensorDetailList = emptyList()
        isScanningDtc = true
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_T11)
            delay(300)
            manager.pollEngineData()
            manager.sendCommand(manager.CMD_T13)
            delay(300)
            manager.pollEngineData()
            manager.sendCommand(manager.CMD_T20)
            delay(300)
            manager.pollEngineData()
            manager.sendCommand(manager.CMD_TD1)
            delay(300)
            manager.pollEngineData()
            isScanningDtc = false
        }
    }

    // ============================================================
    // INIT LISTENER
    // ============================================================
    fun initKLineListener(manager: HondaKLineManager) {
        kLineManager = manager
        isConnected = true
        isKontakOn = true
        lastDataTimestamp = System.currentTimeMillis()
        addLog("Listener ECU diinisialisasi.")
        manager.onLog = { msg -> addLog(msg) }

        manager.onDataReceived = { data ->
            viewModelScope.launch(Dispatchers.Main) {
                isKontakOn = true
                lastDataTimestamp = System.currentTimeMillis()
                rpm = data.rpm
                tpsDegrees = data.tpsDeg
                tpsVolt = data.tpsVolt
                ect = data.ect
                ectVolt = data.ectVolt
                iat = data.iat
                iatVolt = data.iatVolt
                mapKpa = data.mapKpa
                mapVolt = data.mapVolt
                batteryVolt = data.battery
                afr = data.afr
                o2Volt = data.o2Volt
                engineLoad = data.engineLoad
                iacv = data.iacv
                injectorMs = data.injectorMs
                ignitionTiming = data.ignitionTiming
                eot = data.eot
                gear = data.gear
                isNeutral = data.isNeutral
                speedEcu = data.speedKmh
                if (speedEcu > topSpeedEcu) topSpeedEcu = speedEcu
            }
        }

        manager.onSensorDetailReceived = { items ->
            viewModelScope.launch(Dispatchers.Main) {
                sensorDetailList = sensorDetailList + items
            }
        }

        manager.onDtcReceived = { dtcs ->
            viewModelScope.launch(Dispatchers.Main) {
                dtcList = dtcs
                dtcMessage = if (dtcs.isEmpty()) "Tidak Ada DTC Tersimpan" else "${dtcs.size} Kode DTC Terdeteksi!"
            }
        }

        manager.onEcmIdReceived = { ecmId ->
            viewModelScope.launch(Dispatchers.Main) {
                onEcmIdDetected(ecmId)
            }
        }
    }

    // ============================================================
    // DIAGNOSTIC FUNCTIONS
    // ============================================================
    fun scanDtc() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Memindai DTC..."
        addLog("Scan DTC...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_READ_DTC)
            delay(1000)
            manager.pollEngineData()
            isScanningDtc = false
        }
    }

    fun clearDtc() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Menghapus DTC..."
        addLog("Clear DTC...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_CLEAR_DTC)
            delay(500)
            withContext(Dispatchers.Main) {
                dtcList = emptyList()
                dtcMessage = "DTC Berhasil Dihapus!"
            }
            delay(1000)
            isScanningDtc = false
        }
    }

    fun resetTp() {
        if (!isConnected) return
        val manager = kLineManager ?: return
        isScanningDtc = true
        dtcMessage = "Melakukan Reset TP..."
        addLog("Reset TP...")
        viewModelScope.launch(Dispatchers.IO) {
            manager.sendCommand(manager.CMD_RESET_TP)
            delay(500)
            withContext(Dispatchers.Main) {
                dtcMessage = "Reset TP Berhasil Dikirim!"
            }
            delay(1000)
            isScanningDtc = false
        }
    }

    // ============================================================
    // POLLING (dengan auto-fallback stream → table)
    // ============================================================
    fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch(Dispatchers.IO) {
            var keepAliveCounter = 0
            var emptyStreamCount = 0

            while (isActive) {
                if (isConnected && System.currentTimeMillis() - lastDataTimestamp > 2500) {
                    isKontakOn = false
                }
                if (isConnected && !isScanningDtc) {
                    val manager = kLineManager
                    if (manager != null) {
                        // Kirim command sesuai mode
                        if (manager.pollMode == 0) {
                            manager.sendCommand(manager.CMD_LIVE_STREAM)
                        } else {
                            manager.sendCommand(manager.CMD_TABLE_10)
                        }
                        delay(80)
                        manager.pollEngineData()

                        // Auto-fallback: jika stream tidak dibalas 10x, ganti ke table 10
                        if (manager.pollMode == 0) {
                            emptyStreamCount++
                            if (emptyStreamCount >= 10) {
                                manager.pollMode = 1
                                addLog("⚠️ Stream tidak respons, fallback ke Table 10")
                            }
                        } else {
                            emptyStreamCount = 0
                        }

                        keepAliveCounter++
                        if (keepAliveCounter >= 10) {
                            manager.sendCommand(manager.CMD_INIT_KWP)
                            keepAliveCounter = 0
                        }
                    } else {
                        break
                    }
                }
                delay(150)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        isConnected = false
        isKontakOn = false
    }

    fun updateGpsSpeed(speed: Float) {
        val kmh = (speed * 3.6f).toInt()
        speedGps = kmh
        if (kmh > topSpeedGps) topSpeedGps = kmh
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
        kLineManager?.closePort()
        kLineManager = null
    }
}