package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float, val speedKmh: Int,
    val ignitionTiming: Float = 0f, val eot: Int = 0,
    val gear: Int = -1, val isNeutral: Boolean = false
)

data class SensorItem(
    val category: String, val name: String, val value: String, val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val TAG = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // ============================================================
    // COMMAND — SESUAI SKILL.md BAGIAN 7
    // Live Stream: 72 07 72 00 00 0D  (service 0x72, table 00 00)
    // ============================================================
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x07, 0x72, 0x00, 0x00, 0x0D)

    // Fallback table read (service 0x71) untuk ECU yang tidak support stream
    val CMD_TABLE_10 = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)
    val CMD_TABLE_17 = byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01)

    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()) // Tester/Keep Alive

    val CMD_T11 = byteArrayOf(0x72, 0x05, 0x71, 0x11, 0x07)
    val CMD_T13 = byteArrayOf(0x72, 0x05, 0x71, 0x13, 0x05)
    val CMD_T20 = byteArrayOf(0x72, 0x05, 0x71, 0x20, 0xF8.toByte())
    val CMD_TD1 = byteArrayOf(0x72, 0x05, 0x71, 0xD1.toByte(), 0x47)

    val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)
    val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    // Mode polling: 0 = stream 0x72, 1 = table 10, 2 = table 17
    var pollMode = 0

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) rxQueue.add(b)
        }
    }

    fun setupPort() {
        onLog?.invoke("Membuka Port (10400 Baud, 8N1)...")
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
        onLog?.invoke("Port berhasil dibuka.")
    }

    fun closePort() {
        onLog?.invoke("Port ditutup.")
        try { serialPort.close() } catch (_: Exception) {}
    }

    // Checksum two's complement: (0x100 - sum) & 0xFF  (SKILL.md bagian 2)
    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length) sum += data[i].toInt() and 0xFF
        return (0x100 - (sum and 0xFF)).toByte()
    }

    // ============================================================
    // HANDSHAKE — TIDAK DIUBAH (sesuai instruksi Anda)
    // ============================================================
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            serialPort.setBreak(true)
            delay(70)
            serialPort.setBreak(false)
            delay(120)
            serialPort.write(CMD_WAKEUP)
            delay(50)
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP)
            delay(100)
            rxQueue.clear() // Buang echo + wakeup byte (SKILL.md: half-duplex echo)
            return@withContext true
        } catch (e: Exception) {
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
        // Buang echo TX (SKILL.md: "consume and discard N bytes of echo")
        repeat(command.size) {
            if (rxQueue.isNotEmpty()) rxQueue.poll()
        }
    }

    fun pollEngineData() {
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) {
            rxQueue.poll()
        }
        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF
            if (expectedLength in 5..60) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) buffer[i] = rxQueue.poll()!!
                    val calcCs = calculateChecksum(buffer, expectedLength - 1)
                    val rxCs = buffer[expectedLength - 1]
                    if (calcCs == rxCs) {
                        parseHondaResponse(buffer)
                    } else {
                        onLog?.invoke("CS salah: calc=${String.format("%02X", calcCs.toInt() and 0xFF)} rx=${String.format("%02X", rxCs.toInt() and 0xFF)}")
                    }
                }
            } else {
                rxQueue.poll()
            }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data[2].toInt() and 0xFF
            val rawHex = data.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }

            // ============================================================
            // SERVICE 0x72 — LIVE STREAM (SKILL.md bagian 7)
            // Offset: RPM=5-6, TPS%=7, TPSV=8, EOT/ECT=9, MAP=10,
            //         IAT=11, BAT=12, INJ=13-14, IGN=15, O2/AFR=16, GEAR=17
            // ============================================================
            if (responseType == 0x72 && data.size >= 18) {
                onLog?.invoke("STREAM RAW: $rawHex")

                val rpm = ((data[5].toInt() and 0xFF) shl 8) or (data[6].toInt() and 0xFF)
                val tpsPct = (data[7].toInt() and 0xFF) * 100.0f / 255.0f
                val tpsVolt = (data[8].toInt() and 0xFF) * 5.0f / 255.0f
                val eot = (data[9].toInt() and 0xFF) - 40
                val mapKpa = data[10].toInt() and 0xFF
                val iat = (data[11].toInt() and 0xFF) - 40
                val battery = (data[12].toInt() and 0xFF) * 0.1f
                val injectorMs = (((data[13].toInt() and 0xFF) shl 8) or (data[14].toInt() and 0xFF)) / 1000.0f
                val ignition = ((data[15].toInt() and 0xFF) - 60) / 2.0f
                val o2Byte = data[16].toInt() and 0xFF
                val afr = 14.7f + (o2Byte - 128) * 0.03f
                val o2Volt = o2Byte * 0.02f
                val gearByte = data[17].toInt() and 0xFF
                val isNeutral = (gearByte and 0x01) != 0
                val gear = (gearByte shr 1) and 0x07

                val engineData = EngineData(
                    rpm = rpm, tpsDeg = tpsPct, tpsVolt = tpsVolt,
                    ect = eot, ectVolt = tpsVolt * 0f, iat = iat, iatVolt = 0f,
                    mapKpa = mapKpa, mapVolt = 0f, battery = battery,
                    afr = afr, o2Volt = o2Volt,
                    engineLoad = tpsPct, iacv = 30,
                    injectorMs = injectorMs, speedKmh = 0,
                    ignitionTiming = ignition, eot = eot,
                    gear = gear, isNeutral = isNeutral
                )
                onDataReceived?.invoke(engineData)
                onLog?.invoke("STREAM OK: RPM=$rpm BAT=$battery AFR=${String.format("%.2f", afr)} IGN=${String.format("%.1f", ignition)}")
            }
            // ============================================================
            // SERVICE 0x71 — TABLE READ (fallback, offset Tabel 10)
            // ============================================================
            else if (responseType == 0x71) {
                val tableId = data[3].toInt() and 0xFF
                if (tableId == 0x10 && data.size >= 22) {
                    val rpm = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
                    val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                    val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                    val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                    val ectRaw = data[9].toInt() and 0xFF
                    val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                    val iatRaw = data[11].toInt() and 0xFF
                    val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                    val mapKpa = data[13].toInt() and 0xFF
                    val battery = (data[16].toInt() and 0xFF) * 0.1f
                    val speed = data[21].toInt() and 0xFF

                    // Validasi: byte 0xFF/0x87 = sensor tidak ada → jangan tampilkan 215°C
                    val ect = if (ectRaw > 190) 0 else ectRaw - 40
                    val iat = if (iatRaw > 190) 0 else iatRaw - 40

                    val engineData = EngineData(
                        rpm = rpm, tpsDeg = tpsDeg, tpsVolt = tpsVolt,
                        ect = ect, ectVolt = ectVolt, iat = iat, iatVolt = iatVolt,
                        mapKpa = mapKpa, mapVolt = mapVolt, battery = battery,
                        afr = 14.7f, o2Volt = 0.45f,
                        engineLoad = (tpsVolt / 5f) * 100f, iacv = 30,
                        injectorMs = 2.5f, speedKmh = speed
                    )
                    onDataReceived?.invoke(engineData)
                    onLog?.invoke("T10 OK: RPM=$rpm BAT=$battery")
                } else if (tableId == 0x11 || tableId == 0x13 || tableId == 0x20 || tableId == 0xD1) {
                    parseDetailTable(data, tableId, rawHex)
                }
            }
            // ============================================================
            // SERVICE 0x73 / 0x74 — DTC
            // ============================================================
            else if (responseType == 0x73 || responseType == 0x74) {
                val dtcList = mutableListOf<String>()
                for (i in 4 until (data.size - 1) step 2) {
                    if (i + 1 < data.size - 1) {
                        val c1 = data[i].toInt() and 0xFF
                        val c2 = data[i + 1].toInt() and 0xFF
                        if (c1 != 0 || c2 != 0) dtcList.add(String.format("%02d-%02d", c1, c2))
                    }
                }
                onDtcReceived?.invoke(dtcList)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error Parsing: ${e.message}")
        }
    }

    private fun parseDetailTable(data: ByteArray, tableId: Int, rawHex: String) {
        val sensorList = mutableListOf<SensorItem>()
        sensorList.add(SensorItem("TABEL ${String.format("%02X", tableId)}", "Raw", rawHex, "--"))

        when (tableId) {
            0x11 -> if (data.size >= 15) {
                val tpsV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapV = (data[7].toInt() and 0xFF) * (5.0f / 256.0f)
                val bat = (data[9].toInt() and 0xFF) * 0.1f
                val injMs = (((data[10].toInt() and 0xFF) shl 8) or (data[11].toInt() and 0xFF)) * 0.001f
                sensorList.add(SensorItem("TABEL 11", "TPS Voltage", "--", String.format("%.2f V", tpsV)))
                sensorList.add(SensorItem("TABEL 11", "MAP Voltage", "--", String.format("%.2f V", mapV)))
                sensorList.add(SensorItem("TABEL 11", "Battery", "--", String.format("%.1f V", bat)))
                sensorList.add(SensorItem("TABEL 11", "Injector", String.format("%.2f ms", injMs), "--"))
            }
            0x13 -> if (data.size >= 15) {
                val ign = ((data[10].toInt() and 0xFF) - 64) * 0.5f
                sensorList.add(SensorItem("TABEL 13", "Ignition Timing", String.format("%.1f° BTDC", ign), "--"))
            }
            0x20 -> if (data.size >= 10) {
                val o2V = (data[4].toInt() and 0xFF) * (5.0f / 256.0f)
                val stftRaw = data[5].toInt() and 0xFF
                val stftSigned = if (stftRaw > 127) stftRaw - 256 else stftRaw
                val stftPct = (stftSigned / 128.0f) * 100f
                val heaterV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                sensorList.add(SensorItem("TABEL 20", "O2 Sensor", "--", String.format("%.3f V", o2V)))
                sensorList.add(SensorItem("TABEL 20", "STFT", String.format("%.1f%%", stftPct), "--"))
                sensorList.add(SensorItem("TABEL 20", "O2 Heater", "--", String.format("%.3f V", heaterV)))
            }
            0xD1 -> if (data.size >= 10) {
                val d9 = data[4].toInt() and 0xFF
                val d13 = data[8].toInt() and 0xFF
                val d14 = data[9].toInt() and 0xFF
                val gear = when (d9) {
                    0x00 -> "In Gear"
                    0x01 -> "Neutral/Clutch"
                    0x03 -> "Kickstand"
                    else -> "Unknown"
                }
                val fp = if (d13 == 0x01 || d13 == 0x05) "ON" else "OFF"
                val cf = if (d14 == 0x01) "ON" else "OFF"
                sensorList.add(SensorItem("TABEL D1", "Gear", gear, "--"))
                sensorList.add(SensorItem("TABEL D1", "Fuel Pump", fp, "--"))
                sensorList.add(SensorItem("TABEL D1", "Cooling Fan", cf, "--"))
            }
        }
        onSensorDetailReceived?.invoke(sensorList)
    }
}