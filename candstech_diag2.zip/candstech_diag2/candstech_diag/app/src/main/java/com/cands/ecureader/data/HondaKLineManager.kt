package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float,
    val o2Volt: Float, val engineLoad: Float, val iacv: Int,
    val injectorMs: Float, val speedKmh: Int,
    val gearStatus: String = "Unknown", val engineRunning: Boolean = false
)

data class SensorItem(
    val category: String, val name: String, val value: String, val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val TAG = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // PROTOKOL SESUAI REFERENSI C++ (andreibaw/Honda_K-Line_KWP2000)
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    
    // Tabel 0x10: Sensor Data (sesuai referensi C++)
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)
    
    // Tabel 0xD1: Status & Gear
    val CMD_STATUS = byteArrayOf(0x72, 0x05, 0x71, 0xD1.toByte(), 0x47)
    
    val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)
    val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) rxQueue.add(b)
        }
    }

    fun setupPort() {
        onLog?.invoke("Membuka Port (10400 Baud, 8N1)...")
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
        onLog?.invoke("Port berhasil dibuka.")
    }

    fun closePort() {
        onLog?.invoke("Port ditutup.")
        try { serialPort.close() } catch (_: Exception) {}
    }

    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length) {
            sum += data[i].toInt() and 0xFF
        }
        return (0x100 - (sum and 0xFF)).toByte()
    }

    // HANDSHAKE - TIDAK DIUBAH (SUDAH BERHASIL CONNECT)
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            serialPort.setBreak(true)
            delay(70)
            serialPort.setBreak(false)
            delay(120)
            serialPort.write(CMD_WAKEUP)
            delay(50)
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP)
            delay(100)
            return@withContext true
        } catch (e: Exception) {
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    fun pollEngineData() {
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) {
            rxQueue.poll()
        }
        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF
            if (expectedLength in 5..60) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) buffer[i] = rxQueue.poll()!!
                    val calcCs = calculateChecksum(buffer, expectedLength - 1)
                    val rxCs = buffer[expectedLength - 1]
                    if (calcCs == rxCs) {
                        parseHondaResponse(buffer)
                    } else {
                        onLog?.invoke("⚠️ Checksum salah!")
                    }
                }
            } else {
                rxQueue.poll()
            }
        }
    }

    // PARSING SESUAI REFERENSI C++ (andreibaw/Honda_K-Line_KWP2000)
    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data[2].toInt() and 0xFF
            val tableId = data[3].toInt() and 0xFF
            val rawHex = data.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }
            val sensorList = mutableListOf<SensorItem>()

            // TABEL 0x10: SENSOR DATA (sesuai referensi C++)
            // Respons: 02 16 71 10 [22 21 20 19 18 17 16 15 14 13 12 11 10 09 08 07 06 05 04 03 02 01] CS
            if (responseType == 0x71 && tableId == 0x10 && data.size >= 22) {
                onLog?.invoke("T10 RAW: $rawHex")
                
                // Offset sesuai referensi C++
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF
                val calculatedRpm = (rpmH shl 8) or rpmL
                
                val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                
                val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                val ect = (data[9].toInt() and 0xFF) - 40
                
                val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                val iat = (data[11].toInt() and 0xFF) - 40
                
                val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapKpa = data[13].toInt() and 0xFF
                
                // Battery di offset 16 (sesuai referensi C++)
                val battery = (data[16].toInt() and 0xFF) * 0.1f
                
                // Speed di offset 17 (BUKAN 21!) - sesuai referensi C++
                val speed = data[17].toInt() and 0xFF

                // Validasi data
                val validEct = if (ect > 150 || ect < -40) 0 else ect
                val validIat = if (iat > 150 || iat < -40) 0 else iat
                val validBattery = if (battery < 5f || battery > 20f) 0f else battery

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDeg, tpsVolt = tpsVolt,
                    ect = validEct, ectVolt = ectVolt, iat = validIat, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = validBattery, speedKmh = speed,
                    afr = 14.7f, o2Volt = 0.45f, engineLoad = (tpsVolt / 5f) * 100f,
                    iacv = 30, injectorMs = 2.5f
                )
                onDataReceived?.invoke(engineData)
                onLog?.invoke("T10 OK: RPM=$calculatedRpm ECT=$validEct IAT=$validIat MAP=$mapKpa BAT=$validBattery SPD=$speed")
            }
            // TABEL 0xD1: STATUS & GEAR (sesuai referensi C++)
            else if (responseType == 0x71 && tableId == 0xD1 && data.size >= 10) {
                onLog?.invoke("D1 RAW: $rawHex")
                
                // Offset 4: Gear Status
                val gearByte = data[4].toInt() and 0xFF
                val gearStatus = when (gearByte) {
                    0x01 -> "Neutral/Clutch"
                    0x00 -> "In Gear"
                    0x03 -> "On Kickstand"
                    else -> "Unknown"
                }
                
                // Offset 8: Engine Status
                val engineByte = data[8].toInt() and 0xFF
                val engineRunning = engineByte == 0x01

                sensorList.add(SensorItem("TABEL D1", "Gear Status", gearStatus, "--"))
                sensorList.add(SensorItem("TABEL D1", "Engine Running", if (engineRunning) "Yes" else "No", "--"))
                onSensorDetailReceived?.invoke(sensorList)
            }
            // DTC
            else if (responseType == 0x73) {
                val dtcList = mutableListOf<String>()
                for (i in 4 until (data.size - 1) step 2) {
                    if (i + 1 < data.size - 1) {
                        val code1 = data[i].toInt() and 0xFF
                        val code2 = data[i+1].toInt() and 0xFF
                        if (code1 != 0 || code2 != 0) {
                            dtcList.add(String.format("%02d-%02d", code1, code2))
                        }
                    }
                }
                onDtcReceived?.invoke(dtcList)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error Parsing: ${e.message}")
        }
    }
}