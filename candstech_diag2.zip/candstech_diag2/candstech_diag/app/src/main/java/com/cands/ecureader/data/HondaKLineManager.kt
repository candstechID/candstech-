package com.cands.ecureader.data

import android.util.Log
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

data class EngineData(
    val rpm: Int, val tpsDeg: Float, val tpsVolt: Float,
    val ect: Int, val ectVolt: Float, val iat: Int, val iatVolt: Float,
    val mapKpa: Int, val mapVolt: Float, val battery: Float, val afr: Float, val o2Volt: Float,
    val engineLoad: Float, val iacv: Int, val injectorMs: Float, val speedKmh: Int,
    val ignitionTiming: Float = 0f, val fastIdle: Boolean = false, val eot: Int = 0
)

data class SensorItem(
    val category: String, val name: String, val value: String, val voltage: String = "--"
)

class HondaKLineManager(private val serialPort: UsbSerialDevice) {
    private val TAG = "HondaKLine"
    private val rxQueue = ConcurrentLinkedQueue<Byte>()

    var onDataReceived: ((EngineData) -> Unit)? = null
    var onDtcReceived: ((List<String>) -> Unit)? = null
    var onSensorDetailReceived: ((List<SensorItem>) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    // PROTOKOL DASAR - TIDAK BERUBAH
    val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
    val CMD_INIT_KWP = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
    
    // GANTI KE TABEL 17 (karena ECU Anda balas 5 byte untuk Tabel 10)
    val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01)
    
    // Tabel tambahan untuk dialog sensor lengkap
    val CMD_T10 = byteArrayOf(0x72, 0x05, 0x71, 0x10, 0x08)
    val CMD_T11 = byteArrayOf(0x72, 0x05, 0x71, 0x11, 0x07)
    val CMD_T13 = byteArrayOf(0x72, 0x05, 0x71, 0x13, 0x05)
    val CMD_T20 = byteArrayOf(0x72, 0x05, 0x71, 0x20, 0xF8.toByte())
    val CMD_TD1 = byteArrayOf(0x72, 0x05, 0x71, 0xD1.toByte(), 0x47)
    
    val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)
    val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)
    val CMD_RESET_TP = byteArrayOf(0x02, 0x04, 0x60, 0x9A.toByte())

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null) {
            for (b in data) rxQueue.add(b)
        }
    }

    fun setupPort() {
        serialPort.open()
        serialPort.setBaudRate(10400)
        serialPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
        serialPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
        serialPort.setParity(UsbSerialInterface.PARITY_NONE)
        serialPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
        serialPort.read(mCallback)
        onLog?.invoke("Port dibuka (10400, 8N1)")
    }

    fun closePort() {
        onLog?.invoke("Port ditutup")
        try { serialPort.close() } catch (_: Exception) {}
    }

    private fun calculateChecksum(data: ByteArray, length: Int): Byte {
        var sum = 0
        for (i in 0 until length) {
            sum += data[i].toInt() and 0xFF
        }
        return (0x100 - (sum and 0xFF)).toByte()
    }

    // ============================================================
    // HANDSHAKE - TIDAK DIGANTI (SUDAH BERHASIL CONNECT)
    // ============================================================
    suspend fun performFastInit(): Boolean = withContext(Dispatchers.IO) {
        try {
            serialPort.setBreak(true)
            delay(70)
            serialPort.setBreak(false)
            delay(120)
            serialPort.write(CMD_WAKEUP)
            delay(50)
            rxQueue.clear()
            serialPort.write(CMD_INIT_KWP)
            delay(100)
            return@withContext true
        } catch (e: Exception) {
            return@withContext false
        }
    }

    fun sendCommand(command: ByteArray) {
        serialPort.write(command)
    }

    fun pollEngineData() {
        while (rxQueue.isNotEmpty() && rxQueue.peek() != 0x02.toByte()) {
            rxQueue.poll()
        }
        if (rxQueue.size >= 2) {
            val list = rxQueue.toList()
            val expectedLength = list[1].toInt() and 0xFF
            if (expectedLength in 5..60) {
                if (rxQueue.size >= expectedLength) {
                    val buffer = ByteArray(expectedLength)
                    for (i in 0 until expectedLength) buffer[i] = rxQueue.poll()!!
                    val calcCs = calculateChecksum(buffer, expectedLength - 1)
                    val rxCs = buffer[expectedLength - 1]
                    if (calcCs == rxCs) {
                        parseHondaResponse(buffer)
                    } else {
                        onLog?.invoke("CS salah: calc=${String.format("%02X", calcCs.toInt() and 0xFF)} rx=${String.format("%02X", rxCs.toInt() and 0xFF)}")
                    }
                }
            } else {
                rxQueue.poll()
            }
        }
    }

    private fun parseHondaResponse(data: ByteArray) {
        if (data.size < 4) return
        try {
            val responseType = data[2].toInt() and 0xFF
            val tableId = data[3].toInt() and 0xFF
            val rawHex = data.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }
            val sensorList = mutableListOf<SensorItem>()

            // ============================================================
            // TABEL 17: LIVE DATA UTAMA (untuk UI depan)
            // ============================================================
            if (responseType == 0x71 && tableId == 0x17 && data.size >= 22) {
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF
                val calculatedRpm = (rpmH shl 8) or rpmL
                val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                val ect = (data[9].toInt() and 0xFF) - 40
                val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                val iat = (data[11].toInt() and 0xFF) - 40
                val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapKpa = data[13].toInt() and 0xFF
                val eot = (data[14].toInt() and 0xFF) - 40
                val battery = (data[16].toInt() and 0xFF) * 0.1f
                val injectorMs = ((data[17].toInt() and 0xFF) * 256 + (data[18].toInt() and 0xFF)) * 0.001f
                val ignition = ((data[19].toInt() and 0xFF) - 64) * 0.5f
                val speed = data[21].toInt() and 0xFF
                val fastIdle = data.size > 22 && data[22].toInt() and 0xFF == 0x01

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDeg, tpsVolt = tpsVolt,
                    ect = ect, ectVolt = ectVolt, iat = iat, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, speedKmh = speed,
                    afr = 14.7f, o2Volt = 0.45f, engineLoad = (tpsVolt / 5f) * 100f,
                    iacv = 30, injectorMs = injectorMs,
                    ignitionTiming = ignition, fastIdle = fastIdle, eot = eot
                )
                onDataReceived?.invoke(engineData)
                onLog?.invoke("T17 OK: RPM=$calculatedRpm IAT=$iat MAP=$mapKpa")
            }
            // ============================================================
            // TABEL 10: FALLBACK (jika ECU lain pakai T10)
            // ============================================================
            else if (responseType == 0x71 && tableId == 0x10 && data.size >= 22) {
                val rpmH = data[4].toInt() and 0xFF
                val rpmL = data[5].toInt() and 0xFF
                val calculatedRpm = (rpmH shl 8) or rpmL
                val tpsVolt = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                val tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                val ectVolt = (data[8].toInt() and 0xFF) * (5.0f / 256.0f)
                val ect = (data[9].toInt() and 0xFF) - 40
                val iatVolt = (data[10].toInt() and 0xFF) * (5.0f / 256.0f)
                val iat = (data[11].toInt() and 0xFF) - 40
                val mapVolt = (data[12].toInt() and 0xFF) * (5.0f / 256.0f)
                val mapKpa = data[13].toInt() and 0xFF
                val battery = (data[16].toInt() and 0xFF) * 0.1f
                val speed = data[21].toInt() and 0xFF

                val engineData = EngineData(
                    rpm = calculatedRpm, tpsDeg = tpsDeg, tpsVolt = tpsVolt,
                    ect = ect, ectVolt = ectVolt, iat = iat, iatVolt = iatVolt,
                    mapKpa = mapKpa, mapVolt = mapVolt, battery = battery, speedKmh = speed,
                    afr = 14.7f, o2Volt = 0.45f, engineLoad = (tpsVolt / 5f) * 100f,
                    iacv = 30, injectorMs = 2.5f
                )
                onDataReceived?.invoke(engineData)
            }
            // ============================================================
            // TABEL 11: Injector & Voltase
            // ============================================================
            else if (responseType == 0x71 && tableId == 0x11) {
                sensorList.add(SensorItem("TABEL 11", "Raw", rawHex, "--"))
                if (data.size >= 15) {
                    val tpsV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                    val mapV = (data[7].toInt() and 0xFF) * (5.0f / 256.0f)
                    val bat = (data[9].toInt() and 0xFF) * 0.1f
                    val injMs = ((data[10].toInt() and 0xFF) * 256 + (data[11].toInt() and 0xFF)) * 0.001f
                    sensorList.add(SensorItem("TABEL 11", "TPS", "--", "${String.format("%.2f", tpsV)} V"))
                    sensorList.add(SensorItem("TABEL 11", "MAP", "--", "${String.format("%.2f", mapV)} V"))
                    sensorList.add(SensorItem("TABEL 11", "Battery", "--", "${String.format("%.1f", bat)} V"))
                    sensorList.add(SensorItem("TABEL 11", "Injector", "${String.format("%.2f", injMs)} ms", "--"))
                }
                onSensorDetailReceived?.invoke(sensorList)
            }
            // ============================================================
            // TABEL 13: Ignition Timing
            // ============================================================
            else if (responseType == 0x71 && tableId == 0x13) {
                sensorList.add(SensorItem("TABEL 13", "Raw", rawHex, "--"))
                if (data.size >= 15) {
                    val ign = ((data[10].toInt() and 0xFF) - 64) * 0.5f
                    sensorList.add(SensorItem("TABEL 13", "Ignition", "${String.format("%.1f", ign)}° BTDC", "--"))
                }
                onSensorDetailReceived?.invoke(sensorList)
            }
            // ============================================================
            // TABEL 20: O2 & STFT
            // ============================================================
            else if (responseType == 0x71 && tableId == 0x20) {
                sensorList.add(SensorItem("TABEL 20", "Raw", rawHex, "--"))
                if (data.size >= 10) {
                    val o2V = (data[4].toInt() and 0xFF) * (5.0f / 256.0f)
                    val stftRaw = data[5].toInt() and 0xFF
                    val stftSigned = if (stftRaw > 127) stftRaw - 256 else stftRaw
                    val stftPct = (stftSigned / 128.0f) * 100f
                    val heaterV = (data[6].toInt() and 0xFF) * (5.0f / 256.0f)
                    sensorList.add(SensorItem("TABEL 20", "O2", "--", "${String.format("%.3f", o2V)} V"))
                    sensorList.add(SensorItem("TABEL 20", "STFT", "${String.format("%.1f", stftPct)}%", "--"))
                    sensorList.add(SensorItem("TABEL 20", "O2 Heater", "--", "${String.format("%.3f", heaterV)} V"))
                }
                onSensorDetailReceived?.invoke(sensorList)
            }
            // ============================================================
            // TABEL D1: Status (Gear, Fuel Pump, Fan)
            // ============================================================
            else if (responseType == 0x71 && tableId == 0xD1) {
                sensorList.add(SensorItem("TABEL D1", "Raw", rawHex, "--"))
                if (data.size >= 10) {
                    val d9 = data[4].toInt() and 0xFF
                    val d13 = data[8].toInt() and 0xFF
                    val d14 = data[9].toInt() and 0xFF
                    val gear = when (d9) {
                        0x00 -> "Neutral"
                        0x01 -> "On Gear"
                        0x03 -> "Kickstand"
                        else -> "Unknown"
                    }
                    val fp = if (d13 == 0x01 || d13 == 0x05) "ON" else "OFF"
                    val cf = if (d14 == 0x01) "ON" else "OFF"
                    sensorList.add(SensorItem("TABEL D1", "Gear", gear, "--"))
                    sensorList.add(SensorItem("TABEL D1", "Fuel Pump", fp, "--"))
                    sensorList.add(SensorItem("TABEL D1", "Cooling Fan", cf, "--"))
                }
                onSensorDetailReceived?.invoke(sensorList)
            }
            // ============================================================
            // DTC
            // ============================================================
            else if (responseType == 0x73) {
                val dtcList = mutableListOf<String>()
                for (i in 4 until (data.size - 1) step 2) {
                    if (i + 1 < data.size - 1) {
                        val code1 = data[i].toInt() and 0xFF
                        val code2 = data[i+1].toInt() and 0xFF
                        if (code1 != 0 || code2 != 0) {
                            dtcList.add(String.format("%02d-%02d", code1, code2))
                        }
                    }
                }
                onDtcReceived?.invoke(dtcList)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error Parsing: ${e.message}")
        }
    }
}